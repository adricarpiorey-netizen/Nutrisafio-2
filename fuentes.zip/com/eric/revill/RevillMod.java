package com.eric.revill;

import com.eric.revill.command.Dedsafio4Command;
import com.eric.revill.command.EconomyCommand;
import com.eric.revill.command.RevillCommand;
import com.eric.revill.config.RevillConfig;
import com.eric.revill.dedsafio4.Dedsafio4Manager;
import com.eric.revill.dedsafio4.Dedsafio4Networking;
import com.eric.revill.dedsafio4.DifficultyEffects;
import com.eric.revill.economy.AtmScreenHandler;
import com.eric.revill.economy.CurrencyManager;
import com.eric.revill.economy.EconomyNetworking;
import com.eric.revill.entity.ModEntities;
import com.eric.revill.event.RedEventManager;
import com.eric.revill.item.ModItems;
import com.eric.revill.mail.MailComposeScreenHandler;
import com.eric.revill.mail.MailInboxScreenHandler;
import com.eric.revill.mail.MailNetworking;
import com.eric.revill.mail.ModMailBlocks;
import com.eric.revill.mixin.CreeperEntityChargedAccessor;
import com.eric.revill.network.RevillNetworking;
import com.eric.revill.waypoint.Waypoint;
import com.eric.revill.waypoint.WaypointManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AllowDeath;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.Load;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.ServerStarted;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.ServerStopping;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndTick;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.Join;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RevillMod implements ModInitializer {
   public static final String MOD_ID = "dedsafio-4-mechanics";
   public static final Logger LOGGER = LoggerFactory.getLogger("dedsafio-4-mechanics");
   public static final RevillConfig CONFIG = RevillConfig.load();
   public static boolean FUSION_ACTIVE = false;

   public void onInitialize() {
      LOGGER.info("Iniciando DEDSAFIO 4 Mechanics para Minecraft 1.20.1");
      ModEntities.initialize();
      AtmScreenHandler.initialize();
      ModMailBlocks.initialize();
      MailInboxScreenHandler.initialize();
      MailComposeScreenHandler.initialize();
      ModItems.initialize();
      DifficultyEffects.register();
      EconomyNetworking.registerServer();
      MailNetworking.registerServer();
      CommandRegistrationCallback.EVENT.register((CommandRegistrationCallback)(dispatcher, registryAccess, environment) -> {
         RevillCommand.register(dispatcher);
         Dedsafio4Command.register(dispatcher);
         EconomyCommand.register(dispatcher);
      });
      ServerLifecycleEvents.SERVER_STARTED.register((ServerStarted)server -> RedEventManager.INSTANCE.loadState(server));
      ServerLifecycleEvents.SERVER_STOPPING.register((ServerStopping)server -> RedEventManager.INSTANCE.shutdown(server));
      ServerTickEvents.END_SERVER_TICK.register((EndTick)server -> {
         RedEventManager.INSTANCE.tick(server);
         Dedsafio4Manager.tick(server);
      });
      ServerEntityEvents.ENTITY_LOAD.register((Load)(entity, world) -> {
         if (entity instanceof Creeper creeper && Dedsafio4Manager.isEnabled("dia1_creepers_electricos")) {
            creeper.getEntityData().set(CreeperEntityChargedAccessor.dedsafio4$getChargedData(), true);
         }
      });
      ServerLivingEntityEvents.ALLOW_DEATH
         .register(
            (AllowDeath)(entity, source, damageAmount) -> {
               if (!(entity instanceof ServerPlayer player)) {
                  return true;
               } else {
                  boolean hasTotem = player.getOffhandItem().is(Items.TOTEM_OF_UNDYING) || player.getMainHandItem().is(Items.TOTEM_OF_UNDYING);
                  if (!hasTotem) {
                     return !Dedsafio4Manager.handleDeath(player, source, damageAmount);
                  } else {
                     Component totemMessage = Component.literal(player.getName().getString())
                        .withStyle(ChatFormatting.BOLD)
                        .append(Component.literal(" ha consumido un totem").withStyle(ChatFormatting.YELLOW));

                     for (ServerPlayer viewer : player.getServer().getPlayerList().getPlayers()) {
                        viewer.displayClientMessage(totemMessage, false);
                     }

                     return true;
                  }
               }
            }
         );
      ServerPlayNetworking.registerGlobalReceiver(Dedsafio4Networking.APPLY_CHANGE, (server, player, handler, buf, responseSender) -> {
         String changeId = buf.readUtf();
         server.execute(() -> Dedsafio4Manager.activateChange(server, changeId));
      });
      ServerPlayNetworking.registerGlobalReceiver(Dedsafio4Networking.CUSTOM_ROULETTE, (server, player, handler, buf, responseSender) -> {
         String color = buf.readUtf();
         String message = buf.readUtf();
         server.execute(() -> Dedsafio4Manager.startRoulette(server, color, message));
      });
      ServerPlayNetworking.registerGlobalReceiver(
         RevillNetworking.NUTRIA_ANIMATION_COMPLETE,
         (server, player, handler, buf, responseSender) -> server.execute(() -> Dedsafio4Manager.finishNutriaAnnouncement(server))
      );
      ServerPlayNetworking.registerGlobalReceiver(
         RevillNetworking.REVILL_INTRO_COMPLETE,
         (server, player, handler, buf, responseSender) -> server.execute(() -> Dedsafio4Manager.finishRevillIntro(server))
      );
      ServerPlayNetworking.registerGlobalReceiver(Dedsafio4Networking.START_REVILL, (server, player, handler, buf, responseSender) -> {
         String taskId = buf.readUtf(64);
         String message = buf.readUtf();
         server.execute(() -> RedEventManager.INSTANCE.startRedEvent(server, taskId, message));
      });
      ServerPlayNetworking.registerGlobalReceiver(Dedsafio4Networking.STOP_REVILL, (server, player, handler, buf, responseSender) -> {
         if (!player.hasPermissions(2)) {
            player.displayClientMessage(Component.literal("Necesitas ser operador para detener REVILL."), false);
         } else {
            server.execute(() -> RedEventManager.INSTANCE.stopRedEvent(server, true));
         }
      });
      ServerPlayNetworking.registerGlobalReceiver(WaypointManager.ADD_WAYPOINT, (server, player, handler, buf, responseSender) -> {
         String name = buf.readUtf();
         String icon = buf.readUtf();
         server.execute(() -> {
            String id = "wp_" + System.currentTimeMillis();
            Waypoint wp = new Waypoint(id, name, player.blockPosition(), icon, -16711732, player.level().dimension().location().toString());
            WaypointManager.addWaypoint(server, wp);
            player.displayClientMessage(Component.literal("Waypoint '" + name + "' registrado."), false);
         });
      });
      ServerPlayNetworking.registerGlobalReceiver(WaypointManager.REMOVE_WAYPOINT, (server, player, handler, buf, responseSender) -> {
         String id = buf.readUtf();
         server.execute(() -> {
            WaypointManager.removeWaypoint(server, id);
            player.displayClientMessage(Component.literal("Waypoint eliminado."), false);
         });
      });
      ServerPlayNetworking.registerGlobalReceiver(WaypointManager.EDIT_WAYPOINT, (server, player, handler, buf, responseSender) -> {
         String id = buf.readUtf();
         String name = buf.readUtf();
         String icon = buf.readUtf();
         BlockPos pos = buf.readBlockPos();
         int color = buf.readInt();
         String dim = buf.readUtf();
         server.execute(() -> {
            Waypoint wp = new Waypoint(id, name, pos, icon, color, dim);
            WaypointManager.addWaypoint(server, wp);
            player.displayClientMessage(Component.literal("Waypoint '" + name + "' actualizado."), false);
         });
      });
      ServerPlayConnectionEvents.JOIN.register((Join)(handler, sender, server) -> {
         WaypointManager.syncToPlayer(handler.getPlayer());
         CurrencyManager.sync(handler.getPlayer());
      });
      LOGGER.info("DEDSAFIO 4 Mechanics inicializado correctamente.");
   }
}
