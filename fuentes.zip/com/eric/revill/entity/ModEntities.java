package com.eric.revill.entity;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;

public final class ModEntities {
   public static final EntityType<CajeroEntity> CAJERO = (EntityType<CajeroEntity>)Registry.register(
      BuiltInRegistries.ENTITY_TYPE,
      new ResourceLocation("dedsafio-4-mechanics", "cajero"),
      Builder.of(CajeroEntity::new, MobCategory.MISC).sized(0.75F, 1.8F).clientTrackingRange(10).updateInterval(3).build("cajero")
   );

   private ModEntities() {
   }

   public static void initialize() {
      FabricDefaultAttributeRegistry.register(CAJERO, Mob.createMobAttributes().build());
   }
}
