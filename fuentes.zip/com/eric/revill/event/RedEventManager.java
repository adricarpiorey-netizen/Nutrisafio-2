package com.eric.revill.event;

import com.eric.revill.RevillMod;
import com.eric.revill.bunker.BunkerManager;
import com.eric.revill.config.RevillConfig;
import com.eric.revill.dedsafio4.Dedsafio4Manager;
import com.eric.revill.meteor.MeteorManager;
import com.eric.revill.network.RevillNetworking;
import com.eric.revill.waypoint.WaypointManager;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.DimensionDataStorage;

public class RedEventManager {
   public static final RedEventManager INSTANCE = new RedEventManager();
   private final RevillConfig config = RevillMod.CONFIG;
   private final MeteorManager meteorManager = new MeteorManager();
   private final Set<ServerPlayer> participatingPlayers = new HashSet<>();
   private boolean eventActive;
   private int remainingSeconds = 600;
   private boolean skyActive;
   private boolean announcementActive;
   private boolean eventFinished;
   private int tickCounter;
   private RevillTask activeTask = RevillTask.BUNKER;
   private RevillTask pendingTask = RevillTask.BUNKER;
   private final Set<UUID> completedTaskPlayers = new HashSet<>();

   public RevillConfig getConfig() {
      return this.config;
   }

   public void startRedEvent(MinecraftServer server) {
      this.startRedEvent(server, RevillTask.BUNKER.id(), null);
   }

   public void startRedEvent(MinecraftServer server, String rouletteMessage) {
      this.startRedEvent(server, RevillTask.BUNKER.id(), rouletteMessage);
   }

   public void startRedEvent(MinecraftServer server, String taskId, String additionalMessage) {
      if (server != null && !this.eventActive) {
         this.pendingTask = RevillTask.fromId(taskId);
         Dedsafio4Manager.startRevillRoulette(server, this.pendingTask, additionalMessage);
      }
   }

   public RevillTask getPendingTask() {
      return this.pendingTask;
   }

   public void beginRedEvent(MinecraftServer server) {
      if (server != null && !this.eventActive) {
         this.eventActive = true;
         this.eventFinished = false;
         this.tickCounter = 0;
         this.remainingSeconds = this.config.durationSeconds;
         this.skyActive = true;
         this.announcementActive = this.config.announcementEnabled;
         this.activeTask = this.pendingTask;
         this.pendingTask = this.activeTask;
         this.participatingPlayers.clear();
         this.completedTaskPlayers.clear();

         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            this.participatingPlayers.add(player);
         }

         if (this.activeTask == RevillTask.BUNKER && BunkerManager.isConfigured()) {
            BlockPos first = BunkerManager.getBunker().getFirstCorner();
            BlockPos second = BunkerManager.getBunker().getSecondCorner();
            int centerX = (first.getX() + second.getX()) / 2;
            int centerY = (first.getY() + second.getY()) / 2;
            int centerZ = (first.getZ() + second.getZ()) / 2;
            WaypointManager.setBunkerWaypoint(server, new BlockPos(centerX, centerY, centerZ), BunkerManager.getBunker().getDimension());
         }

         this.showAnnouncement(server);
         RevillNetworking.sendEventState(server, true, this.remainingSeconds, true, true);
         this.saveState(server);
      }
   }

   public void stopRedEvent(MinecraftServer server, boolean cancelled) {
      boolean cancelledRoulette = Dedsafio4Manager.cancelPendingRevillRoulette(server);
      if (this.eventActive || this.eventFinished || cancelledRoulette) {
         this.eventActive = false;
         this.eventFinished = true;
         this.skyActive = false;
         this.announcementActive = false;
         this.completedTaskPlayers.clear();
         this.meteorManager.clear();
         if (server != null) {
            WaypointManager.removeWaypoint(server, "bunker");
            RevillNetworking.sendEventState(server, false, 0, false, false);
            if (cancelled) {
               this.sendGlobalMessage(server, "El Evento Rojo ha sido cancelado.");
            }
         }

         this.saveState(server);
      }
   }

   public void tick(MinecraftServer server) {
      if (server != null && this.eventActive) {
         this.tickCounter++;
         if (this.tickCounter % 20 == 0) {
            this.remainingSeconds = Math.max(0, this.remainingSeconds - 1);
            this.sendTimeWarnings(server, this.remainingSeconds);
            RevillNetworking.sendEventState(server, true, this.remainingSeconds, this.skyActive, this.announcementActive);
            if (this.remainingSeconds <= 0) {
               this.performFinalCheck(server);
               return;
            }
         }

         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!player.isSpectator() && this.activeTask.isComplete(player) && this.completedTaskPlayers.add(player.getUUID())) {
               this.sendGlobalMessage(server, this.activeTask.completionMessage(player.getGameProfile().getName()));
            }
         }

         if (server.overworld() != null) {
            this.meteorManager.update(server.overworld(), this.remainingSeconds, this.config);
         }
      }
   }

   public void displayStatus(CommandSourceStack source) {
      source.sendSuccess(
         () -> Component.literal(
               "Evento activo: "
                  + (this.eventActive ? "sí" : "no")
                  + "\nTiempo restante: "
                  + this.formatSeconds(this.remainingSeconds)
                  + "\nMeteoritos activos: "
                  + this.meteorManager.getActiveCount()
                  + "\nBúnker configurado: "
                  + (BunkerManager.isConfigured() ? "sí" : "no")
                  + "\nCielo rojo: "
                  + (this.skyActive ? "activo" : "inactivo")
            ),
         false
      );
   }

   public void loadState(MinecraftServer server) {
      if (server != null) {
         DimensionDataStorage manager = server.overworld().getDataStorage();
         RedEventState state = (RedEventState)manager.computeIfAbsent(RedEventState::fromNbt, RedEventState::new, "revill_event");
         this.eventActive = state.isActive();
         this.remainingSeconds = state.getRemainingSeconds();
         this.skyActive = state.isSkyActive();
         this.announcementActive = state.isAnnouncementActive();
         this.activeTask = RevillTask.fromId(state.getTaskId());
         this.pendingTask = this.activeTask;
         BunkerManager.applyToState(state);
         if (this.eventActive) {
            RevillNetworking.sendEventState(server, true, this.remainingSeconds, this.skyActive, this.announcementActive);
         }
      }
   }

   public void saveState(MinecraftServer server) {
      if (server != null && server.overworld() != null) {
         DimensionDataStorage manager = server.overworld().getDataStorage();
         RedEventState state = (RedEventState)manager.computeIfAbsent(RedEventState::fromNbt, RedEventState::new, "revill_event");
         state.setActive(this.eventActive);
         state.setRemainingSeconds(this.remainingSeconds);
         state.setSkyActive(this.skyActive);
         state.setAnnouncementActive(this.announcementActive);
         state.setTaskId(this.activeTask.id());
         BunkerManager.applyToState(state);
         state.setWorldKey(server.overworld().dimension().location().toString());
         state.setDirty();
      }
   }

   public void shutdown(MinecraftServer server) {
      this.saveState(server);
   }

   private void showAnnouncement(MinecraftServer server) {
      if (server != null && this.config.announcementEnabled) {
         this.announcementActive = true;
         RevillNetworking.sendAnnouncement(server, this.config.announcementDurationSeconds, this.config.announcementFlashSpeed);
      }
   }

   private void sendTimeWarnings(MinecraftServer server, int seconds) {
      if (seconds == 600 || seconds == 300 || seconds == 120 || seconds == 60 || seconds == 30 || seconds == 10) {
         String text = switch (seconds) {
            case 10 -> "10 segundos.";
            case 30 -> "Quedan 30 segundos.";
            case 60 -> "Queda 1 minuto.";
            case 120 -> "Quedan 2 minutos.";
            case 300 -> "Quedan 5 minutos.";
            case 600 -> "Quedan 10 minutos.";
            default -> "";
         };
         if (!text.isEmpty()) {
            this.sendGlobalMessage(server, text);
         }
      }
   }

   private void performFinalCheck(MinecraftServer server) {
      this.eventActive = false;
      this.eventFinished = true;
      this.skyActive = false;
      this.announcementActive = false;
      this.meteorManager.clear();
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (!this.activeTask.isComplete(player) && !this.completedTaskPlayers.contains(player.getUUID())) {
               player.kill();
            }
         }

         this.sendGlobalMessage(
            server, "Final del Momento Revill. Objetivo: " + this.activeTask.shortTitle() + ". Quienes no lo completaron han sido eliminados."
         );
         RevillNetworking.sendEventState(server, false, 0, false, false);
      }

      this.saveState(server);
   }

   private void sendGlobalMessage(MinecraftServer server, String message) {
      if (server != null) {
         Component text = Component.literal(message);

         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.displayClientMessage(text, false);
         }
      }
   }

   private String formatSeconds(int seconds) {
      int totalMinutes = seconds / 60;
      int remainingSeconds = seconds % 60;
      return String.format("%02d:%02d", totalMinutes, remainingSeconds);
   }
}
