package com.eric.revill.dedsafio4;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AllowDamage;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.Load;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.EndWorldTick;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ambient.AmbientCreature;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.WaterAnimal;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.monster.Drowned;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.monster.Stray;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.monster.ZombieVillager;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.TrapDoorBlock;

public final class DifficultyEffects {
   private static final ThreadLocal<Boolean> TRIPLING_FIRE_DAMAGE = ThreadLocal.withInitial(() -> false);

   private DifficultyEffects() {
   }

   public static void register() {
      registerEnderPearlDamageIgnoreArmor();
      registerWardensSculkShrieker();
      registerNoMilk();
      registerNoUnderwaterAirPockets();
      registerNoGolems();
      registerSpiderWebCaveSpider();
      registerZombieClimbers();
      registerBlazeNether();
      registerZombiesNether();
      registerZombieMejorados();
      registerMagmaLethal();
      registerBoggeds();
      registerStrays();
      registerLunaMata();
      registerWardenDeepDark();
      registerTreeSaplings();
      registerWitherSkeletonsNether();
      registerFireLavaTripleDamage();
      registerAnimalExtinction();
   }

   public static void extinguishAnimals(MinecraftServer server) {
      if (server != null) {
         for (ServerLevel world : server.getAllLevels()) {
            List<Entity> animals = new ArrayList<>();

            for (Entity entity : world.getAllEntities()) {
               if (isAnimalEntity(entity)) {
                  animals.add(entity);
               }
            }

            animals.forEach(Entity::discard);
         }
      }
   }

   private static void registerWitherSkeletonsNether() {
      ServerTickEvents.END_WORLD_TICK
         .register(
            (EndWorldTick)world -> {
               if (Dedsafio4Manager.isEnabled("dia6_wither_skeletons_nether")) {
                  ServerLevel serverWorld = world;
                  if (world.dimension().equals(Level.NETHER) && world.getGameTime() % 60L == 0L) {
                     for (ServerPlayer player : world.players()) {
                        if (serverWorld.getRandom().nextInt(10) == 0) {
                           BlockPos spawnPos = findGroundPos(
                              serverWorld,
                              player.blockPosition()
                                 .offset(serverWorld.getRandom().nextIntBetweenInclusive(-24, 24), 0, serverWorld.getRandom().nextIntBetweenInclusive(-24, 24))
                           );
                           if (spawnPos != null) {
                              WitherSkeleton skeleton = (WitherSkeleton)EntityType.WITHER_SKELETON.create(serverWorld);
                              if (skeleton != null) {
                                 skeleton.moveTo((double)spawnPos.getX() + 0.5, (double)spawnPos.getY(), (double)spawnPos.getZ() + 0.5, 0.0F, 0.0F);
                                 skeleton.finalizeSpawn(serverWorld, serverWorld.getCurrentDifficultyAt(spawnPos), MobSpawnType.NATURAL, null, null);
                                 serverWorld.addFreshEntityWithPassengers(skeleton);
                              }
                           }
                        }
                     }
                  }
               }
            }
         );
   }

   private static void registerFireLavaTripleDamage() {
      ServerLivingEntityEvents.ALLOW_DAMAGE
         .register(
            (AllowDamage)(entity, source, amount) -> {
               if (TRIPLING_FIRE_DAMAGE.get()) {
                  return true;
               } else if (Dedsafio4Manager.isEnabled("dia6_fuego_lava_triple")
                  && (source.is(DamageTypes.IN_FIRE) || source.is(DamageTypes.ON_FIRE) || source.is(DamageTypes.LAVA))) {
                  TRIPLING_FIRE_DAMAGE.set(true);

                  try {
                     entity.hurt(source, amount * 3.0F);
                  } finally {
                     TRIPLING_FIRE_DAMAGE.set(false);
                  }

                  return false;
               } else {
                  return true;
               }
            }
         );
   }

   private static void registerAnimalExtinction() {
      ServerEntityEvents.ENTITY_LOAD.register((Load)(entity, world) -> {
         if (Dedsafio4Manager.isEnabled("dia6_animales_extintos") && isAnimalEntity(entity)) {
            entity.discard();
         }
      });
   }

   private static boolean isAnimalEntity(Entity entity) {
      return entity instanceof Animal || entity instanceof WaterAnimal || entity instanceof AmbientCreature;
   }

   private static void registerEnderPearlDamageIgnoreArmor() {
   }

   private static void registerWardensSculkShrieker() {
   }

   private static void registerNoMilk() {
      UseBlockCallback.EVENT.register((UseBlockCallback)(player, world, hand, hitResult) -> {
         if (world.isClientSide) {
            return InteractionResult.PASS;
         } else if (!Dedsafio4Manager.isEnabled("dia1_no_leche")) {
            return InteractionResult.PASS;
         } else if (player instanceof ServerPlayer sp) {
            BlockPos pos = hitResult.getBlockPos();
            return InteractionResult.PASS;
         } else {
            return InteractionResult.PASS;
         }
      });
      UseEntityCallback.EVENT.register((UseEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.isClientSide) {
            return InteractionResult.PASS;
         } else if (!Dedsafio4Manager.isEnabled("dia1_no_leche")) {
            return InteractionResult.PASS;
         } else if (!(entity instanceof Cow)) {
            return InteractionResult.PASS;
         } else {
            ItemStack stack = player.getItemInHand(hand);
            if (stack.is(Items.BUCKET)) {
               player.displayClientMessage(Component.literal("§cLas vacas ya no producen leche."), true);
               return InteractionResult.FAIL;
            } else {
               return InteractionResult.PASS;
            }
         }
      });
   }

   private static void registerNoGolems() {
   }

   private static void registerNoUnderwaterAirPockets() {
      UseBlockCallback.EVENT.register((UseBlockCallback)(player, world, hand, hitResult) -> {
         if (world.isClientSide || !Dedsafio4Manager.isEnabled("dia1_respirar_bajo_agua")) {
            return InteractionResult.PASS;
         } else if (!player.isUnderWater()) {
            return InteractionResult.PASS;
         } else {
            ItemStack stack = player.getItemInHand(hand);
            if (!(stack.getItem() instanceof BlockItem blockItem)) {
               return InteractionResult.PASS;
            } else {
               Block block = blockItem.getBlock();
               return !(block instanceof DoorBlock) && !(block instanceof TrapDoorBlock) ? InteractionResult.PASS : InteractionResult.FAIL;
            }
         }
      });
   }

   private static void registerSpiderWebCaveSpider() {
   }

   private static void registerZombieClimbers() {
      ServerEntityEvents.ENTITY_LOAD.register((Load)(entity, world) -> {
         if (Dedsafio4Manager.isEnabled("dia2_zombies_trepadores") || Dedsafio4Manager.isEnabled("dia4_zombies_mejorados")) {
            if (entity instanceof Zombie zombie) {
               if (!(zombie instanceof Drowned) && !(zombie instanceof ZombieVillager)) {
                  boolean climber;
                  boolean sunImmune;
                  if (Dedsafio4Manager.isEnabled("dia4_zombies_mejorados")) {
                     climber = true;
                     sunImmune = true;
                  } else {
                     climber = world.getRandom().nextBoolean();
                     sunImmune = climber;
                  }

                  if (climber) {
                     zombie.setCanPickUpLoot(true);
                  }

                  if (sunImmune) {
                     zombie.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false, false));
                  }
               }
            }
         }
      });
   }

   private static void registerBlazeNether() {
      ServerTickEvents.END_WORLD_TICK
         .register(
            (EndWorldTick)world -> {
               if (Dedsafio4Manager.isEnabled("dia2_blazes_nether")) {
                  ServerLevel sw = world;
                  if (world.dimension().equals(Level.NETHER)) {
                     if (world.getGameTime() % 60L == 0L) {
                        for (ServerPlayer player : world.players()) {
                           if (sw.getRandom().nextInt(10) == 0) {
                              BlockPos spawnPos = findGroundPos(
                                 sw,
                                 player.blockPosition()
                                    .offset(sw.getRandom().nextIntBetweenInclusive(-24, 24), 0, sw.getRandom().nextIntBetweenInclusive(-24, 24))
                              );
                              if (spawnPos != null) {
                                 Blaze blaze = (Blaze)EntityType.BLAZE.create(sw);
                                 if (blaze != null) {
                                    blaze.moveTo((double)spawnPos.getX() + 0.5, (double)spawnPos.getY(), (double)spawnPos.getZ() + 0.5, 0.0F, 0.0F);
                                    blaze.finalizeSpawn(sw, sw.getCurrentDifficultyAt(spawnPos), MobSpawnType.NATURAL, null, null);
                                    sw.addFreshEntityWithPassengers(blaze);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         );
   }

   private static void registerZombiesNether() {
      ServerTickEvents.END_WORLD_TICK.register((EndWorldTick)world -> {
         if (Dedsafio4Manager.isEnabled("dia5_zombies_nether")) {
            ServerLevel sw = world;
            if (world.dimension().equals(Level.NETHER)) {
               if (world.getGameTime() % 40L == 0L) {
                  for (ServerPlayer player : world.players()) {
                     if (sw.getRandom().nextInt(10) == 0) {
                        int offsetX = sw.getRandom().nextIntBetweenInclusive(-24, 24);
                        int offsetZ = sw.getRandom().nextIntBetweenInclusive(-24, 24);
                        BlockPos spawnPos = player.blockPosition().offset(offsetX, 0, offsetZ);
                        spawnPos = findGroundPos(sw, spawnPos);
                        if (spawnPos != null) {
                           Zombie zombie = (Zombie)EntityType.ZOMBIE.create(sw);
                           if (zombie != null) {
                              zombie.moveTo((double)spawnPos.getX() + 0.5, (double)spawnPos.getY(), (double)spawnPos.getZ() + 0.5, 0.0F, 0.0F);
                              zombie.finalizeSpawn(sw, sw.getCurrentDifficultyAt(spawnPos), MobSpawnType.SPAWNER, null, null);
                              sw.addFreshEntityWithPassengers(zombie);
                           }
                        }
                     }
                  }
               }
            }
         }
      });
   }

   private static void registerZombieMejorados() {
      ServerEntityEvents.ENTITY_LOAD.register((Load)(entity, world) -> {
         if (Dedsafio4Manager.isEnabled("dia4_zombies_mejorados")) {
            if (entity instanceof Zombie zombie) {
               if (!(zombie instanceof Drowned) && !(zombie instanceof ZombieVillager)) {
                  zombie.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false, false));
                  ItemStack sword = new ItemStack(Items.IRON_SWORD);
                  sword.enchant(Enchantments.SHARPNESS, 5);
                  zombie.setItemSlot(EquipmentSlot.MAINHAND, sword);
               }
            }
         }
      });
   }

   private static void registerMagmaLethal() {
      ServerTickEvents.END_WORLD_TICK.register((EndWorldTick)world -> {
         if (Dedsafio4Manager.isEnabled("dia3_magma_letal")) {
            ServerLevel sw = world;

            for (ServerPlayer player : world.players()) {
               if (!player.isSpectator() && !player.isCreative()) {
                  BlockPos pos = player.blockPosition();

                  for (BlockPos check : new BlockPos[]{pos, pos.below(), pos.above(), pos.north(), pos.south(), pos.east(), pos.west()}) {
                     if (sw.getBlockState(check).is(Blocks.MAGMA_BLOCK)) {
                        player.hurt(sw.damageSources().hotFloor(), Float.MAX_VALUE);
                        break;
                     }
                  }
               }
            }
         }
      });
   }

   private static void registerBoggeds() {
      ServerTickEvents.END_WORLD_TICK.register((EndWorldTick)world -> {
         if (Dedsafio4Manager.isEnabled("dia5_bogged_noche")) {
            ServerLevel sw = world;
            if (!world.dimension().equals(Level.NETHER)) {
               if (!world.dimension().equals(Level.END)) {
                  if (world.isNight()) {
                     if (world.getGameTime() % 60L == 0L) {
                        for (ServerPlayer player : world.players()) {
                           if (sw.getRandom().nextInt(8) == 0) {
                              int offsetX = sw.getRandom().nextIntBetweenInclusive(-20, 20);
                              int offsetZ = sw.getRandom().nextIntBetweenInclusive(-20, 20);
                              BlockPos spawnPos = findGroundPos(sw, player.blockPosition().offset(offsetX, 0, offsetZ));
                              if (spawnPos != null) {
                                 Skeleton bogged = (Skeleton)EntityType.SKELETON.create(sw);
                                 if (bogged != null) {
                                    bogged.addTag("dedsafio4_bogged");
                                    bogged.moveTo((double)spawnPos.getX() + 0.5, (double)spawnPos.getY(), (double)spawnPos.getZ() + 0.5, 0.0F, 0.0F);
                                    bogged.finalizeSpawn(sw, sw.getCurrentDifficultyAt(spawnPos), MobSpawnType.NATURAL, null, null);
                                    sw.addFreshEntityWithPassengers(bogged);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      });
   }

   private static void registerStrays() {
      ServerTickEvents.END_WORLD_TICK.register((EndWorldTick)world -> {
         if (Dedsafio4Manager.isEnabled("dia5_stray_noche")) {
            ServerLevel sw = world;
            if (world.dimension().equals(Level.OVERWORLD)) {
               if (world.isNight()) {
                  if (world.getGameTime() % 60L == 0L) {
                     for (ServerPlayer player : world.players()) {
                        if (sw.getRandom().nextInt(8) == 0) {
                           int offsetX = sw.getRandom().nextIntBetweenInclusive(-20, 20);
                           int offsetZ = sw.getRandom().nextIntBetweenInclusive(-20, 20);
                           BlockPos spawnPos = findGroundPos(sw, player.blockPosition().offset(offsetX, 0, offsetZ));
                           if (spawnPos != null) {
                              Stray stray = (Stray)EntityType.STRAY.create(sw);
                              if (stray != null) {
                                 stray.moveTo((double)spawnPos.getX() + 0.5, (double)spawnPos.getY(), (double)spawnPos.getZ() + 0.5, 0.0F, 0.0F);
                                 stray.finalizeSpawn(sw, sw.getCurrentDifficultyAt(spawnPos), MobSpawnType.NATURAL, null, null);
                                 sw.addFreshEntityWithPassengers(stray);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      });
   }

   private static void registerLunaMata() {
      ServerTickEvents.END_WORLD_TICK.register((EndWorldTick)world -> {
         if (Dedsafio4Manager.isEnabled("dia5_luna_mata")) {
            ServerLevel sw = world;
            if (world.dimension().equals(Level.OVERWORLD)) {
               if (world.isNight()) {
                  if (world.getGameTime() % 5L == 0L) {
                     for (ServerPlayer player : world.players()) {
                        if (!player.isSpectator() && !player.isCreative()) {
                           float pitch = player.getXRot();
                           if (!(pitch > -40.0F)) {
                              BlockPos eyePos = player.blockPosition().above();
                              if (!sw.getBlockState(eyePos).canOcclude()) {
                                 player.hurt(sw.damageSources().magic(), Float.MAX_VALUE);
                                 Dedsafio4Manager.disableChange("dia5_luna_mata");
                                 break;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      });
   }

   private static void registerWardenDeepDark() {
      ServerEntityEvents.ENTITY_LOAD.register((Load)(entity, world) -> {
      });
      ServerTickEvents.END_WORLD_TICK
         .register(
            (EndWorldTick)world -> {
               if (Dedsafio4Manager.isEnabled("dia1_wardens_deep_dark")) {
                  ServerLevel sw = world;
                  if (world.dimension().equals(Level.OVERWORLD)) {
                     if (world.getGameTime() % 300L == 0L) {
                        for (ServerPlayer player : world.players()) {
                           if (!player.isSpectator()
                              && !player.isCreative()
                              && sw.getBiome(player.blockPosition()).is(Biomes.DEEP_DARK)
                              && sw.getRandom().nextInt(5) == 0) {
                              BlockPos spawnPos = findGroundPos(
                                 sw,
                                 player.blockPosition()
                                    .offset(sw.getRandom().nextIntBetweenInclusive(-15, 15), 0, sw.getRandom().nextIntBetweenInclusive(-15, 15))
                              );
                              if (spawnPos != null && sw.getBiome(spawnPos).is(Biomes.DEEP_DARK)) {
                                 Warden warden = (Warden)EntityType.WARDEN.create(sw);
                                 if (warden != null) {
                                    warden.moveTo((double)spawnPos.getX() + 0.5, (double)spawnPos.getY(), (double)spawnPos.getZ() + 0.5, 0.0F, 0.0F);
                                    sw.addFreshEntityWithPassengers(warden);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         );
   }

   private static void registerTreeSaplings() {
   }

   private static BlockPos findGroundPos(ServerLevel world, BlockPos start) {
      int topY = Math.min(world.getMaxBuildHeight(), start.getY() + 8);
      BlockPos check = new BlockPos(start.getX(), topY, start.getZ());

      for (int dy = 0; dy < 20; dy++) {
         BlockPos above = check.above(dy);
         BlockPos at = check.above(dy + 1);
         if (world.getBlockState(above).isRedstoneConductor(world, above) && !world.getBlockState(at).isRedstoneConductor(world, at)) {
            return at;
         }
      }

      for (int dyx = 0; dyx > -30; dyx--) {
         BlockPos below = start.above(dyx - 1);
         BlockPos at = start.above(dyx);
         if (world.getBlockState(below).isRedstoneConductor(world, below) && !world.getBlockState(at).isRedstoneConductor(world, at)) {
            return at;
         }
      }

      return null;
   }
}
