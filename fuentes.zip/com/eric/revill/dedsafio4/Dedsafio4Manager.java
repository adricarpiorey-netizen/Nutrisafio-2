package com.eric.revill.dedsafio4;

import com.eric.revill.event.RedEventManager;
import com.eric.revill.event.RevillTask;
import com.eric.revill.network.RevillNetworking;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;

public final class Dedsafio4Manager {
   private static final Set<UUID> ACTIVE_SPECTATOR_MODE = new HashSet<>();
   private static final Set<UUID> ACTIVE_ROULETTE = new HashSet<>();
   private static final int ROULETTE_DURATION_TICKS = 280;
   private static int rouletteTicksRemaining;
   private static String pendingRouletteColor;
   private static String pendingRouletteText;
   private static String pendingNutriaAnnouncementText;
   private static String pendingQueuedChangeId;
   private static boolean startRevillAfterRoulette;
   private static boolean nutriaAnimationPending;
   private static boolean revillDeathAnimationPending;
   private static final Map<String, Boolean> ENABLED_CHANGES = new HashMap<>();
   private static final List<Dedsafio4Manager.Dedsafio4Change> ALL_CHANGES = createChanges();
   private static final String[] COLOR_KEYS = new String[]{"roja", "red", "verde", "green", "naranja", "orange", "rosada", "rosa", "pink"};

   private Dedsafio4Manager() {
   }

   public static List<Dedsafio4Manager.Dedsafio4Change> getAllChanges() {
      return new ArrayList<>(ALL_CHANGES);
   }

   public static List<Dedsafio4Manager.Dedsafio4Change> getChangesForDay(int day) {
      List<Dedsafio4Manager.Dedsafio4Change> result = new ArrayList<>();

      for (Dedsafio4Manager.Dedsafio4Change change : ALL_CHANGES) {
         if (change.day() == day) {
            result.add(change);
         }
      }

      return result;
   }

   public static boolean isEnabled(String id) {
      return ENABLED_CHANGES.getOrDefault(id, false);
   }

   public static void disableChange(String id) {
      ENABLED_CHANGES.put(id, false);
   }

   public static void openMenu(ServerPlayer player) {
      if (player != null) {
         ServerPlayNetworking.send(player, Dedsafio4Networking.OPEN_MENU, PacketByteBufs.empty());
      }
   }

   public static void activateChange(MinecraftServer server, String id) {
      Dedsafio4Manager.Dedsafio4Change change = findById(id);
      if (change != null) {
         pendingQueuedChangeId = change.id();
         String announcementText = change.description() != null && !change.description().isBlank() ? change.description() : change.rouletteText();
         broadcastRoulette(server, "naranja", announcementText);
      }
   }

   public static void startRoulette(MinecraftServer server, String rawColor) {
      startRoulette(server, rawColor, "La ruleta ha elegido esta zona.", false);
   }

   public static void startRoulette(MinecraftServer server, String rawColor, String resultText) {
      startRoulette(server, rawColor, resultText, false);
   }

   public static void startRevillRoulette(MinecraftServer server) {
      startRevillRoulette(server, null);
   }

   public static void startRevillRoulette(MinecraftServer server, String customMessage) {
      startRevillRoulette(server, RevillTask.BUNKER, customMessage);
   }

   public static void startRevillRoulette(MinecraftServer server, RevillTask task, String customMessage) {
      RevillTask selectedTask = task == null ? RevillTask.BUNKER : task;
      startRoulette(server, "roja", selectedTask.buildAnnouncement(customMessage), true);
   }

   private static void startRoulette(MinecraftServer server, String rawColor, String resultText, boolean launchRevill) {
      if (server != null) {
         String color = normalize(rawColor);
         if (!isSupportedColor(color)) {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
               player.displayClientMessage(Component.literal("Color no válido. Usa uno de: roja, verde, naranja, rosada."), false);
            }
         } else {
            color = canonicalColor(color);
            ACTIVE_ROULETTE.clear();

            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
               ACTIVE_ROULETTE.add(player.getUUID());
               playCustomSound(player, "ruleta");
            }

            pendingRouletteColor = color;
            pendingRouletteText = resultText;
            startRevillAfterRoulette = launchRevill;
            nutriaAnimationPending = false;
            revillDeathAnimationPending = false;
            pendingNutriaAnnouncementText = null;
            rouletteTicksRemaining = 280;
            RevillNetworking.sendRoulette(server, color, resultText);
         }
      }
   }

   public static boolean handleDeath(ServerPlayer player, DamageSource source, float amount) {
      if (player != null && !player.isSpectator()) {
         Vec3 pos = player.position();
         ServerLevel world = player.serverLevel();
         String reason = resolveDeathReason(source);
         ACTIVE_SPECTATOR_MODE.add(player.getUUID());
         player.setGameMode(GameType.SPECTATOR);
         player.setHealth(player.getMaxHealth());
         player.getAbilities().flying = false;
         player.clearFire();
         player.fallDistance = 0.0F;
         player.getFoodData().setFoodLevel(20);
         if (world != null) {
            player.teleportTo(world, pos.x, pos.y, pos.z, player.getYRot(), player.getXRot());
         }

         playCustomSound(player, "muerte");
         MinecraftServer server = player.getServer();
         if (server != null) {
            server.execute(() -> ServerPlayNetworking.send(player, Dedsafio4Networking.DEATH_ANIMATION, PacketByteBufs.empty()));
         } else {
            ServerPlayNetworking.send(player, Dedsafio4Networking.DEATH_ANIMATION, PacketByteBufs.empty());
         }

         for (ServerPlayer viewer : player.getServer().getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeUtf(player.getGameProfile().getName());
            buf.writeUtf(reason);
            buf.writeBoolean(viewer.getUUID().equals(player.getUUID()));
            ServerPlayNetworking.send(viewer, Dedsafio4Networking.DEATH_ACTIONBAR, buf);
         }

         return true;
      } else {
         return false;
      }
   }

   public static boolean cancelPendingRevillRoulette(MinecraftServer server) {
      if ((rouletteTicksRemaining <= 0 || !startRevillAfterRoulette) && !revillDeathAnimationPending) {
         return false;
      } else {
         rouletteTicksRemaining = 0;
         pendingRouletteColor = null;
         pendingRouletteText = null;
         startRevillAfterRoulette = false;
         revillDeathAnimationPending = false;
         RevillNetworking.sendStopEvent(server);
         return true;
      }
   }

   public static void tick(MinecraftServer server) {
      if (server != null) {
         if (rouletteTicksRemaining > 0 && --rouletteTicksRemaining == 0) {
            finishRoulette(server);
         }

         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (ACTIVE_SPECTATOR_MODE.contains(player.getUUID())) {
               if (player.isDeadOrDying() || player.getHealth() <= 0.0F) {
                  reviveIntoSpectator(player);
               } else if (player.gameMode.getGameModeForPlayer() != GameType.SPECTATOR) {
                  player.setGameMode(GameType.SPECTATOR);
               }
            }
         }
      }
   }

   public static void clearRouletteState(MinecraftServer server) {
      ACTIVE_ROULETTE.clear();
      ACTIVE_SPECTATOR_MODE.clear();
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.isSpectator()) {
               player.setGameMode(GameType.SURVIVAL);
            }
         }
      }
   }

   public static void reviveIntoSpectator(ServerPlayer player) {
      if (player != null) {
         ACTIVE_SPECTATOR_MODE.add(player.getUUID());
         player.setHealth(player.getMaxHealth());
         player.getAbilities().flying = false;
         player.setGameMode(GameType.SPECTATOR);
         player.clearFire();
         player.fallDistance = 0.0F;
         player.getFoodData().setFoodLevel(20);
      }
   }

   public static void restorePlayerGameMode(ServerPlayer player, GameType mode) {
      if (player != null) {
         ACTIVE_SPECTATOR_MODE.remove(player.getUUID());
         if (mode != null) {
            player.setGameMode(mode);
         }
      }
   }

   private static void applyChange(MinecraftServer server, Dedsafio4Manager.Dedsafio4Change change) {
      if (server != null && change != null) {
         ENABLED_CHANGES.put(change.id(), true);
         if ("dia6_animales_extintos".equals(change.id())) {
            DifficultyEffects.extinguishAnimals(server);
         }

         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.displayClientMessage(
               Component.literal("Cambio aplicado: " + change.title()).withStyle(style -> style.withBold(true).withColor(TextColor.fromRgb(16766282))), false
            );
         }
      }
   }

   private static String resolveDeathReason(DamageSource source) {
      if (source == null) {
         return "muerte";
      } else if (source.is(DamageTypes.DROWN)) {
         return "ahogamiento";
      } else if (source.is(DamageTypes.FELL_OUT_OF_WORLD)) {
         return "caída del mundo";
      } else {
         String name = source.getMsgId();
         if (name != null && !name.isBlank()) {
            String lower = name.toLowerCase(Locale.ROOT);
            if (lower.contains("suffocate") || lower.contains("wall") || lower.contains("asfix")) {
               return "asfixia";
            } else {
               return !lower.contains("fire") && !lower.contains("lava") && !lower.contains("burn") ? name : "fuego";
            }
         } else {
            return "muerte";
         }
      }
   }

   private static void broadcastRoulette(MinecraftServer server, String color, String text) {
      startRoulette(server, color, text, false);
   }

   private static void finishRoulette(MinecraftServer server) {
      String color = pendingRouletteColor;
      String result = pendingRouletteText;
      boolean launchRevill = startRevillAfterRoulette;
      pendingRouletteColor = null;
      pendingRouletteText = null;
      startRevillAfterRoulette = false;
      if (color != null && result != null) {
         String displayText = sanitizeRouletteDisplayText(result);
         if ("rosada".equals(color) && !launchRevill) {
            pendingNutriaAnnouncementText = displayText;
            nutriaAnimationPending = true;
            RevillNetworking.sendNutriaAnimation(server);
         } else {
            RevillTask revillTask = launchRevill ? RedEventManager.INSTANCE.getPendingTask() : null;
            String announcementMessage = buildRouletteChatMessage(color, displayText, launchRevill, revillTask);
            Component announcement = Component.literal(announcementMessage);

            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
               player.displayClientMessage(announcement, false);
            }

            if (launchRevill || "verde".equals(color)) {
               String cardMessage = buildRouletteCardMessage(color, displayText, launchRevill, revillTask);
               RevillNetworking.sendRouletteAnnouncement(server, color, cardMessage);
            }
         }

         if (pendingQueuedChangeId != null) {
            Dedsafio4Manager.Dedsafio4Change queuedChange = findById(pendingQueuedChangeId);
            if (queuedChange != null) {
               applyChange(server, queuedChange);
            }

            pendingQueuedChangeId = null;
         }

         if (launchRevill) {
            revillDeathAnimationPending = true;
            RevillNetworking.sendRevillIntroDeath(server);
         }
      }
   }

   public static void finishNutriaAnnouncement(MinecraftServer server) {
      String explanation = pendingNutriaAnnouncementText;
      pendingNutriaAnnouncementText = null;
      if (nutriaAnimationPending && server != null && explanation != null) {
         nutriaAnimationPending = false;
         String chatMessage = buildRouletteChatMessage("rosada", explanation, false, null);

         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.displayClientMessage(Component.literal(chatMessage), false);
         }

         RevillNetworking.sendRouletteAnnouncement(server, "rosada", buildRouletteCardMessage("rosada", explanation, false, null));
      }
   }

   public static void finishRevillIntro(MinecraftServer server) {
      if (revillDeathAnimationPending && server != null) {
         revillDeathAnimationPending = false;
         RedEventManager.INSTANCE.beginRedEvent(server);
      }
   }

   private static String buildRouletteChatMessage(String color, String displayText, boolean isRevill, RevillTask task) {
      String body = cleanAnnouncementBody(displayText);
      String colorCode = rouletteFormattingCode(color);
      if ("verde".equals(color)) {
         return colorCode + body;
      } else {
         String title = isRevill
            ? "Momento Revill: " + (task == null ? RevillTask.BUNKER.shortTitle() : task.shortTitle())
            : ("rosada".equals(color) ? "Momento nutria" : "Cambio de dificultad");
         return colorCode + "§l⩥ §k||§r " + colorCode + "§l" + title + " §k||§r\n\n" + colorCode + body;
      }
   }

   private static String buildRouletteCardMessage(String color, String displayText, boolean isRevill, RevillTask task) {
      String body = cleanAnnouncementBody(displayText);
      if ("verde".equals(color)) {
         return body;
      } else {
         String title = isRevill
            ? "Momento Revill: " + (task == null ? RevillTask.BUNKER.shortTitle() : task.shortTitle())
            : ("rosada".equals(color) ? "Momento nutria" : "Cambio de dificultad");
         return "⩥ || " + title + " ||\n\n" + body;
      }
   }

   private static String rouletteFormattingCode(String color) {
      return switch (color) {
         case "roja" -> "§c";
         case "verde" -> "§a";
         case "naranja" -> "§6";
         case "rosada" -> "§d";
         default -> "§e";
      };
   }

   private static String cleanAnnouncementBody(String displayText) {
      String body = displayText == null ? "" : displayText.trim();
      body = body.replaceFirst("(?i)^ruleta\\s+[a-záéíóúüñ]+\\s*[-–:]?\\s*", "");
      body = body.replaceAll("§[0-9A-FK-ORa-fk-or]", "");
      body = body.replaceAll("\\s+", " ").trim();
      return body.isBlank()
         ? "El evento ha comenzado. Seguid las instrucciones y preparaos para sobrevivir. ADVERTENCIA: permaneced atentos al objetivo."
         : body;
   }

   private static String sanitizeRouletteDisplayText(String result) {
      return result != null && !result.isBlank() ? result.trim() : "";
   }

   private static void playCustomSound(ServerPlayer player, String soundName) {
      ResourceLocation id = new ResourceLocation("revill", soundName);
      player.playNotifySound(SoundEvent.createVariableRangeEvent(id), SoundSource.MASTER, 1.0F, 1.0F);
   }

   private static Dedsafio4Manager.Dedsafio4Change findById(String id) {
      for (Dedsafio4Manager.Dedsafio4Change change : ALL_CHANGES) {
         if (change.id().equals(id)) {
            return change;
         }
      }

      return null;
   }

   private static String normalize(String rawColor) {
      return rawColor == null ? "" : rawColor.trim().toLowerCase(Locale.ROOT).replace("-", "").replace("_", "");
   }

   private static String canonicalColor(String color) {
      return switch (color) {
         case "red" -> "roja";
         case "green" -> "verde";
         case "orange" -> "naranja";
         case "rosa", "pink" -> "rosada";
         default -> color;
      };
   }

   private static boolean isSupportedColor(String color) {
      for (String key : COLOR_KEYS) {
         if (key.equals(color)) {
            return true;
         }
      }

      return false;
   }

   private static List<Dedsafio4Manager.Dedsafio4Change> createChanges() {
      List<Dedsafio4Manager.Dedsafio4Change> changes = new ArrayList<>();
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_creepers_electricos",
            1,
            "Creepers Eléctricos",
            "Revill ha electrificado a los Creepers! Los Creepers Normales han sido modificados por Creepers Eléctricos. Con el equipamiento que tenemos, sólo podemos sobrevivir a su explosión utilizando un escudo.",
            "naranja",
            "Ruleta Naranja - Cambio de dificultad"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_ender_pearls_ignoran_armor",
            1,
            "Ender Pearls dañinas",
            "ReviiL corrompió la composición de las Ender Pearls. A partir de ahora, su daño ignora la armadura.",
            "naranja",
            "ReviiL corrompió la composición de las Ender Pearls. A partir de ahora, su daño ignora la armadura."
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_wardens_sculk",
            1,
            "Wardens dejan Sculk Shrieker",
            "ReviiL corrompió el alma de los Wardens. A partir de ahora, al morir dejan un Sculk Shrieker.",
            "naranja",
            "Cambio de dificultad — Wardens ahora dejan Sculk Shrieker al morir"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_respirar_bajo_agua",
            1,
            "Respirar bajo el agua",
            "Revill alteró las corrientes de agua. Las puertas y trampillas ya no pueden utilizarse para respirar bajo el agua.",
            "naranja",
            "Cambio de dificultad — Respirar bajo el agua"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_sin_golems",
            1,
            "Sin Gólems",
            "Revill lanzó una maldición que impide que las calabazas cobren vida. Los Gólems de Hierro y de Nieve ya no pueden ser invocados.",
            "naranja",
            "Cambio de dificultad — Sin Gólems de Hierro ni de Nieve"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_no_leche",
            1,
            "Sin leche",
            "REviil ordena a todas las vacas y, a partir de ahora, los jugadores ya no pueden obtener leche de ellas.",
            "naranja",
            "Cambio de dificultad — Ya no se puede sacar leche a las vacas"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_wardens_deep_dark",
            1,
            "Wardens Deep Dark",
            "REviil altera la genética de los Wardens. A partir de ahora pueden aparecer naturalmente en el Deep Dark.",
            "naranja",
            "Cambio de dificultad — Wardens en el Deep Dark"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia1_arboles_sin_brotes",
            1,
            "Árboles sin brotes",
            "Los árboles dejan de soltar brotes, por lo que replantar ya no es una opción.",
            "naranja",
            "Cambio de dificultad — Los árboles dejan de soltar brotes"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia2_zombies_trepadores",
            2,
            "Zombies trepadores",
            "Cuando los zombies aparecen hay un 50% de probabilidad de que puedan escalar paredes como las Arañas y sean inmunes al sol.",
            "naranja",
            "Cambio de dificultad — Zombies trepadores"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia2_blazes_nether",
            2,
            "Blazes en el Nether",
            "El Inframundo no descansa. Ahora los Blaze aparecen naturalmente en el Nether.",
            "naranja",
            "Cambio de dificultad — Blazes en el Nether"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia3_ender_pearls_damage10",
            3,
            "Ender Pearls más dañinas",
            "ReviiL ha utilizado el poder de la Ruleta para corromper la composición de las Ender Pearls. Ahora su daño aumentó a 10.",
            "naranja",
            "Cambio de dificultad — Ender Pearls más dañinas"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia3_magma_letal",
            3,
            "Bloques de Magma letales",
            "El calor de las capas bajas es insoportable. Ahora los Bloques de Magma hacen siete mil millones de cuatrillones de daño. El daño también se aplica al tocar cualquiera de las caras del bloque vertical u horizontalmente.",
            "naranja",
            "Cambio de dificultad — Bloques de Magma letales"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia4_aranas_cueva",
            4,
            "Arañas de Cueva",
            "Al romper una Tela de Araña existe la probabilidad de que salga una Araña de Cueva.",
            "naranja",
            "Cambio de dificultad — Arañas de Cueva al romper telarañas"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia4_zombies_mejorados",
            4,
            "Zombies mejorados",
            "ReviiL está experimentando con los Zombies. Ahora todos pueden escalar, no se queman con el sol y spaunean con una Espada de Hierro con Filo V.",
            "naranja",
            "Cambio de dificultad — Zombies mejorados"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia5_zombies_nether",
            5,
            "Zombies en el Nether",
            "Ahora los Zombies aparecen en el Nether, sin importar la luz.",
            "naranja",
            "Cambio de dificultad — Zombies en el Nether"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia5_bogged_noche",
            5,
            "Esqueletos Bogged",
            "A partir de este momento los Esqueletos Bogged (veneno) aparecen durante la noche.",
            "naranja",
            "Cambio de dificultad — Esqueletos Bogged durante la noche"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia5_stray_noche",
            5,
            "Esqueletos Stray",
            "A partir de este momento los Esqueletos Stray pueden salir durante la noche en el Overworld.",
            "naranja",
            "Cambio de dificultad — Esqueletos Stray en el Overworld"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia5_luna_mata",
            5,
            "Mirar la Luna mata",
            "Si alguien mira a la Luna directamente recibirá daño instantáneamente y morirá. Este cambio permanecerá activo hasta que alguien muera por esa razón.",
            "naranja",
            "Cambio de dificultad — Mirar la Luna causa la muerte"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia6_wither_skeletons_nether",
            6,
            "Wither Skeleton en el Nether",
            "Los Wither Skeleton ahora aparecen naturalmente en el Nether.",
            "naranja",
            "Cambio de dificultad — Wither Skeleton en el Nether"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia6_fuego_lava_triple",
            6,
            "Daño de Lava y Fuego",
            "La Lava y el Fuego han triplicado su daño.",
            "naranja",
            "Cambio de dificultad — Daño de Lava y Fuego"
         )
      );
      changes.add(
         new Dedsafio4Manager.Dedsafio4Change(
            "dia6_animales_extintos",
            6,
            "Extinción de los animales",
            "ReviiL ha lanzado un gas tóxico que afecta a los animales. Los animales fueron extintos. Ningún animal volverá a aparecer.",
            "naranja",
            "Cambio de dificultad — Extinción de los animales"
         )
      );
      return changes;
   }

   public static record Dedsafio4Change(String id, int day, String title, String description, String rouletteColor, String rouletteText) {
   }
}
