package com.eric.revill.dedsafio4;

import net.minecraft.resources.ResourceLocation;

public final class Dedsafio4Networking {
   public static final ResourceLocation OPEN_MENU = new ResourceLocation("revill", "dedsafio4_open_menu");
   public static final ResourceLocation APPLY_CHANGE = new ResourceLocation("revill", "dedsafio4_apply_change");
   public static final ResourceLocation CUSTOM_ROULETTE = new ResourceLocation("revill", "dedsafio4_custom_roulette");
   public static final ResourceLocation START_REVILL = new ResourceLocation("revill", "dedsafio4_start_revill");
   public static final ResourceLocation STOP_REVILL = new ResourceLocation("revill", "dedsafio4_stop_revill");
   public static final ResourceLocation DEATH_ANIMATION = new ResourceLocation("revill", "dedsafio4_death_animation");
   public static final ResourceLocation DEATH_ACTIONBAR = new ResourceLocation("revill", "dedsafio4_death_actionbar");
   public static final ResourceLocation FUSION_TOGGLE = new ResourceLocation("revill", "dedsafio4_fusion_toggle");

   private Dedsafio4Networking() {
   }
}
