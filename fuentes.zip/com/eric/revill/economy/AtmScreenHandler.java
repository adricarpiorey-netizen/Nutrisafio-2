package com.eric.revill.economy;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public final class AtmScreenHandler extends AbstractContainerMenu {
   public static final int CONFIRM_DEPOSIT_BUTTON = 0;
   public static final MenuType<AtmScreenHandler> TYPE = ScreenHandlerRegistry.registerExtended(
      new ResourceLocation("dedsafio-4-mechanics", "atm_deposit"), (syncId, inventory, buf) -> new AtmScreenHandler(syncId, inventory, new SimpleContainer(9))
   );
   private final Inventory playerInventory;
   private final SimpleContainer depositInventory;

   public static MenuType<AtmScreenHandler> initialize() {
      return TYPE;
   }

   public AtmScreenHandler(int syncId, Inventory playerInventory, SimpleContainer depositInventory) {
      super(TYPE, syncId);
      this.playerInventory = playerInventory;
      this.depositInventory = depositInventory;
      checkContainerSize(depositInventory, 9);

      for (int row = 0; row < 3; row++) {
         for (int column = 0; column < 3; column++) {
            int index = row * 3 + column;
            this.addSlot(new AtmScreenHandler.CurrencySlot(depositInventory, index, 0, 0));
         }
      }

      for (int row = 0; row < 3; row++) {
         for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(playerInventory, column + row * 9 + 9, 0, 0));
         }
      }

      for (int column = 0; column < 9; column++) {
         this.addSlot(new Slot(playerInventory, column, 0, 0));
      }
   }

   public static ExtendedScreenHandlerFactory depositFactory() {
      return new ExtendedScreenHandlerFactory() {
         public void writeScreenOpeningData(ServerPlayer player, FriendlyByteBuf buf) {
         }

         public Component getDisplayName() {
            return Component.literal("Cajero Automático");
         }

         public AbstractContainerMenu createMenu(int syncId, Inventory inventory, Player player) {
            return new AtmScreenHandler(syncId, inventory, new SimpleContainer(9));
         }
      };
   }

   public boolean clickMenuButton(Player player, int id) {
      if (id == 0 && player instanceof ServerPlayer serverPlayer) {
         int[] deposited = this.getDepositAmounts();

         for (int slot = 0; slot < this.depositInventory.getContainerSize(); slot++) {
            ItemStack stack = this.depositInventory.getItem(slot);
            if (CurrencyType.fromStack(stack) != null) {
               this.depositInventory.setItem(slot, ItemStack.EMPTY);
            }
         }

         for (CurrencyType type : CurrencyType.values()) {
            CurrencyManager.addCurrency(serverPlayer.getServer(), serverPlayer.getUUID(), type, deposited[type.ordinal()]);
         }

         serverPlayer.displayClientMessage(Component.literal("Deditas ingresadas en la cuenta."), true);
         serverPlayer.closeContainer();
         return true;
      } else {
         return false;
      }
   }

   public int[] getDepositAmounts() {
      int[] deposited = new int[CurrencyType.values().length];

      for (int slot = 0; slot < this.depositInventory.getContainerSize(); slot++) {
         ItemStack stack = this.depositInventory.getItem(slot);
         CurrencyType type = CurrencyType.fromStack(stack);
         if (type != null) {
            deposited[type.ordinal()] += stack.getCount();
         }
      }

      int blueAmount = deposited[CurrencyType.AZUL.ordinal()];
      deposited[CurrencyType.AZUL.ordinal()] = blueAmount % 100;
      deposited[CurrencyType.VERDE.ordinal()] += blueAmount / 100;
      return deposited;
   }

   public ItemStack quickMoveStack(Player player, int slotIndex) {
      if (slotIndex >= 0 && slotIndex < this.slots.size()) {
         Slot slot = (Slot)this.slots.get(slotIndex);
         if (!slot.hasItem()) {
            return ItemStack.EMPTY;
         } else {
            ItemStack original = slot.getItem();
            ItemStack result = original.copy();
            if (slotIndex < 9) {
               if (!this.moveItemStackTo(original, 9, this.slots.size(), true)) {
                  return ItemStack.EMPTY;
               }
            } else if (CurrencyType.fromStack(original) == null || !this.moveItemStackTo(original, 0, 9, false)) {
               return ItemStack.EMPTY;
            }

            if (original.isEmpty()) {
               slot.setByPlayer(ItemStack.EMPTY);
            } else {
               slot.setChanged();
            }

            return result;
         }
      } else {
         return ItemStack.EMPTY;
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public void removed(Player player) {
      super.removed(player);
      if (!player.level().isClientSide) {
         for (int index = 0; index < this.depositInventory.getContainerSize(); index++) {
            ItemStack stack = this.depositInventory.removeItemNoUpdate(index);
            if (!stack.isEmpty() && !this.playerInventory.add(stack)) {
               player.drop(stack, false);
            }
         }

         this.depositInventory.stopOpen(player);
      }
   }

   public void layoutSlots(int[][] positions) {
      int expected = 45;
      if (positions.length == expected && this.slots.size() == expected) {
         for (int index = 0; index < expected; index++) {
            Slot old = (Slot)this.slots.get(index);
            Slot replacement = (Slot)(index < 9
               ? new AtmScreenHandler.CurrencySlot(this.depositInventory, index, positions[index][0], positions[index][1])
               : new Slot(this.playerInventory, old.getContainerSlot(), positions[index][0], positions[index][1]));
            replacement.index = old.index;
            this.slots.set(index, replacement);
         }
      }
   }

   private static final class CurrencySlot extends Slot {
      private CurrencySlot(Container inventory, int index, int x, int y) {
         super(inventory, index, x, y);
      }

      public boolean mayPlace(ItemStack stack) {
         return CurrencyType.fromStack(stack) != null;
      }

      public int getMaxStackSize() {
         return 99;
      }

      public int getMaxStackSize(ItemStack stack) {
         return CurrencyType.fromStack(stack) == null ? super.getMaxStackSize(stack) : stack.getMaxStackSize();
      }
   }
}
