package com.eric.revill.economy;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class EconomyNetworking {
   public static final ResourceLocation OPEN_ATM = new ResourceLocation("dedsafio-4-mechanics", "atm_open");
   public static final ResourceLocation OPEN_WITHDRAW = new ResourceLocation("dedsafio-4-mechanics", "atm_withdraw_open");
   public static final ResourceLocation OPEN_WITHDRAW_UI = new ResourceLocation("dedsafio-4-mechanics", "atm_withdraw_ui");
   public static final ResourceLocation OPEN_DEPOSIT = new ResourceLocation("dedsafio-4-mechanics", "atm_deposit_open");
   public static final ResourceLocation OPEN_COINS_MENU = new ResourceLocation("dedsafio-4-mechanics", "coins_menu_open");
   public static final ResourceLocation COINS_ACTION = new ResourceLocation("dedsafio-4-mechanics", "coins_action");
   public static final ResourceLocation WITHDRAW = new ResourceLocation("dedsafio-4-mechanics", "atm_withdraw");
   public static final ResourceLocation BALANCE_SYNC = new ResourceLocation("dedsafio-4-mechanics", "currency_sync");

   private EconomyNetworking() {
   }

   public static void registerServer() {
      ServerPlayNetworking.registerGlobalReceiver(
         OPEN_DEPOSIT, (server, player, handler, buf, responseSender) -> server.execute(() -> player.openMenu(AtmScreenHandler.depositFactory()))
      );
      ServerPlayNetworking.registerGlobalReceiver(OPEN_WITHDRAW, (server, player, handler, buf, responseSender) -> server.execute(() -> {
            syncBalances(player, CurrencyManager.getCurrencies(server, player.getUUID()));
            ServerPlayNetworking.send(player, OPEN_WITHDRAW_UI, PacketByteBufs.empty());
         }));
      ServerPlayNetworking.registerGlobalReceiver(COINS_ACTION, (server, player, handler, buf, responseSender) -> {
         int action = buf.readVarInt();
         int currencyIndex = buf.readVarInt();
         int amount = buf.readVarInt();
         server.execute(() -> handleCoinsAction(player, action, currencyIndex, amount));
      });
      ServerPlayNetworking.registerGlobalReceiver(WITHDRAW, (server, player, handler, buf, responseSender) -> {
         int blue = buf.readVarInt();
         int red = buf.readVarInt();
         int green = buf.readVarInt();
         server.execute(() -> withdraw(player, blue, red, green));
      });
   }

   public static void openAtm(ServerPlayer player) {
      ServerPlayNetworking.send(player, OPEN_ATM, PacketByteBufs.empty());
   }

   public static void openCoinsMenu(ServerPlayer player) {
      ServerPlayNetworking.send(player, OPEN_COINS_MENU, PacketByteBufs.empty());
   }

   public static void syncBalances(ServerPlayer player, int[] balances) {
      FriendlyByteBuf buf = PacketByteBufs.create();

      for (int balance : balances) {
         buf.writeVarInt(balance);
      }

      ServerPlayNetworking.send(player, BALANCE_SYNC, buf);
   }

   private static void handleCoinsAction(ServerPlayer player, int action, int currencyIndex, int amount) {
      CurrencyType[] types = CurrencyType.values();
      if (currencyIndex < 0 || currencyIndex >= types.length) {
         currencyIndex = 0;
      }

      CurrencyType type = types[currencyIndex];
      switch (action) {
         case 0:
            CurrencyManager.addCurrency(player.getServer(), player.getUUID(), type, Math.max(1, amount));
            player.displayClientMessage(Component.literal("Añadidas " + Math.max(1, amount) + " deditas " + type.key() + " a tu cuenta."), false);
            break;
         case 1:
            int removal = Math.max(1, amount);
            if (!CurrencyManager.subtractCurrency(player.getServer(), player.getUUID(), type, removal)) {
               player.displayClientMessage(Component.literal("No tienes suficientes deditas " + type.key() + " para quitar."), false);
               return;
            }

            player.displayClientMessage(Component.literal("Quitadas " + removal + " deditas " + type.key() + " de tu cuenta."), false);
            break;
         case 2:
            int[] balances = CurrencyManager.getCurrencies(player.getServer(), player.getUUID());
            player.displayClientMessage(Component.literal("Tu saldo: Azul " + balances[0] + " | Roja " + balances[1] + " | Verde " + balances[2]), false);
            break;
         default:
            player.displayClientMessage(Component.literal("Acción no válida."), false);
      }

      CurrencyManager.sync(player);
   }

   private static void withdraw(ServerPlayer player, int blue, int red, int green) {
      int[] requested = new int[]{blue, red, green};
      CurrencyType[] types = CurrencyType.values();

      for (int index = 0; index < requested.length; index++) {
         int amount = requested[index];
         if (amount < 0 || amount > CurrencyManager.getCurrency(player.getServer(), player.getUUID(), types[index])) {
            player.displayClientMessage(Component.literal("No tienes suficientes deditas en la cuenta."), true);
            CurrencyManager.sync(player);
            return;
         }
      }

      if (!canFitWithdrawal(player, requested, types)) {
         player.displayClientMessage(Component.literal("No tienes espacio suficiente en el inventario."), true);
      } else if (!CurrencyManager.subtractCurrencies(player.getServer(), player.getUUID(), requested)) {
         player.displayClientMessage(Component.literal("No tienes suficientes deditas en la cuenta."), true);
         CurrencyManager.sync(player);
      } else {
         for (int indexx = 0; indexx < requested.length; indexx++) {
            int amount = requested[indexx];
            if (amount != 0) {
               CurrencyType type = types[indexx];

               while (amount > 0) {
                  int stackSize = Math.min(amount, type.item().getMaxStackSize());
                  player.getInventory().add(new ItemStack(type.item(), stackSize));
                  amount -= stackSize;
               }
            }
         }

         CurrencyManager.sync(player);
      }
   }

   private static boolean canFitWithdrawal(ServerPlayer player, int[] amounts, CurrencyType[] types) {
      int emptySlots = 0;

      for (int slot = 0; slot < 36; slot++) {
         ItemStack stack = player.getInventory().getItem(slot);
         if (stack.isEmpty()) {
            emptySlots++;
         }
      }

      int requiredEmptySlots = 0;

      for (int index = 0; index < amounts.length; index++) {
         int remaining = amounts[index];
         Item item = types[index].item();

         for (int slotx = 0; slotx < 36 && remaining > 0; slotx++) {
            ItemStack stack = player.getInventory().getItem(slotx);
            if (stack.is(item)) {
               remaining -= stack.getMaxStackSize() - stack.getCount();
            }
         }

         remaining = Math.max(0, remaining);
         requiredEmptySlots += (remaining + item.getMaxStackSize() - 1) / item.getMaxStackSize();
      }

      return requiredEmptySlots <= emptySlots;
   }
}
