package com.eric.revill.network;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class RevillNetworking {
   public static final ResourceLocation EVENT_STATE = new ResourceLocation("revill", "event_state");
   public static final ResourceLocation ANNOUNCEMENT = new ResourceLocation("revill", "announcement");
   public static final ResourceLocation STOP_EVENT = new ResourceLocation("revill", "stop_event");
   public static final ResourceLocation ROULETTE = new ResourceLocation("revill", "roulette");
   public static final ResourceLocation ROULETTE_ANNOUNCEMENT = new ResourceLocation("revill", "roulette_announcement");
   public static final ResourceLocation NUTRIA_ANIMATION = new ResourceLocation("revill", "nutria_animation");
   public static final ResourceLocation NUTRIA_ANIMATION_COMPLETE = new ResourceLocation("revill", "nutria_animation_complete");
   public static final ResourceLocation REVILL_INTRO_DEATH = new ResourceLocation("revill", "revill_intro_death");
   public static final ResourceLocation REVILL_INTRO_COMPLETE = new ResourceLocation("revill", "revill_intro_complete");

   private RevillNetworking() {
   }

   public static void sendEventState(MinecraftServer server, boolean active, int remainingSeconds, boolean skyActive, boolean announcementActive) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeBoolean(active);
            buf.writeInt(remainingSeconds);
            buf.writeBoolean(skyActive);
            buf.writeBoolean(announcementActive);
            ServerPlayNetworking.send(player, EVENT_STATE, buf);
         }
      }
   }

   public static void sendAnnouncement(MinecraftServer server, int durationSeconds, double flashSpeed) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeInt(durationSeconds);
            buf.writeDouble(flashSpeed);
            ServerPlayNetworking.send(player, ANNOUNCEMENT, buf);
         }
      }
   }

   public static void sendStopEvent(MinecraftServer server) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeBoolean(false);
            ServerPlayNetworking.send(player, STOP_EVENT, buf);
         }
      }
   }

   public static void sendRoulette(MinecraftServer server, String color, String result) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeUtf(color);
            buf.writeUtf(result);
            ServerPlayNetworking.send(player, ROULETTE, buf);
         }
      }
   }

   public static void sendRouletteAnnouncement(MinecraftServer server, String color, String message) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeUtf(color == null ? "naranja" : color, 32);
            buf.writeUtf(message, 32767);
            ServerPlayNetworking.send(player, ROULETTE_ANNOUNCEMENT, buf);
         }
      }
   }

   public static void sendRouletteAnnouncement(MinecraftServer server, String message) {
      sendRouletteAnnouncement(server, "naranja", message);
   }

   public static void sendNutriaAnimation(MinecraftServer server) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ServerPlayNetworking.send(player, NUTRIA_ANIMATION, PacketByteBufs.empty());
         }
      }
   }

   public static void sendRevillIntroDeath(MinecraftServer server) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ServerPlayNetworking.send(player, REVILL_INTRO_DEATH, PacketByteBufs.empty());
         }
      }
   }
}
