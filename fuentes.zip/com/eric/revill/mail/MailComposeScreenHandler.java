package com.eric.revill.mail;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public final class MailComposeScreenHandler extends AbstractContainerMenu {
   public static final MenuType<MailComposeScreenHandler> TYPE = ScreenHandlerRegistry.registerExtended(
      new ResourceLocation("dedsafio-4-mechanics", "mail_compose"),
      (syncId, inventory, buf) -> new MailComposeScreenHandler(syncId, inventory, new SimpleContainer(9))
   );
   private final Inventory playerInventory;
   private final SimpleContainer attachments;

   public MailComposeScreenHandler(int syncId, Inventory playerInventory, SimpleContainer attachments) {
      super(TYPE, syncId);
      this.playerInventory = playerInventory;
      this.attachments = attachments;
      checkContainerSize(attachments, 9);

      for (int slot = 0; slot < 9; slot++) {
         this.addSlot(new Slot(attachments, slot, 0, 0));
      }

      for (int row = 0; row < 3; row++) {
         for (int column = 0; column < 9; column++) {
            this.addSlot(new Slot(playerInventory, column + row * 9 + 9, 0, 0));
         }
      }

      for (int column = 0; column < 9; column++) {
         this.addSlot(new Slot(playerInventory, column, 0, 0));
      }
   }

   public static ExtendedScreenHandlerFactory factory() {
      return new ExtendedScreenHandlerFactory() {
         public void writeScreenOpeningData(ServerPlayer player, FriendlyByteBuf buf) {
         }

         public Component getDisplayName() {
            return Component.literal("Enviar correo");
         }

         public AbstractContainerMenu createMenu(int syncId, Inventory inventory, Player player) {
            return new MailComposeScreenHandler(syncId, inventory, new SimpleContainer(9));
         }
      };
   }

   public static MenuType<MailComposeScreenHandler> initialize() {
      return TYPE;
   }

   public SimpleContainer getAttachments() {
      return this.attachments;
   }

   public void clearAttachments() {
      for (int index = 0; index < this.attachments.getContainerSize(); index++) {
         this.attachments.setItem(index, ItemStack.EMPTY);
      }
   }

   public void layoutSlots(int[][] positions) {
      if (positions.length == this.slots.size()) {
         for (int index = 0; index < positions.length; index++) {
            Slot old = (Slot)this.slots.get(index);
            Slot replacement = index < 9
               ? new Slot(this.attachments, index, positions[index][0], positions[index][1])
               : new Slot(this.playerInventory, old.getContainerSlot(), positions[index][0], positions[index][1]);
            replacement.index = old.index;
            this.slots.set(index, replacement);
         }
      }
   }

   public ItemStack quickMoveStack(Player player, int slotIndex) {
      if (slotIndex >= 0 && slotIndex < this.slots.size()) {
         Slot slot = (Slot)this.slots.get(slotIndex);
         if (!slot.hasItem()) {
            return ItemStack.EMPTY;
         } else {
            ItemStack original = slot.getItem();
            ItemStack result = original.copy();
            if (slotIndex < 9) {
               if (!this.moveItemStackTo(original, 9, this.slots.size(), true)) {
                  return ItemStack.EMPTY;
               }
            } else if (!this.moveItemStackTo(original, 0, 9, false)) {
               return ItemStack.EMPTY;
            }

            if (original.isEmpty()) {
               slot.setByPlayer(ItemStack.EMPTY);
            } else {
               slot.setChanged();
            }

            return result;
         }
      } else {
         return ItemStack.EMPTY;
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public void removed(Player player) {
      super.removed(player);
      if (!player.level().isClientSide) {
         for (int index = 0; index < this.attachments.getContainerSize(); index++) {
            ItemStack stack = this.attachments.removeItemNoUpdate(index);
            if (!stack.isEmpty() && !this.playerInventory.add(stack)) {
               player.drop(stack, false);
            }
         }

         this.attachments.stopOpen(player);
      }
   }
}
