package com.eric.revill.mail;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public final class MailNetworking {
   public static final ResourceLocation OPEN_COMPOSE = new ResourceLocation("dedsafio-4-mechanics", "mail_compose_open");
   public static final ResourceLocation RETURN_INBOX = new ResourceLocation("dedsafio-4-mechanics", "mail_return_inbox");
   public static final ResourceLocation SEND_MAIL = new ResourceLocation("dedsafio-4-mechanics", "mail_send");
   public static final ResourceLocation MARK_READ = new ResourceLocation("dedsafio-4-mechanics", "mail_mark_read");
   public static final ResourceLocation CLAIM_ITEMS = new ResourceLocation("dedsafio-4-mechanics", "mail_claim_items");
   public static final ResourceLocation INBOX_SYNC = new ResourceLocation("dedsafio-4-mechanics", "mail_inbox_sync");

   private MailNetworking() {
   }

   public static void registerServer() {
      ServerPlayNetworking.registerGlobalReceiver(
         OPEN_COMPOSE, (server, player, handler, buf, responseSender) -> server.execute(() -> player.openMenu(MailComposeScreenHandler.factory()))
      );
      ServerPlayNetworking.registerGlobalReceiver(RETURN_INBOX, (server, player, handler, buf, responseSender) -> server.execute(() -> {
            if (player.containerMenu instanceof MailComposeScreenHandler) {
               player.openMenu(MailInboxScreenHandler.inboxFactory());
            }
         }));
      ServerPlayNetworking.registerGlobalReceiver(SEND_MAIL, (server, player, handler, buf, responseSender) -> {
         String recipientName = buf.readUtf(64);
         String message = buf.readUtf(512);
         server.execute(() -> sendMail(player, recipientName, message));
      });
      ServerPlayNetworking.registerGlobalReceiver(MARK_READ, (server, player, handler, buf, responseSender) -> {
         int syncId = buf.readVarInt();
         int index = buf.readVarInt();
         server.execute(() -> updateMail(player, syncId, index, false));
      });
      ServerPlayNetworking.registerGlobalReceiver(CLAIM_ITEMS, (server, player, handler, buf, responseSender) -> {
         int syncId = buf.readVarInt();
         int index = buf.readVarInt();
         server.execute(() -> updateMail(player, syncId, index, true));
      });
   }

   public static void writeInbox(FriendlyByteBuf buf, List<Mail> mails) {
      int count = Math.min(mails.size(), 100);
      buf.writeVarInt(count);

      for (int index = 0; index < count; index++) {
         Mail mail = mails.get(index);
         buf.writeUtf(mail.getSenderName(), 64);
         buf.writeUtf(mail.getMessage(), 512);
         buf.writeBoolean(mail.isRead());
         int itemCount = Math.min(mail.getItems().size(), 9);
         buf.writeVarInt(itemCount);

         for (int itemIndex = 0; itemIndex < itemCount; itemIndex++) {
            buf.writeItem(mail.getItems().get(itemIndex));
         }
      }
   }

   public static List<MailInboxScreenHandler.MailView> readInbox(FriendlyByteBuf buf) {
      int count = Math.min(buf.readVarInt(), 100);
      List<MailInboxScreenHandler.MailView> mails = new ArrayList<>(count);

      for (int index = 0; index < count; index++) {
         String sender = buf.readUtf(64);
         String message = buf.readUtf(512);
         boolean read = buf.readBoolean();
         int itemCount = Math.min(buf.readVarInt(), 9);
         List<ItemStack> items = new ArrayList<>(itemCount);

         for (int itemIndex = 0; itemIndex < itemCount; itemIndex++) {
            items.add(buf.readItem());
         }

         mails.add(new MailInboxScreenHandler.MailView(sender, message, read, items));
      }

      return mails;
   }

   public static void syncInbox(ServerPlayer player, MailInboxScreenHandler handler) {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeVarInt(handler.containerId);
      writeInbox(buf, MailManager.INSTANCE.snapshot(player.getUUID()));
      ServerPlayNetworking.send(player, INBOX_SYNC, buf);
   }

   private static void sendMail(ServerPlayer sender, String recipientName, String message) {
      if (sender.containerMenu instanceof MailComposeScreenHandler composeHandler) {
         ServerPlayer recipient = sender.getServer().getPlayerList().getPlayerByName(recipientName.trim());
         if (recipient != null && !message.isBlank()) {
            List<ItemStack> attachments = new ArrayList<>();

            for (int slot = 0; slot < composeHandler.getAttachments().getContainerSize(); slot++) {
               ItemStack stack = composeHandler.getAttachments().getItem(slot);
               if (!stack.isEmpty()) {
                  attachments.add(stack.copy());
               }
            }

            MailManager.INSTANCE.send(recipient.getUUID(), sender.getUUID(), sender.getName().getString(), "Correo", message, attachments);
            composeHandler.clearAttachments();
            MailManager.INSTANCE.notifyRecipient(recipient, sender.getName().getString());
            sender.displayClientMessage(Component.literal("Correo enviado."), true);
            sender.closeContainer();
         } else {
            sender.displayClientMessage(Component.literal(recipient == null ? "Destinatario no conectado." : "El mensaje no puede estar vacío."), true);
         }
      }
   }

   private static void updateMail(ServerPlayer player, int syncId, int index, boolean claim) {
      if (player.containerMenu instanceof MailInboxScreenHandler inbox && inbox.containerId == syncId) {
         if (claim) {
            MailManager.INSTANCE.claimItems(player.getUUID(), index, player);
         } else {
            MailManager.INSTANCE.markRead(player.getUUID(), index);
         }

         syncInbox(player, inbox);
         return;
      }
   }
}
