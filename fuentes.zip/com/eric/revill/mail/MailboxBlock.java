package com.eric.revill.mail;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class MailboxBlock extends Block {
   public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
   private static final VoxelShape NORTH_SHAPE = createMailboxShape(Direction.NORTH);
   private static final VoxelShape EAST_SHAPE = createMailboxShape(Direction.EAST);
   private static final VoxelShape SOUTH_SHAPE = createMailboxShape(Direction.SOUTH);
   private static final VoxelShape WEST_SHAPE = createMailboxShape(Direction.WEST);

   public MailboxBlock(Properties settings) {
      super(settings);
      this.registerDefaultState((BlockState)((BlockState)this.getStateDefinition().any()).setValue(FACING, Direction.NORTH));
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{FACING});
   }

   public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
      return this.getFacingShape(state);
   }

   public VoxelShape getCollisionShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
      return this.getFacingShape(state);
   }

   private VoxelShape getFacingShape(BlockState state) {
      return switch ((Direction)state.getValue(FACING)) {
         case EAST -> EAST_SHAPE;
         case SOUTH -> SOUTH_SHAPE;
         case WEST -> WEST_SHAPE;
         default -> NORTH_SHAPE;
      };
   }

   private static VoxelShape createMailboxShape(Direction facing) {
      return Shapes.or(
         Shapes.or(rotateBox(2.0, 0.0, 11.0, 14.0, 9.0, 16.0, facing), rotateBox(2.0, 7.0, 10.0, 14.0, 12.0, 16.0, facing)),
         rotateBox(4.0, 5.0, 10.5, 12.0, 8.0, 11.0, facing)
      );
   }

   private static VoxelShape rotateBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Direction facing) {
      return switch (facing) {
         case EAST -> Block.box(16.0 - maxZ, minY, minX, 16.0 - minZ, maxY, maxX);
         case SOUTH -> Block.box(16.0 - maxX, minY, 16.0 - maxZ, 16.0 - minX, maxY, 16.0 - minZ);
         case WEST -> Block.box(minZ, minY, 16.0 - maxX, maxZ, maxY, 16.0 - minX);
         default -> Block.box(minX, minY, minZ, maxX, maxY, maxZ);
      };
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)this.defaultBlockState().setValue(FACING, context.getPlayer().getDirection().getOpposite());
   }

   public InteractionResult use(BlockState state, Level world, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
      if (world.isClientSide) {
         return InteractionResult.SUCCESS;
      } else {
         if (player instanceof ServerPlayer serverPlayer) {
            serverPlayer.openMenu(MailInboxScreenHandler.inboxFactory());
         }

         return InteractionResult.SUCCESS;
      }
   }
}
