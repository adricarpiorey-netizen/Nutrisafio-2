package com.eric.revill.waypoint;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class WaypointManager {
   public static final ResourceLocation SYNC_WAYPOINTS = new ResourceLocation("revill", "sync_waypoints");
   public static final ResourceLocation ADD_WAYPOINT = new ResourceLocation("revill", "add_waypoint");
   public static final ResourceLocation REMOVE_WAYPOINT = new ResourceLocation("revill", "remove_waypoint");
   public static final ResourceLocation EDIT_WAYPOINT = new ResourceLocation("revill", "edit_waypoint");
   private static final Map<String, Waypoint> WAYPOINTS = new LinkedHashMap<>();

   private WaypointManager() {
   }

   public static void addWaypoint(MinecraftServer server, Waypoint waypoint) {
      if (waypoint != null) {
         WAYPOINTS.put(waypoint.getId(), waypoint);
         syncToAll(server);
      }
   }

   public static void removeWaypoint(MinecraftServer server, String idOrName) {
      if (idOrName != null && !idOrName.isBlank()) {
         boolean removed = WAYPOINTS.remove(idOrName) != null;
         if (!removed) {
            String targetId = null;

            for (Waypoint wp : WAYPOINTS.values()) {
               if (wp.getName().equalsIgnoreCase(idOrName)) {
                  targetId = wp.getId();
                  break;
               }
            }

            if (targetId != null) {
               WAYPOINTS.remove(targetId);
               removed = true;
            }
         }

         if (removed) {
            syncToAll(server);
         }
      }
   }

   public static List<Waypoint> getAllWaypoints() {
      return Collections.unmodifiableList(new ArrayList<>(WAYPOINTS.values()));
   }

   public static void setBunkerWaypoint(MinecraftServer server, BlockPos pos, String dimension) {
      Waypoint bunkerWp = new Waypoint("bunker", "BÚNKER", pos, "bunker", -56798, dimension);
      addWaypoint(server, bunkerWp);
   }

   public static void syncToPlayer(ServerPlayer player) {
      if (player != null) {
         FriendlyByteBuf buf = encodeWaypoints();
         ServerPlayNetworking.send(player, SYNC_WAYPOINTS, buf);
      }
   }

   public static void syncToAll(MinecraftServer server) {
      if (server != null) {
         FriendlyByteBuf buf = encodeWaypoints();

         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ServerPlayNetworking.send(player, SYNC_WAYPOINTS, buf);
         }
      }
   }

   private static FriendlyByteBuf encodeWaypoints() {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeInt(WAYPOINTS.size());

      for (Waypoint wp : WAYPOINTS.values()) {
         buf.writeUtf(wp.getId());
         buf.writeUtf(wp.getName());
         buf.writeBlockPos(wp.getPos());
         buf.writeUtf(wp.getIcon());
         buf.writeInt(wp.getColor());
         buf.writeUtf(wp.getDimension());
      }

      return buf;
   }

   public static List<Waypoint> decodeWaypoints(FriendlyByteBuf buf) {
      List<Waypoint> list = new ArrayList<>();
      int count = buf.readInt();

      for (int i = 0; i < count; i++) {
         String id = buf.readUtf();
         String name = buf.readUtf();
         BlockPos pos = buf.readBlockPos();
         String icon = buf.readUtf();
         int color = buf.readInt();
         String dimension = buf.readUtf();
         list.add(new Waypoint(id, name, pos, icon, color, dimension));
      }

      return list;
   }
}
