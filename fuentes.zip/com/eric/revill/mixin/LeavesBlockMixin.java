package com.eric.revill.mixin;

import com.eric.revill.dedsafio4.Dedsafio4Manager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Block.class})
public abstract class LeavesBlockMixin {
   @Inject(
      method = {"getDroppedStacks(Lnet/minecraft/block/BlockState;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/entity/BlockEntity;)Ljava/util/List;"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private static void dedsafio4$suppressSaplingDrops(
      BlockState state, ServerLevel world, BlockPos pos, BlockEntity blockEntity, CallbackInfoReturnable<List<ItemStack>> cir
   ) {
      if (state.getBlock() instanceof LeavesBlock) {
         if (Dedsafio4Manager.isEnabled("dia1_arboles_sin_brotes")) {
            List<ItemStack> original = (List<ItemStack>)cir.getReturnValue();
            List<ItemStack> filtered = new ArrayList<>();

            for (ItemStack stack : original) {
               if (!stack.is(ItemTags.SAPLINGS)) {
                  filtered.add(stack);
               }
            }

            cir.setReturnValue(filtered);
         }
      }
   }
}
