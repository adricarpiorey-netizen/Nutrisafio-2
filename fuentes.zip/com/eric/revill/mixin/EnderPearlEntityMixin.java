package com.eric.revill.mixin;

import com.eric.revill.dedsafio4.Dedsafio4Manager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrownEnderpearl;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ThrownEnderpearl.class})
public abstract class EnderPearlEntityMixin {
   @Inject(
      method = {"onCollision"},
      at = {@At("TAIL")}
   )
   private void dedsafio4$enchancedEnderPearlDamage(HitResult hitResult, CallbackInfo ci) {
      ThrownEnderpearl pearl = (ThrownEnderpearl)this;
      Level world = pearl.level();
      if (!world.isClientSide) {
         if (world instanceof ServerLevel sw) {
            Entity owner = pearl.getOwner();
            if (owner instanceof LivingEntity livingOwner) {
               float damageAmount;
               if (Dedsafio4Manager.isEnabled("dia3_ender_pearls_damage10")) {
                  damageAmount = 10.0F;
                  damageAmount = 20.0F;
               } else {
                  damageAmount = 5.0F;
               }

               boolean ignoreArmor = Dedsafio4Manager.isEnabled("dia1_ender_pearls_ignoran_armor") || Dedsafio4Manager.isEnabled("dia3_ender_pearls_damage10");
               if (ignoreArmor || Dedsafio4Manager.isEnabled("dia3_ender_pearls_damage10")) {
                  if (ignoreArmor && owner instanceof ServerPlayer player) {
                     float extra = damageAmount - 5.0F;
                     if (extra > 0.0F) {
                        player.hurt(sw.damageSources().magic(), extra);
                     } else if (Dedsafio4Manager.isEnabled("dia1_ender_pearls_ignoran_armor")) {
                        player.hurt(sw.damageSources().magic(), 5.0F);
                     }
                  }
               }
            }
         }
      }
   }
}
