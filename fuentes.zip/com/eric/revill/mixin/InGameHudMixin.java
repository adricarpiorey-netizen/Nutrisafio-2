package com.eric.revill.mixin;

import com.eric.revill.RevillClient;
import com.eric.revill.item.ModItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({Gui.class})
public abstract class InGameHudMixin {
   private static final int DEDSAFIO4_GREEN = -12327313;

   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;F)V"},
      at = {@At("TAIL")}
   )
   private void dedsafio4$renderRedOverlayAboveChat(GuiGraphics context, float tickDelta, CallbackInfo callbackInfo) {
      RevillClient.SKY_RENDERER.renderOverlay(context);
   }

   @Inject(
      method = {"renderHotbarItem"},
      at = {@At("TAIL")}
   )
   private void dedsafio4$drawGreenHotbarBorder(
      GuiGraphics context, int x, int y, float tickDelta, Player player, ItemStack stack, int seed, CallbackInfo callbackInfo
   ) {
      if (stack.is(ModItems.DEDITA)
         || stack.is(ModItems.DEDITA_ROJA)
         || stack.is(ModItems.DEDITA_ROSA)
         || stack.is(ModItems.DEDITA_VERDE)
         || stack.is(Items.TOTEM_OF_UNDYING)) {
         context.fill(x, y, x + 16, y + 1, -12327313);
         context.fill(x, y + 15, x + 16, y + 16, -12327313);
         context.fill(x, y + 1, x + 1, y + 15, -12327313);
         context.fill(x + 15, y + 1, x + 16, y + 15, -12327313);
      }
   }
}
