package com.eric.revill.mixin;

import com.eric.revill.item.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemEntity.class})
public abstract class ItemEntityMixin {
   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void dedsafio4$spawnGreenBeam(CallbackInfo callbackInfo) {
      ItemEntity itemEntity = (ItemEntity)this;
      if (itemEntity.level() instanceof ServerLevel serverWorld) {
         if (itemEntity.onGround()) {
            ItemStack stack = itemEntity.getItem();
            if (stack.is(ModItems.DEDITA)
               || stack.is(ModItems.DEDITA_ROJA)
               || stack.is(ModItems.DEDITA_ROSA)
               || stack.is(ModItems.DEDITA_VERDE)
               || stack.is(Items.TOTEM_OF_UNDYING)) {
               if ((serverWorld.getGameTime() & 7L) == 0L) {
                  for (int segment = 0; segment < 5; segment++) {
                     serverWorld.sendParticles(
                        ParticleTypes.HAPPY_VILLAGER,
                        itemEntity.getX(),
                        itemEntity.getY() + 0.12 + (double)segment * 0.16,
                        itemEntity.getZ(),
                        1,
                        0.015,
                        0.01,
                        0.015,
                        0.005
                     );
                  }
               }
            }
         }
      }
   }
}
