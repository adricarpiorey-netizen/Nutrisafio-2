package com.eric.revill.mixin;

import com.eric.revill.RevillClient;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import com.mojang.math.Axis;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({LevelRenderer.class})
public abstract class WorldRendererMixin {
   private static final ResourceLocation CUSTOM_SKY_TEXTURE = new ResourceLocation("revill", "textures/environment/vortex.png");

   @Inject(
      method = {"renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void dedsafio4$renderCustomRedSky(
      PoseStack matrices, Matrix4f projectionMatrix, float tickDelta, Camera camera, boolean thickFog, Runnable skyFogSetup, CallbackInfo ci
   ) {
      if (RevillClient.FUSION_RENDERER.isBlackWorld()) {
         ci.cancel();
      } else if (RevillClient.SKY_RENDERER.shouldTintSky()) {
         ci.cancel();
         Minecraft client = Minecraft.getInstance();
         if (client != null) {
            float alpha = Math.min(1.0F, Math.max(0.0F, RevillClient.SKY_RENDERER.getTransition()));
            if (!(alpha <= 0.01F)) {
               RenderSystem.disableCull();
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.depthMask(false);
               Tesselator tessellator = Tesselator.getInstance();
               RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
               RenderSystem.setShaderTexture(0, CUSTOM_SKY_TEXTURE);
               matrices.pushPose();
               float rotationAngle = (float)((double)(System.currentTimeMillis() % 360000L) * 0.005);
               matrices.mulPose(Axis.YP.rotationDegrees(rotationAngle));
               BufferBuilder bufferBuilder = tessellator.getBuilder();
               int segments = 48;
               int stacks = 24;
               double radius = 100.0;
               bufferBuilder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);

               for (int i = 0; i < stacks; i++) {
                  float v0 = (float)i / (float)stacks;
                  float v1 = (float)(i + 1) / (float)stacks;
                  double phi0 = Math.PI * (double)v0;
                  double phi1 = Math.PI * (double)v1;
                  double y0 = radius * Math.cos(phi0);
                  double y1 = radius * Math.cos(phi1);
                  double r0 = radius * Math.sin(phi0);
                  double r1 = radius * Math.sin(phi1);
                  float stackCenter = (v0 + v1) * 0.5F;
                  float stackAlpha;
                  if (alpha >= 1.0F) {
                     stackAlpha = 1.0F;
                  } else if (alpha <= 0.0F) {
                     stackAlpha = 0.0F;
                  } else {
                     stackAlpha = Math.min(1.0F, Math.max(0.0F, (alpha - stackCenter * 0.5F) / 0.6F));
                  }

                  int sa = Math.round(stackAlpha * 255.0F);

                  for (int j = 0; j < segments; j++) {
                     float u0 = (float)j / (float)segments;
                     float u1 = (float)(j + 1) / (float)segments;
                     double theta0 = (Math.PI * 2) * (double)u0;
                     double theta1 = (Math.PI * 2) * (double)u1;
                     double x00 = r0 * Math.cos(theta0);
                     double z00 = r0 * Math.sin(theta0);
                     double x01 = r0 * Math.cos(theta1);
                     double z01 = r0 * Math.sin(theta1);
                     double x10 = r1 * Math.cos(theta0);
                     double z10 = r1 * Math.sin(theta0);
                     double x11 = r1 * Math.cos(theta1);
                     double z11 = r1 * Math.sin(theta1);
                     Matrix4f matrix = matrices.last().pose();
                     bufferBuilder.vertex(matrix, (float)x00, (float)y0, (float)z00).uv(u0, v0).color(255, 255, 255, sa).endVertex();
                     bufferBuilder.vertex(matrix, (float)x10, (float)y1, (float)z10).uv(u0, v1).color(255, 255, 255, sa).endVertex();
                     bufferBuilder.vertex(matrix, (float)x11, (float)y1, (float)z11).uv(u1, v1).color(255, 255, 255, sa).endVertex();
                     bufferBuilder.vertex(matrix, (float)x01, (float)y0, (float)z01).uv(u1, v0).color(255, 255, 255, sa).endVertex();
                  }
               }

               BufferUploader.drawWithShader(bufferBuilder.end());
               matrices.popPose();
               RenderSystem.depthMask(true);
               RenderSystem.disableBlend();
               RenderSystem.enableCull();
               RevillClient.ZENITH_ANIMATION_RENDERER.render(matrices, RevillClient.SKY_RENDERER);
            }
         }
      }
   }

   @Inject(
      method = {"renderEndSky(Lnet/minecraft/client/util/math/MatrixStack;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void dedsafio4$hideEndSkyWhileBlack(PoseStack matrices, CallbackInfo ci) {
      if (RevillClient.FUSION_RENDERER.isBlackWorld()) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"renderClouds(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FDDD)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void dedsafio4$hideCloudsDuringRedEvent(
      PoseStack matrices, Matrix4f projectionMatrix, float tickDelta, double cameraX, double cameraY, double cameraZ, CallbackInfo ci
   ) {
      if (RevillClient.SKY_RENDERER.shouldTintSky()) {
         ci.cancel();
      }
   }

   @Inject(
      method = {"renderLayer(Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/util/math/MatrixStack;DDDLorg/joml/Matrix4f;)V"},
      at = {@At("HEAD")}
   )
   private void dedsafio4$blackBlockTextureLayer(
      RenderType renderLayer, PoseStack matrices, double cameraX, double cameraY, double cameraZ, Matrix4f positionMatrix, CallbackInfo ci
   ) {
      if (RevillClient.FUSION_RENDERER.isBlackWorld()) {
         RenderSystem.setShaderColor(0.0F, 0.0F, 0.0F, 1.0F);
      }
   }

   @Inject(
      method = {"renderLayer(Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/util/math/MatrixStack;DDDLorg/joml/Matrix4f;)V"},
      at = {@At("RETURN")}
   )
   private void dedsafio4$restoreBlockTextureLayer(
      RenderType renderLayer, PoseStack matrices, double cameraX, double cameraY, double cameraZ, Matrix4f positionMatrix, CallbackInfo ci
   ) {
      if (RevillClient.FUSION_RENDERER.isBlackWorld()) {
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      }
   }
}
