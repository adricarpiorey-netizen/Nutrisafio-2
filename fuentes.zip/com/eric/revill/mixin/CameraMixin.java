package com.eric.revill.mixin;

import com.eric.revill.RevillClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({Camera.class})
public abstract class CameraMixin {
   @Shadow
   protected abstract void method_19325(float var1, float var2);

   @Inject(
      method = {"update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V"},
      at = {@At("TAIL")}
   )
   private void dedsafio4$shakeCameraDuringRift(
      BlockGetter area, Entity focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci
   ) {
      float strength = RevillClient.ZENITH_ANIMATION_RENDERER.getCameraShakeStrength();
      if (!(strength <= 0.0F)) {
         Camera camera = (Camera)this;
         float time = (float)((double)System.nanoTime() / 1.0E9);
         float yaw = (float)(Math.sin((double)(time * 19.0F)) + Math.sin((double)(time * 31.0F)) * 0.4F) * strength * 0.8F;
         float pitch = (float)(Math.sin((double)(time * 23.0F)) + Math.sin((double)(time * 37.0F)) * 0.35F) * strength * 0.55F;
         this.method_19325(camera.getYRot() + yaw, camera.getXRot() + pitch);
      }
   }
}
