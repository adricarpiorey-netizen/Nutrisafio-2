package com.eric.revill.mixin;

import com.eric.revill.RevillClient;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.client.renderer.FogRenderer.FogMode;
import net.minecraft.world.level.material.FogType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({FogRenderer.class})
public abstract class BackgroundRendererMixin {
   @Inject(
      method = {"applyFog(Lnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/BackgroundRenderer$FogType;FZF)V"},
      at = {@At("RETURN")}
   )
   private static void dedsafio4$applyRedFog(Camera camera, FogMode fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
      if (RevillClient.FUSION_RENDERER.isBlackWorld()) {
         float[] fog = RenderSystem.getShaderFogColor();
         RenderSystem.setShaderFogColor(0.0F, 0.0F, 0.0F, fog[3]);
      } else if (RevillClient.SKY_RENDERER.shouldTintSky()) {
         if (camera.getFluidInCamera() == FogType.NONE) {
            float t = RevillClient.SKY_RENDERER.getTransition();
            float[] fog = RenderSystem.getShaderFogColor();
            float r = fog[0] + (0.92F - fog[0]) * t;
            float g = fog[1] + (0.018F - fog[1]) * t;
            float b = fog[2] + (0.025F - fog[2]) * t;
            RenderSystem.setShaderFogColor(r, g, b, fog[3]);
         }
      }
   }
}
