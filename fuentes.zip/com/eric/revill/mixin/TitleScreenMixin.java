package com.eric.revill.mixin;

import com.eric.revill.client.render.TitleBackgroundRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({TitleScreen.class})
public abstract class TitleScreenMixin {
   @Inject(
      method = {"render(Lnet/minecraft/client/gui/DrawContext;IIF)V"},
      at = {@At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/gui/RotatingCubeMapRenderer;render(FF)V",
         shift = Shift.AFTER
      )}
   )
   private void dedsafio4$renderCustomTitleBackground(GuiGraphics context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      TitleBackgroundRenderer.render(context);
   }
}
