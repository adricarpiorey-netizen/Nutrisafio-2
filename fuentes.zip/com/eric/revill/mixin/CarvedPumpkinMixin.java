package com.eric.revill.mixin;

import com.eric.revill.dedsafio4.Dedsafio4Manager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.CarvedPumpkinBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({CarvedPumpkinBlock.class})
public abstract class CarvedPumpkinMixin {
   @Inject(
      method = {"canDispense(Lnet/minecraft/world/WorldView;Lnet/minecraft/util/math/BlockPos;)Z"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private static void dedsafio4$noGolemDispense(LevelReader world, BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
      if (Dedsafio4Manager.isEnabled("dia1_sin_golems")) {
         cir.setReturnValue(false);
      }
   }

   @Inject(
      method = {"trySpawnEntity(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void dedsafio4$preventGolemSpawn(Level world, BlockPos pos, CallbackInfo ci) {
      if (Dedsafio4Manager.isEnabled("dia1_sin_golems")) {
         if (!world.isClientSide) {
            Player closest = world.getNearestPlayer((double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), 8.0, false);
            if (closest != null) {
               closest.displayClientMessage(Component.literal("§cLos Gólems ya no pueden ser invocados."), true);
            }
         }

         ci.cancel();
      }
   }
}
