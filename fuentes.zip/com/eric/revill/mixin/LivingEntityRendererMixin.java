package com.eric.revill.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Font.DisplayMode;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({EntityRenderer.class})
public abstract class LivingEntityRendererMixin {
   @Inject(
      method = {"renderLabelIfPresent"},
      at = {@At("TAIL")},
      require = 0
   )
   private void dedsafio4$renderPlayerHealth(
      Entity entity, Component text, PoseStack matrices, MultiBufferSource vertexConsumers, int light, CallbackInfo callbackInfo
   ) {
      if (!(entity instanceof Player player) || player.isSpectator() || player.isDeadOrDying()) {
         return;
      }

      if (player != Minecraft.getInstance().player) {
         int currentHealth = Mth.ceil(player.getHealth());
         Component healthText = Component.literal("❤ " + currentHealth).copy().withStyle(style -> style.withColor(TextColor.fromRgb(16731212)));
         Font textRenderer = Minecraft.getInstance().font;
         matrices.pushPose();
         matrices.translate(0.0, (double)player.getBbHeight() + 0.85, 0.0);
         matrices.mulPose(Minecraft.getInstance().gameRenderer.getMainCamera().rotation());
         matrices.scale(-0.025F, -0.025F, 0.025F);
         float width = (float)(-textRenderer.width(healthText) / 2);
         textRenderer.drawInBatch(healthText, width, 0.0F, 16731212, false, matrices.last().pose(), vertexConsumers, DisplayMode.SEE_THROUGH, 0, 15728880);
         matrices.popPose();
      }
   }
}
