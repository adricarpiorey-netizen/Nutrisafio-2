package com.eric.revill.client.network;

import com.eric.revill.client.render.CurrencyHudRenderer;
import com.eric.revill.client.ui.AtmScreen;
import com.eric.revill.client.ui.AtmWithdrawScreen;
import com.eric.revill.client.ui.EconomyMenuScreen;
import com.eric.revill.economy.EconomyNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.FriendlyByteBuf;

@Environment(EnvType.CLIENT)
public final class EconomyClientNetworking {
   private EconomyClientNetworking() {
   }

   public static void register() {
      ClientPlayNetworking.registerGlobalReceiver(
         EconomyNetworking.OPEN_ATM, (client, handler, buf, responseSender) -> client.execute(() -> client.setScreen(new AtmScreen()))
      );
      ClientPlayNetworking.registerGlobalReceiver(
         EconomyNetworking.OPEN_COINS_MENU, (client, handler, buf, responseSender) -> client.execute(() -> client.setScreen(new EconomyMenuScreen()))
      );
      ClientPlayNetworking.registerGlobalReceiver(
         EconomyNetworking.OPEN_WITHDRAW_UI, (client, handler, buf, responseSender) -> client.execute(() -> client.setScreen(new AtmWithdrawScreen()))
      );
      ClientPlayNetworking.registerGlobalReceiver(EconomyNetworking.BALANCE_SYNC, (client, handler, buf, responseSender) -> {
         int blue = buf.readVarInt();
         int red = buf.readVarInt();
         int green = buf.readVarInt();
         client.execute(() -> CurrencyHudRenderer.setBalances(blue, red, green));
      });
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> CurrencyHudRenderer.setBalances(0, 0, 0));
   }

   public static void sendWithdrawRequest(int blue, int red, int green) {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeVarInt(blue);
      buf.writeVarInt(red);
      buf.writeVarInt(green);
      ClientPlayNetworking.send(EconomyNetworking.WITHDRAW, buf);
   }
}
