package com.eric.revill.client.network;

import com.eric.revill.RevillClient;
import com.eric.revill.client.render.ClientWaypointManager;
import com.eric.revill.client.sound.RevillEventAudio;
import com.eric.revill.dedsafio4.Dedsafio4Networking;
import com.eric.revill.mail.MailInboxScreenHandler;
import com.eric.revill.mail.MailNetworking;
import com.eric.revill.network.RevillNetworking;
import com.eric.revill.waypoint.Waypoint;
import com.eric.revill.waypoint.WaypointManager;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

@Environment(EnvType.CLIENT)
public final class RevillClientNetworking {
   private RevillClientNetworking() {
   }

   public static void register() {
      ClientPlayNetworking.registerGlobalReceiver(RevillNetworking.EVENT_STATE, (client, handler, buf, responseSender) -> {
         boolean active = buf.readBoolean();
         int remainingSeconds = buf.readInt();
         boolean skyActive = buf.readBoolean();
         boolean announcementActive = buf.readBoolean();
         client.execute(() -> {
            if (active) {
               RevillEventAudio.start();
            } else {
               RevillEventAudio.stop();
            }

            if (active && skyActive) {
               RevillClient.SKY_RENDERER.setActive(true);
               RevillClient.ZENITH_ANIMATION_RENDERER.start();
            } else {
               RevillClient.ZENITH_ANIMATION_RENDERER.stop(RevillClient.SKY_RENDERER);
            }

            if (!active || !announcementActive) {
               RevillClient.ANNOUNCEMENT_RENDERER.stop();
            } else if (!RevillClient.ANNOUNCEMENT_RENDERER.isActive()) {
               RevillClient.ANNOUNCEMENT_RENDERER.setActive(true);
            }

            RevillClient.HUD_RENDERER.setEventState(active, remainingSeconds);
         });
      });
      ClientPlayNetworking.registerGlobalReceiver(RevillNetworking.ANNOUNCEMENT, (client, handler, buf, responseSender) -> {
         int durationSeconds = buf.readInt();
         double flashSpeed = buf.readDouble();
         client.execute(() -> {
            RevillClient.ANNOUNCEMENT_RENDERER.setDurationSeconds(durationSeconds);
            RevillClient.ANNOUNCEMENT_RENDERER.setFlashSpeed(flashSpeed);
            RevillClient.ANNOUNCEMENT_RENDERER.start();
         });
      });
      ClientPlayNetworking.registerGlobalReceiver(RevillNetworking.STOP_EVENT, (client, handler, buf, responseSender) -> {
         buf.readBoolean();
         client.execute(() -> {
            RevillEventAudio.stop();
            RevillClient.ZENITH_ANIMATION_RENDERER.stop(RevillClient.SKY_RENDERER);
            RevillClient.ANNOUNCEMENT_RENDERER.stop();
            RevillClient.HUD_RENDERER.setEventState(false, 0);
            RevillClient.HUD_RENDERER.stopRoulette();
         });
      });
      ClientPlayNetworking.registerGlobalReceiver(RevillNetworking.ROULETTE, (client, handler, buf, responseSender) -> {
         String color = buf.readUtf();
         String result = buf.readUtf();
         client.execute(() -> RevillClient.HUD_RENDERER.startRoulette(color, result));
      });
      ClientPlayNetworking.registerGlobalReceiver(RevillNetworking.ROULETTE_ANNOUNCEMENT, (client, handler, buf, responseSender) -> {
         String color = buf.readUtf(32);
         String message = buf.readUtf(32767);
         client.execute(() -> RevillClient.HUD_RENDERER.showAnnouncementCard(message, color));
      });
      ClientPlayNetworking.registerGlobalReceiver(
         RevillNetworking.NUTRIA_ANIMATION, (client, handler, buf, responseSender) -> client.execute(() -> RevillClient.HUD_RENDERER.startNutriaAnimation())
      );
      ClientPlayNetworking.registerGlobalReceiver(
         RevillNetworking.REVILL_INTRO_DEATH,
         (client, handler, buf, responseSender) -> client.execute(() -> RevillClient.HUD_RENDERER.startRevillIntroDeathAnimation())
      );
      ClientPlayNetworking.registerGlobalReceiver(MailNetworking.INBOX_SYNC, (client, handler, buf, responseSender) -> {
         int syncId = buf.readVarInt();
         List<MailInboxScreenHandler.MailView> mails = MailNetworking.readInbox(buf);
         client.execute(() -> {
            if (client.player != null && client.player.containerMenu instanceof MailInboxScreenHandler inbox && inbox.containerId == syncId) {
               inbox.setMails(mails);
            }
         });
      });
      ClientPlayNetworking.registerGlobalReceiver(Dedsafio4Networking.DEATH_ACTIONBAR, (client, handler, buf, responseSender) -> {
         String playerName = buf.readUtf();
         String reason = buf.readUtf();
         boolean self = buf.readBoolean();
         client.execute(() -> RevillClient.HUD_RENDERER.showDeathNotice(playerName, reason, self));
      });
      ClientPlayNetworking.registerGlobalReceiver(Dedsafio4Networking.FUSION_TOGGLE, (client, handler, buf, responseSender) -> {
         boolean enabled = buf.readBoolean();
         client.execute(() -> RevillClient.FUSION_RENDERER.setEnabled(enabled));
      });
      ClientPlayNetworking.registerGlobalReceiver(WaypointManager.SYNC_WAYPOINTS, (client, handler, buf, responseSender) -> {
         List<Waypoint> waypoints = WaypointManager.decodeWaypoints(buf);
         client.execute(() -> ClientWaypointManager.setWaypoints(waypoints));
      });
   }
}
