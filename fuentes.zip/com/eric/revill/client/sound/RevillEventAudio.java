package com.eric.revill.client.sound;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.TickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;

@Environment(EnvType.CLIENT)
public final class RevillEventAudio {
   private static final ResourceLocation SOUND_ID = new ResourceLocation("revill", "revill");
   private static final ResourceLocation RIFT_SOUND_ID = new ResourceLocation("revill", "grieta");
   private static final ResourceLocation NUTRIA_SOUND_ID = new ResourceLocation("revill", "nutria");
   private static final ResourceLocation DEATH_SOUND_ID = new ResourceLocation("revill", "muerte");
   private static RevillEventAudio.RevillMusicInstance instance;
   private static SimpleSoundInstance nutriaInstance;
   private static SimpleSoundInstance deathIntroInstance;
   private static RevillEventAudio.RiftSoundInstance riftInstance;

   private RevillEventAudio() {
   }

   public static void start() {
      Minecraft client = Minecraft.getInstance();
      if (instance != null && client.getSoundManager().isActive(instance)) {
         instance.cancelFadeOut();
      } else {
         instance = new RevillEventAudio.RevillMusicInstance();
         client.getSoundManager().play(instance);
      }
   }

   public static void stop() {
      if (instance != null) {
         instance.fadeOut();
      }
   }

   public static void startNutria() {
      nutriaInstance = playOneShot(NUTRIA_SOUND_ID);
   }

   public static boolean isNutriaPlaying() {
      return isPlaying(nutriaInstance);
   }

   public static void startDeathIntro() {
      deathIntroInstance = playOneShot(DEATH_SOUND_ID);
   }

   public static boolean isDeathIntroPlaying() {
      return isPlaying(deathIntroInstance);
   }

   private static SimpleSoundInstance playOneShot(ResourceLocation soundId) {
      SimpleSoundInstance sound = new SimpleSoundInstance(
         soundId, SoundSource.MASTER, 1.0F, 1.0F, RandomSource.create(), false, 0, Attenuation.NONE, 0.0, 0.0, 0.0, true
      );
      Minecraft.getInstance().getSoundManager().play(sound);
      return sound;
   }

   private static boolean isPlaying(SimpleSoundInstance sound) {
      return sound != null && Minecraft.getInstance().getSoundManager().isActive(sound);
   }

   public static void startRift() {
      if (riftInstance == null || riftInstance.isStopped() || riftInstance.isFadingOut()) {
         riftInstance = new RevillEventAudio.RiftSoundInstance();
         Minecraft.getInstance().getSoundManager().queueTickingSound(riftInstance);
      }
   }

   public static void stopRift() {
      if (riftInstance != null) {
         riftInstance.fadeOut();
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class RevillMusicInstance extends AbstractSoundInstance implements TickableSoundInstance {
      private static final int FADE_TICKS = 30;
      private int ticks;
      private int fadeOutStart = -1;
      private boolean done;

      private RevillMusicInstance() {
         super(RevillEventAudio.SOUND_ID, SoundSource.MASTER, RandomSource.create());
         this.volume = 1.0F;
         this.pitch = 1.0F;
         this.looping = true;
         this.delay = 0;
         this.attenuation = Attenuation.NONE;
         this.relative = true;
      }

      public void tick() {
         this.ticks++;
         if (this.fadeOutStart >= 0) {
            float fadeOut = 1.0F - (float)(this.ticks - this.fadeOutStart) / 30.0F;
            this.volume = Math.max(0.0F, fadeOut);
            this.done = fadeOut <= 0.0F;
         }
      }

      private void fadeOut() {
         if (this.fadeOutStart < 0) {
            this.fadeOutStart = this.ticks;
         }
      }

      private void cancelFadeOut() {
         this.fadeOutStart = -1;
         this.volume = 1.0F;
      }

      public boolean isStopped() {
         return this.done;
      }
   }

   @Environment(EnvType.CLIENT)
   private static final class RiftSoundInstance extends AbstractSoundInstance implements TickableSoundInstance {
      private static final int FADE_TICKS = 12;
      private int ticks;
      private int fadeOutStart = -1;
      private boolean done;

      private RiftSoundInstance() {
         super(RevillEventAudio.RIFT_SOUND_ID, SoundSource.MASTER, RandomSource.create());
         this.volume = 0.01F;
         this.pitch = 1.0F;
         this.looping = true;
         this.delay = 0;
         this.attenuation = Attenuation.NONE;
         this.relative = true;
      }

      public void tick() {
         this.ticks++;
         float fadeIn = Math.min(1.0F, (float)this.ticks / 12.0F);
         if (this.fadeOutStart < 0) {
            this.volume = fadeIn;
         } else {
            float fadeOut = 1.0F - (float)(this.ticks - this.fadeOutStart) / 12.0F;
            this.volume = Math.max(0.0F, Math.min(fadeIn, fadeOut));
            this.done = fadeOut <= 0.0F;
         }
      }

      private void fadeOut() {
         if (this.fadeOutStart < 0) {
            this.fadeOutStart = this.ticks;
         }
      }

      private boolean isFadingOut() {
         return this.fadeOutStart >= 0;
      }

      public boolean isStopped() {
         return this.done;
      }
   }
}
