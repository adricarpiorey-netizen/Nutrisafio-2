package com.eric.revill.client.ui;

import com.eric.revill.mail.MailInboxScreenHandler;
import com.eric.revill.mail.MailNetworking;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

@Environment(EnvType.CLIENT)
public class MailInboxScreen extends AbstractContainerScreen<MailInboxScreenHandler> {
   private static final ResourceLocation TEXTURE = new ResourceLocation("dedsafio-4-mechanics", "textures/gui/mail/correo.png");
   private static final int SOURCE_WIDTH = 384;
   private static final int SOURCE_HEIGHT = 482;
   private float uiScale;
   private int left;
   private int top;
   private int selectedMail = -1;
   private int firstVisibleMail;
   private static final int VISIBLE_MAILS = 10;

   public MailInboxScreen(MailInboxScreenHandler handler, Inventory inventory, Component title) {
      super(handler, inventory, title);
      this.imageWidth = 384;
      this.imageHeight = 482;
      this.titleLabelX = 0;
      this.titleLabelY = 0;
   }

   protected void init() {
      super.init();
      this.uiScale = Math.min(0.67F, Math.min((float)this.width / 384.0F, (float)this.height / 482.0F));
      this.left = (this.width - Math.round(384.0F * this.uiScale)) / 2;
      this.top = (this.height - Math.round(482.0F * this.uiScale)) / 2;
      this.leftPos = 0;
      this.topPos = 0;
   }

   protected void renderBg(GuiGraphics context, float delta, int mouseX, int mouseY) {
      context.blit(TEXTURE, 0, 0, 0.0F, 0.0F, 384, 482, 384, 482);
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      context.pose().pushPose();
      context.pose().translate((float)this.left, (float)this.top, 0.0F);
      context.pose().scale(this.uiScale, this.uiScale, 1.0F);
      super.render(context, Math.round((float)(mouseX - this.left) / this.uiScale), Math.round((float)(mouseY - this.top) / this.uiScale), delta);
      context.pose().popPose();
   }

   protected void renderLabels(GuiGraphics context, int mouseX, int mouseY) {
      List<MailInboxScreenHandler.MailView> mails = ((MailInboxScreenHandler)this.menu).getMails();
      context.drawString(this.font, Component.literal("Buzón"), 22, 17, -1, false);
      context.drawString(this.font, Component.literal("Redactar"), 63, 29, -1, false);
      int visible = Math.min(10, Math.max(0, mails.size() - this.firstVisibleMail));

      for (int index = 0; index < visible; index++) {
         int mailIndex = this.firstVisibleMail + index;
         MailInboxScreenHandler.MailView mail = mails.get(mailIndex);
         int rowY = 86 + index * 29;
         if (mailIndex == this.selectedMail) {
            context.fill(20, rowY - 3, 174, rowY + 22, -14671840);
         }

         int senderColor = mail.read() ? -4737097 : -120;
         context.drawString(this.font, Component.literal(this.font.plainSubstrByWidth(mail.sender(), 144)), 27, rowY, senderColor, false);
         context.drawString(this.font, Component.literal(this.font.plainSubstrByWidth(mail.message(), 144)), 27, rowY + 11, -1, false);
      }

      if (this.selectedMail >= 0 && this.selectedMail < mails.size()) {
         MailInboxScreenHandler.MailView mail = mails.get(this.selectedMail);
         context.drawString(this.font, Component.literal("De: " + mail.sender()), 193, 87, -1, false);
         this.drawWrapped(context, mail.message(), 193, 111, 165, 11, 9);
         List<ItemStack> items = mail.items();
         boolean hasAttachments = items.stream().anyMatch(stack -> !stack.isEmpty());

         for (int index = 0; index < items.size(); index++) {
            if (!items.get(index).isEmpty()) {
               int itemX = 195 + index % 3 * 25;
               int itemY = 255 + index / 3 * 25;
               context.renderItem(items.get(index), itemX, itemY);
               context.renderItemDecorations(this.font, items.get(index), itemX, itemY);
            }
         }

         context.drawString(this.font, Component.literal(hasAttachments ? "Objetos adjuntos" : "Sin objetos adjuntos"), 193, 238, -1, false);
         if (hasAttachments) {
            context.drawString(this.font, Component.literal("Retirar adjuntos"), 220, 425, -1, false);
         }
      } else {
         context.drawString(this.font, Component.literal("Selecciona un correo"), 195, 103, -1, false);
      }
   }

   private void drawWrapped(GuiGraphics context, String message, int x, int y, int maxWidth, int lineHeight, int maxLines) {
      String remaining = message;

      for (int line = 0; line < maxLines && !remaining.isEmpty(); line++) {
         int length = Math.min(remaining.length(), Math.max(1, maxWidth / 6));
         int space = remaining.lastIndexOf(32, length);
         if (space > 0 && length < remaining.length()) {
            length = space;
         }

         context.drawString(this.font, Component.literal(remaining.substring(0, length)), x, y + line * lineHeight, -1, false);
         remaining = remaining.substring(length).stripLeading();
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      double imageX = (mouseX - (double)this.left) / (double)this.uiScale;
      double imageY = (mouseY - (double)this.top) / (double)this.uiScale;
      if (button == 0 && this.inside(imageX, imageY, 12, 8, 82, 57)) {
         FriendlyByteBuf buf = PacketByteBufs.empty();
         ClientPlayNetworking.send(MailNetworking.OPEN_COMPOSE, buf);
         return true;
      } else if (button == 0
         && this.inside(imageX, imageY, 188, 410, 370, 463)
         && this.selectedMail >= 0
         && this.selectedMail < ((MailInboxScreenHandler)this.menu).getMails().size()
         && ((MailInboxScreenHandler)this.menu).getMails().get(this.selectedMail).items().stream().anyMatch(stack -> !stack.isEmpty())) {
         FriendlyByteBuf buf = PacketByteBufs.create();
         buf.writeVarInt(((MailInboxScreenHandler)this.menu).containerId);
         buf.writeVarInt(this.selectedMail);
         ClientPlayNetworking.send(MailNetworking.CLAIM_ITEMS, buf);
         return true;
      } else if (button == 0 && this.inside(imageX, imageY, 18, 82, 177, 382)) {
         int index = this.firstVisibleMail + (int)((imageY - 82.0) / 29.0);
         if (index >= this.firstVisibleMail && index < ((MailInboxScreenHandler)this.menu).getMails().size() && index < this.firstVisibleMail + 10) {
            this.selectedMail = index;
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeVarInt(((MailInboxScreenHandler)this.menu).containerId);
            buf.writeVarInt(index);
            ClientPlayNetworking.send(MailNetworking.MARK_READ, buf);
         }

         return true;
      } else {
         return super.mouseClicked((mouseX - (double)this.left) / (double)this.uiScale, (mouseY - (double)this.top) / (double)this.uiScale, button);
      }
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      return this.minecraft != null && this.minecraft.options.keyInventory.matches(keyCode, scanCode) ? true : super.keyPressed(keyCode, scanCode, modifiers);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
      double imageX = (mouseX - (double)this.left) / (double)this.uiScale;
      double imageY = (mouseY - (double)this.top) / (double)this.uiScale;
      if (this.inside(imageX, imageY, 18, 82, 177, 382)) {
         int maxFirst = Math.max(0, ((MailInboxScreenHandler)this.menu).getMails().size() - 10);
         this.firstVisibleMail = Math.max(0, Math.min(maxFirst, this.firstVisibleMail - (int)Math.signum(amount)));
         return true;
      } else {
         return super.mouseScrolled(mouseX, mouseY, amount);
      }
   }

   private boolean inside(double pointX, double pointY, int minX, int minY, int maxX, int maxY) {
      return pointX >= (double)minX && pointX <= (double)maxX && pointY >= (double)minY && pointY <= (double)maxY;
   }

   public boolean isPauseScreen() {
      return false;
   }
}
