package com.eric.revill.client.ui;

import com.eric.revill.client.network.EconomyClientNetworking;
import com.eric.revill.client.render.CurrencyHudRenderer;
import com.eric.revill.economy.CurrencyType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public final class AtmWithdrawScreen extends Screen {
   private static final ResourceLocation TEXTURE = new ResourceLocation("dedsafio-4-mechanics", "textures/gui/atm/sacar.png");
   private static final int SOURCE_WIDTH = 176;
   private static final int SOURCE_HEIGHT = 166;
   private static final int[] COLUMN_X = new int[]{51, 85, 119};
   private static final int VALUE_Y = 102;
   private static final int CONFIRM_LEFT = 75;
   private static final int CONFIRM_TOP = 130;
   private static final int CONFIRM_RIGHT = 101;
   private static final int CONFIRM_BOTTOM = 146;
   private static final CurrencyType[] ROW_TYPES = new CurrencyType[]{CurrencyType.ROJA, CurrencyType.VERDE, CurrencyType.AZUL};
   private final int[] selected = new int[3];
   private float scale;
   private int left;
   private int top;
   private int renderWidth;
   private int renderHeight;

   public AtmWithdrawScreen() {
      super(Component.literal("Retirar deditas"));
   }

   protected void init() {
      this.scale = Math.min(1.0F, Math.min((float)this.width / 176.0F, (float)this.height / 166.0F));
      this.renderWidth = Math.round(176.0F * this.scale);
      this.renderHeight = Math.round(166.0F * this.scale);
      this.left = (this.width - this.renderWidth) / 2;
      this.top = (this.height - this.renderHeight) / 2;
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      context.blit(TEXTURE, this.left, this.top, 0.0F, 0.0F, this.renderWidth, this.renderHeight, 176, 166);
      int[] balances = CurrencyHudRenderer.getBalances();

      for (int index = 0; index < COLUMN_X.length; index++) {
         int amount = Math.min(this.selected[index], balances[ROW_TYPES[index].ordinal()]);
         context.drawCenteredString(
            this.font,
            Component.literal(Integer.toString(amount)),
            this.left + Math.round((float)COLUMN_X[index] * this.scale),
            this.top + Math.round(102.0F * this.scale),
            -1
         );
      }

      super.render(context, mouseX, mouseY, delta);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button != 0) {
         return super.mouseClicked(mouseX, mouseY, button);
      } else {
         double imageX = (mouseX - (double)this.left) / (double)this.scale;
         double imageY = (mouseY - (double)this.top) / (double)this.scale;

         for (int index = 0; index < COLUMN_X.length; index++) {
            if (Math.abs(imageX - (double)COLUMN_X[index]) <= 12.0) {
               int[] balances = CurrencyHudRenderer.getBalances();
               int balance = balances[ROW_TYPES[index].ordinal()];
               if (imageY >= 54.0 && imageY <= 66.0) {
                  this.selected[index] = Math.min(balance, this.selected[index] + 1);
                  return true;
               }

               if (imageY >= 81.0 && imageY <= 95.0) {
                  this.selected[index] = Math.max(0, this.selected[index] - 1);
                  return true;
               }
            }
         }

         if (this.inside(imageX, imageY, 75, 130, 101, 146)) {
            EconomyClientNetworking.sendWithdrawRequest(this.selected[2], this.selected[0], this.selected[1]);
            this.onClose();
            return true;
         } else {
            return super.mouseClicked(mouseX, mouseY, button);
         }
      }
   }

   private boolean inside(double x, double y, int left, int top, int right, int bottom) {
      return x >= (double)left && x <= (double)right && y >= (double)top && y <= (double)bottom;
   }

   public boolean isPauseScreen() {
      return false;
   }
}
