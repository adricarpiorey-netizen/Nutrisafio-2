package com.eric.revill.client.ui;

import com.eric.revill.economy.EconomyNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public final class AtmScreen extends Screen {
   private static final ResourceLocation TEXTURE = new ResourceLocation("dedsafio-4-mechanics", "textures/gui/atm/cajero.png");
   private static final int SOURCE_WIDTH = 176;
   private static final int SOURCE_HEIGHT = 166;
   private float scale;
   private int left;
   private int top;
   private int renderWidth;
   private int renderHeight;

   public AtmScreen() {
      super(Component.literal("Cajero Automático"));
   }

   protected void init() {
      this.scale = Math.min(1.0F, Math.min((float)this.width / 176.0F, (float)this.height / 166.0F));
      this.renderWidth = Math.round(176.0F * this.scale);
      this.renderHeight = Math.round(166.0F * this.scale);
      this.left = (this.width - this.renderWidth) / 2;
      this.top = (this.height - this.renderHeight) / 2;
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      context.blit(TEXTURE, this.left, this.top, 0.0F, 0.0F, this.renderWidth, this.renderHeight, 176, 166);
      super.render(context, mouseX, mouseY, delta);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button != 0) {
         return super.mouseClicked(mouseX, mouseY, button);
      } else {
         double imageX = (mouseX - (double)this.left) / (double)this.scale;
         double imageY = (mouseY - (double)this.top) / (double)this.scale;
         if (this.inside(imageX, imageY, 25, 120, 82, 141)) {
            ClientPlayNetworking.send(EconomyNetworking.OPEN_DEPOSIT, PacketByteBufs.empty());
            return true;
         } else if (this.inside(imageX, imageY, 90, 120, 150, 141)) {
            ClientPlayNetworking.send(EconomyNetworking.OPEN_WITHDRAW, PacketByteBufs.empty());
            return true;
         } else {
            return super.mouseClicked(mouseX, mouseY, button);
         }
      }
   }

   private boolean inside(double x, double y, int left, int top, int right, int bottom) {
      return x >= (double)left && x <= (double)right && y >= (double)top && y <= (double)bottom;
   }

   public boolean isPauseScreen() {
      return false;
   }
}
