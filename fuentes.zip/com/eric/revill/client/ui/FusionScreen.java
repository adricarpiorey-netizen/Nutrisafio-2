package com.eric.revill.client.ui;

import com.eric.revill.client.render.FusionRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

@Environment(EnvType.CLIENT)
public final class FusionScreen extends Screen {
   private final FusionRenderer renderer;

   public FusionScreen(FusionRenderer renderer) {
      super(Component.empty());
      this.renderer = renderer;
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      this.renderer.render(context);
   }

   public boolean isPauseScreen() {
      return false;
   }

   public boolean shouldCloseOnEsc() {
      return false;
   }
}
