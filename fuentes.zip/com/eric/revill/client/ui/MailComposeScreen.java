package com.eric.revill.client.ui;

import com.eric.revill.mail.MailComposeScreenHandler;
import com.eric.revill.mail.MailNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

@Environment(EnvType.CLIENT)
public final class MailComposeScreen extends AbstractContainerScreen<MailComposeScreenHandler> {
   private static final ResourceLocation TEXTURE = new ResourceLocation("dedsafio-4-mechanics", "textures/gui/mail/correosend.png");
   private static final int SOURCE_WIDTH = 381;
   private static final int SOURCE_HEIGHT = 471;
   private float uiScale;
   private int left;
   private int top;
   private EditBox recipientField;
   private EditBox messageField;

   public MailComposeScreen(MailComposeScreenHandler handler, Inventory inventory, Component title) {
      super(handler, inventory, title);
      this.imageWidth = 381;
      this.imageHeight = 471;
      this.titleLabelX = 0;
      this.titleLabelY = 0;
   }

   protected void init() {
      super.init();
      this.uiScale = Math.min(0.75F, Math.min((float)this.width / 381.0F, (float)this.height / 471.0F));
      this.left = (this.width - Math.round(381.0F * this.uiScale)) / 2;
      this.top = (this.height - Math.round(471.0F * this.uiScale)) / 2;
      this.leftPos = 0;
      this.topPos = 0;
      this.recipientField = new EditBox(this.font, 74, 70, 251, 20, Component.literal("Destinatario"));
      this.recipientField.setMaxLength(64);
      this.recipientField.setHint(Component.literal("Destinatario"));
      this.addRenderableWidget(this.recipientField);
      this.messageField = new EditBox(this.font, 74, 108, 251, 44, Component.literal("Mensaje"));
      this.messageField.setMaxLength(512);
      this.messageField.setHint(Component.literal("Mensaje"));
      this.addRenderableWidget(this.messageField);
      ((MailComposeScreenHandler)this.menu).layoutSlots(this.makeSlotPositions());
   }

   private int[][] makeSlotPositions() {
      int[][] positions = new int[45][2];

      for (int row = 0; row < 3; row++) {
         for (int column = 0; column < 3; column++) {
            int index = row * 3 + column;
            positions[index][0] = 48 + column * 18;
            positions[index][1] = 194 + row * 18;
         }
      }

      for (int row = 0; row < 3; row++) {
         for (int column = 0; column < 9; column++) {
            int index = 9 + row * 9 + column;
            positions[index][0] = 10 + column * 18;
            positions[index][1] = 310 + row * 18;
         }
      }

      for (int column = 0; column < 9; column++) {
         int index = 36 + column;
         positions[index][0] = 10 + column * 18;
         positions[index][1] = 364;
      }

      return positions;
   }

   protected void renderBg(GuiGraphics context, float delta, int mouseX, int mouseY) {
      context.blit(TEXTURE, 0, 0, 0.0F, 0.0F, 381, 471, 381, 471);
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      context.pose().pushPose();
      context.pose().translate((float)this.left, (float)this.top, 0.0F);
      context.pose().scale(this.uiScale, this.uiScale, 1.0F);
      super.render(context, Math.round((float)(mouseX - this.left) / this.uiScale), Math.round((float)(mouseY - this.top) / this.uiScale), delta);
      context.pose().popPose();
   }

   protected void renderLabels(GuiGraphics context, int mouseX, int mouseY) {
      context.drawString(this.font, Component.literal("Destinatario"), 25, 75, -1, false);
      context.drawString(this.font, Component.literal("Mensaje"), 25, 113, -1, false);
      context.drawString(this.font, Component.literal("Adjuntos"), 57, 185, -1, false);
      context.drawString(this.font, Component.literal("Volver"), 38, 434, -1, false);
      context.drawString(this.font, Component.literal("Enviar"), 276, 434, -1, false);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      double imageX = (mouseX - (double)this.left) / (double)this.uiScale;
      double imageY = (mouseY - (double)this.top) / (double)this.uiScale;
      if (button == 0 && imageX >= 20.0 && imageX <= 120.0 && imageY >= 418.0 && imageY <= 459.0) {
         ClientPlayNetworking.send(MailNetworking.RETURN_INBOX, PacketByteBufs.empty());
         return true;
      } else if (button == 0 && imageX >= 244.0 && imageX <= 358.0 && imageY >= 418.0 && imageY <= 459.0) {
         FriendlyByteBuf buf = PacketByteBufs.create();
         buf.writeUtf(this.recipientField.getValue().trim(), 64);
         buf.writeUtf(this.messageField.getValue().trim(), 512);
         ClientPlayNetworking.send(MailNetworking.SEND_MAIL, buf);
         return true;
      } else {
         return super.mouseClicked((mouseX - (double)this.left) / (double)this.uiScale, (mouseY - (double)this.top) / (double)this.uiScale, button);
      }
   }

   public void mouseMoved(double mouseX, double mouseY) {
      super.mouseMoved((mouseX - (double)this.left) / (double)this.uiScale, (mouseY - (double)this.top) / (double)this.uiScale);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      return super.mouseDragged(
         (mouseX - (double)this.left) / (double)this.uiScale,
         (mouseY - (double)this.top) / (double)this.uiScale,
         button,
         deltaX / (double)this.uiScale,
         deltaY / (double)this.uiScale
      );
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      return super.mouseReleased((mouseX - (double)this.left) / (double)this.uiScale, (mouseY - (double)this.top) / (double)this.uiScale, button);
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      return this.minecraft != null && this.minecraft.options.keyInventory.matches(keyCode, scanCode)
         ? (this.recipientField == null || !this.recipientField.isFocused()) && (this.messageField == null || !this.messageField.isFocused())
         : super.keyPressed(keyCode, scanCode, modifiers);
   }

   public boolean isPauseScreen() {
      return false;
   }
}
