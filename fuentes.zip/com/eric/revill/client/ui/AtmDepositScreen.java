package com.eric.revill.client.ui;

import com.eric.revill.economy.AtmScreenHandler;
import com.eric.revill.economy.CurrencyType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

@Environment(EnvType.CLIENT)
public final class AtmDepositScreen extends AbstractContainerScreen<AtmScreenHandler> {
   private static final ResourceLocation TEXTURE = new ResourceLocation("dedsafio-4-mechanics", "textures/gui/atm/ingresar.png");
   private static final int SOURCE_WIDTH = 176;
   private static final int SOURCE_HEIGHT = 166;
   private float scale;
   private int left;
   private int top;
   private int renderWidth;
   private int renderHeight;

   public AtmDepositScreen(AtmScreenHandler handler, Inventory inventory, Component title) {
      super(handler, inventory, title);
      this.imageWidth = 176;
      this.imageHeight = 166;
      this.titleLabelX = 0;
      this.titleLabelY = 0;
   }

   protected void init() {
      super.init();
      this.scale = Math.min(1.0F, Math.min((float)this.width / 176.0F, (float)this.height / 166.0F));
      this.renderWidth = Math.round(176.0F * this.scale);
      this.renderHeight = Math.round(166.0F * this.scale);
      this.left = (this.width - this.renderWidth) / 2;
      this.top = (this.height - this.renderHeight) / 2;
      this.leftPos = 0;
      this.topPos = 0;
      ((AtmScreenHandler)this.menu).layoutSlots(this.makeSlotPositions());
   }

   private int[][] makeSlotPositions() {
      int[][] positions = new int[45][2];

      for (int row = 0; row < 3; row++) {
         for (int column = 0; column < 3; column++) {
            int index = row * 3 + column;
            positions[index][0] = 39 + column * 18;
            positions[index][1] = 15 + row * 18;
         }
      }

      for (int row = 0; row < 3; row++) {
         for (int column = 0; column < 9; column++) {
            int index = 9 + row * 9 + column;
            positions[index][0] = 8 + column * 18;
            positions[index][1] = 85 + row * 18;
         }
      }

      for (int column = 0; column < 9; column++) {
         int index = 36 + column;
         positions[index][0] = 8 + column * 18;
         positions[index][1] = 141;
      }

      return positions;
   }

   protected void renderBg(GuiGraphics context, float delta, int mouseX, int mouseY) {
      context.blit(TEXTURE, 0, 0, 0.0F, 0.0F, 176, 166, 176, 166);
      this.drawDepositPreview(context);
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      context.pose().pushPose();
      context.pose().translate((float)this.left, (float)this.top, 0.0F);
      context.pose().scale(this.scale, this.scale, 1.0F);
      super.render(context, Math.round((float)(mouseX - this.left) / this.scale), Math.round((float)(mouseY - this.top) / this.scale), delta);
      context.pose().popPose();
   }

   protected void renderLabels(GuiGraphics context, int mouseX, int mouseY) {
   }

   private void drawDepositPreview(GuiGraphics context) {
      context.pose().pushPose();
      context.pose().translate(135.0F, 56.0F, 0.0F);
      context.pose().scale(0.65F, 0.65F, 1.0F);
      context.drawCenteredString(this.font, Component.literal("Se ingresará:"), 0, 0, -1);
      context.pose().popPose();
      int[] amounts = ((AtmScreenHandler)this.menu).getDepositAmounts();
      CurrencyType[] types = CurrencyType.values();
      int totalWidth = 0;
      int visibleTypes = 0;

      for (CurrencyType type : types) {
         int amount = amounts[type.ordinal()];
         if (amount > 0) {
            totalWidth += 18 + this.font.width(Integer.toString(amount));
            visibleTypes++;
         }
      }

      if (visibleTypes != 0) {
         totalWidth += (visibleTypes - 1) * 3;
         float previewScale = 0.65F;
         float x = 135.0F - (float)totalWidth * previewScale / 2.0F;

         for (CurrencyType typex : types) {
            int amount = amounts[typex.ordinal()];
            if (amount > 0) {
               String amountText = Integer.toString(amount);
               context.pose().pushPose();
               context.pose().translate(x, 64.0F, 0.0F);
               context.pose().scale(previewScale, previewScale, 1.0F);
               context.renderItem(new ItemStack(typex.item()), 0, 0);
               context.drawString(this.font, amountText, 18, 4, -1);
               context.pose().popPose();
               x += (float)(18 + this.font.width(amountText) + 3) * previewScale;
            }
         }
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         double imageX = (mouseX - (double)this.left) / (double)this.scale;
         double imageY = (mouseY - (double)this.top) / (double)this.scale;
         if (imageX >= 105.0 && imageX <= 145.0 && imageY >= 36.0 && imageY <= 55.0) {
            Minecraft client = Minecraft.getInstance();
            if (client != null && client.gameMode != null && client.player != null) {
               client.gameMode.handleInventoryButtonClick(((AtmScreenHandler)this.menu).containerId, 0);
               client.player.closeContainer();
            }

            return true;
         }
      }

      return super.mouseClicked((mouseX - (double)this.left) / (double)this.scale, (mouseY - (double)this.top) / (double)this.scale, button);
   }

   public boolean isPauseScreen() {
      return false;
   }
}
