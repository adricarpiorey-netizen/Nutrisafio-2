package com.eric.revill.client.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

@Environment(EnvType.CLIENT)
public class RedEventAnnouncementRenderer {
   private static final String TITLE = "MOMENTO REVILL";
   private static final String BODY = "";
   private boolean active;
   private double elapsed;
   private double durationSeconds = 10.0;
   private double flashSpeed = 1.5;
   private boolean started;

   public void start() {
      this.active = true;
      this.elapsed = 0.0;
      this.started = true;
   }

   public void stop() {
      this.active = false;
      this.started = false;
      this.elapsed = 0.0;
   }

   public void setActive(boolean active) {
      this.active = active;
      if (active) {
         this.elapsed = 0.0;
         this.started = true;
      }
   }

   public boolean isActive() {
      return this.active;
   }

   public void setDurationSeconds(int seconds) {
      this.durationSeconds = Math.max(1.0, (double)seconds);
   }

   public void setFlashSpeed(double flashSpeed) {
      this.flashSpeed = flashSpeed;
   }

   public void tick(Minecraft client) {
      if (this.active && client != null) {
         this.elapsed = this.elapsed + (double)client.getDeltaFrameTime();
         if (this.elapsed >= this.durationSeconds) {
            this.stop();
         }
      }
   }

   public void render(GuiGraphics drawContext, Font textRenderer, int width, int height) {
      if (this.active && this.started && "" != null && !"".isBlank()) {
         int centerX = width / 2;
         int titleY = height / 2 - 18;
         int bodyY = height / 2 + 8;
         double phase = this.elapsed * this.flashSpeed % 1.0;
         int glow = (int)Math.round(255.0 * (0.5 + 0.5 * Math.sin(phase * Math.PI * 2.0)));
         int alpha = Math.min(255, Math.max(0, glow));
         drawContext.drawString(
            textRenderer, Component.literal("MOMENTO REVILL"), centerX - textRenderer.width("MOMENTO REVILL") / 2, titleY, 16777215 | alpha << 24
         );
         drawContext.drawString(textRenderer, Component.literal(""), centerX - textRenderer.width("") / 2, bodyY, 16768477 | alpha << 24);
      }
   }
}
