package com.eric.revill.client.render;

import com.eric.revill.waypoint.Waypoint;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

@Environment(EnvType.CLIENT)
public class ClientWaypointManager {
   private static final List<Waypoint> WAYPOINTS = new ArrayList<>();
   private static final Map<String, ClientWaypointManager.Marker> MARKERS = new LinkedHashMap<>();
   private static ClientLevel markerWorld;
   private static int nextEntityId = -1;

   private ClientWaypointManager() {
   }

   public static void setWaypoints(List<Waypoint> waypoints) {
      WAYPOINTS.clear();
      if (waypoints != null) {
         WAYPOINTS.addAll(waypoints);
      }

      refreshMarkers();
   }

   public static void tick() {
      Minecraft client = Minecraft.getInstance();
      if (client != null && client.level == markerWorld) {
         if (client.player != null) {
            for (Waypoint waypoint : WAYPOINTS) {
               ClientWaypointManager.Marker marker = MARKERS.get(waypoint.getId());
               if (marker != null) {
                  int distance = (int)client.player.position().distanceTo(marker.position());
                  if (distance != marker.distance()) {
                     marker.entity().setCustomName(createLabel(waypoint, distance));
                     MARKERS.put(waypoint.getId(), marker.withDistance(distance));
                  }
               }
            }
         }
      } else {
         refreshMarkers();
      }
   }

   public static void clear() {
      WAYPOINTS.clear();
      refreshMarkers();
   }

   public static List<Waypoint> getWaypoints() {
      return Collections.unmodifiableList(WAYPOINTS);
   }

   private static void refreshMarkers() {
      if (markerWorld != null) {
         for (ClientWaypointManager.Marker marker : MARKERS.values()) {
            markerWorld.removeEntity(marker.entityId(), RemovalReason.DISCARDED);
         }
      }

      MARKERS.clear();
      nextEntityId = -1;
      Minecraft client = Minecraft.getInstance();
      markerWorld = client == null ? null : client.level;
      if (markerWorld != null && client.player != null) {
         String dimension = markerWorld.dimension().location().toString();

         for (Waypoint waypoint : WAYPOINTS) {
            if (waypoint.getDimension().isEmpty() || waypoint.getDimension().equals(dimension)) {
               ArmorStand marker = (ArmorStand)EntityType.ARMOR_STAND.create(markerWorld);
               if (marker != null) {
                  BlockPos pos = waypoint.getPos();
                  marker.setPos((double)pos.getX() + 0.5, (double)pos.getY() + 1.5, (double)pos.getZ() + 0.5);
                  marker.setInvisible(true);
                  marker.setNoGravity(true);
                  marker.setInvulnerable(true);
                  marker.setSilent(true);
                  marker.setCustomNameVisible(true);
                  Vec3 markerPosition = marker.position();
                  int distance = (int)client.player.position().distanceTo(markerPosition);
                  marker.setCustomName(createLabel(waypoint, distance));
                  int entityId = nextEntityId--;
                  markerWorld.putNonPlayerEntity(entityId, marker);
                  MARKERS.put(waypoint.getId(), new ClientWaypointManager.Marker(entityId, marker, markerPosition, distance));
               }
            }
         }
      }
   }

   private static Component createLabel(Waypoint waypoint, int distance) {
      return Component.literal(icon(waypoint.getIcon()) + " " + waypoint.getName() + " [" + distance + "m]")
         .withStyle(new ChatFormatting[]{ChatFormatting.WHITE, ChatFormatting.BOLD});
   }

   private static String icon(String icon) {
      if (icon == null) {
         return "◆";
      } else {
         String var1 = icon.toLowerCase();

         return switch (var1) {
            case "bunker" -> "◆";
            case "home", "casa" -> "⌂";
            case "star", "estrella" -> "★";
            case "warning", "peligro" -> "!";
            case "skull", "muerte" -> "☠";
            default -> "◆";
         };
      }
   }

   @Environment(EnvType.CLIENT)
   private static record Marker(int entityId, ArmorStand entity, Vec3 position, int distance) {
      private ClientWaypointManager.Marker withDistance(int updatedDistance) {
         return new ClientWaypointManager.Marker(this.entityId, this.entity, this.position, updatedDistance);
      }
   }
}
