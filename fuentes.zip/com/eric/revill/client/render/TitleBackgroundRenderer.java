package com.eric.revill.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public final class TitleBackgroundRenderer {
   private static final ResourceLocation BACKGROUND = new ResourceLocation("dedsafio-4-mechanics", "textures/gui/title/fondo.png");
   private static final int BACKGROUND_WIDTH = 1360;
   private static final int BACKGROUND_HEIGHT = 752;

   private TitleBackgroundRenderer() {
   }

   public static void render(GuiGraphics context) {
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      context.blit(BACKGROUND, 0, 0, 0.0F, 0.0F, context.guiWidth(), context.guiHeight(), 1360, 752);
   }
}
