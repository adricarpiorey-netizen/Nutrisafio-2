package com.eric.revill.client.render;

import com.eric.revill.client.ui.FusionScreen;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.NativeImage.Format;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.imageio.ImageIO;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.sounds.SoundEvent;

@Environment(EnvType.CLIENT)
public class FusionRenderer {
   private static final ResourceLocation RENDER_TEXTURE = new ResourceLocation("revill", "fusion_gif_texture");
   private static final ResourceLocation FUSION_SOUND = new ResourceLocation("revill", "fusion");
   private static final int FRAME_COUNT = 60;
   private static final int FRAME_RATE = 12;
   private static final int FADE_TICKS = 40;
   private static final int AUDIO_START_TIMEOUT_TICKS = 200;
   private final List<BufferedImage> frames = new ArrayList<>();
   private DynamicTexture dynamicTexture;
   private boolean active;
   private boolean blackWorld;
   private boolean effectRunning;
   private boolean transitionToBlack;
   private int effectTicks;
   private int phaseTicks;
   private int audioStartWaitTicks;
   private boolean audioStarted;
   private FusionRenderer.Phase phase = FusionRenderer.Phase.IDLE;
   private SimpleSoundInstance fusionSound;
   private boolean framesLoaded;

   public void setEnabled(boolean enabled) {
      if (enabled != this.blackWorld || this.effectRunning) {
         this.transitionToBlack = enabled;
         this.effectRunning = true;
         this.effectTicks = 0;
         this.phaseTicks = 0;
         this.active = true;
         this.phase = FusionRenderer.Phase.FADE_IN;
         this.audioStartWaitTicks = 0;
         this.audioStarted = false;
         this.loadGifFrames();
         this.startFusionSound();
         Minecraft client = Minecraft.getInstance();
         if (client != null) {
            client.setScreen(new FusionScreen(this));
         }
      }
   }

   public void toggle() {
      if (!this.effectRunning) {
         boolean nextState = !this.blackWorld;
         this.transitionToBlack = nextState;
         this.effectRunning = true;
         this.effectTicks = 0;
         this.phaseTicks = 0;
         this.active = true;
         this.phase = FusionRenderer.Phase.FADE_IN;
         this.audioStartWaitTicks = 0;
         this.audioStarted = false;
         this.loadGifFrames();
         this.startFusionSound();
         Minecraft client = Minecraft.getInstance();
         if (client != null) {
            client.setScreen(new FusionScreen(this));
         }
      }
   }

   public boolean isActive() {
      return this.active;
   }

   public boolean isBlackWorld() {
      return this.blackWorld;
   }

   public void reset() {
      this.effectRunning = false;
      this.active = false;
      this.setBlackWorld(Minecraft.getInstance(), false);
      this.transitionToBlack = false;
      this.phase = FusionRenderer.Phase.IDLE;
      this.phaseTicks = 0;
      this.fusionSound = null;
      Minecraft client = Minecraft.getInstance();
      if (client != null && client.screen instanceof FusionScreen) {
         client.setScreen(null);
      }
   }

   public void tick() {
      if (!this.effectRunning) {
         this.active = this.blackWorld;
      } else {
         this.effectTicks++;
         this.phaseTicks++;
         Minecraft client = Minecraft.getInstance();
         boolean soundPlaying = client != null && this.fusionSound != null && client.getSoundManager().isActive(this.fusionSound);
         if (soundPlaying) {
            this.audioStarted = true;
         }

         this.active = true;
         switch (this.phase) {
            case FADE_IN:
               if (this.phaseTicks >= 40) {
                  this.phase = FusionRenderer.Phase.PLAYING;
                  this.phaseTicks = 0;
               }
               break;
            case PLAYING:
               if (!soundPlaying && (this.audioStarted || ++this.audioStartWaitTicks >= 200)) {
                  this.phase = FusionRenderer.Phase.FADE_OUT;
                  this.phaseTicks = 0;
                  this.setBlackWorld(client, this.transitionToBlack);
                  this.active = this.blackWorld;
               }
               break;
            case FADE_OUT:
               if (this.phaseTicks >= 40) {
                  this.finishTransition(client);
               }
         }
      }
   }

   public void render(GuiGraphics context) {
      if (this.effectRunning && !this.frames.isEmpty()) {
         int width = context.guiWidth();
         int height = context.guiHeight();
         this.ensureTexture();
         float gifAlpha = this.getGifAlpha();
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, gifAlpha);
         context.blit(RENDER_TEXTURE, 0, 0, 0.0F, 0.0F, width, height, width, height);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.disableBlend();
      }
   }

   private void finishTransition(Minecraft client) {
      this.effectRunning = false;
      this.setBlackWorld(client, this.transitionToBlack);
      this.active = this.blackWorld;
      this.effectTicks = 0;
      this.phaseTicks = 0;
      this.phase = FusionRenderer.Phase.IDLE;
      this.fusionSound = null;
      if (client != null && client.screen instanceof FusionScreen) {
         client.setScreen(null);
      }
   }

   private void setBlackWorld(Minecraft client, boolean enabled) {
      if (this.blackWorld != enabled) {
         this.blackWorld = enabled;
         if (client != null && client.levelRenderer != null && client.player != null && client.level != null) {
            int radius = (Integer)client.options.renderDistance().get() * 16;
            int x = client.player.getBlockX();
            int z = client.player.getBlockZ();
            client.levelRenderer
               .setBlocksDirty(x - radius, client.level.getMinBuildHeight(), z - radius, x + radius, client.level.getMaxBuildHeight(), z + radius);
            client.levelRenderer.needsUpdate();
         }
      }
   }

   private float getGifAlpha() {
      if (!this.effectRunning) {
         return 0.0F;
      } else {
         return switch (this.phase) {
            case FADE_IN -> Math.min(1.0F, (float)this.phaseTicks / 40.0F);
            case PLAYING -> 1.0F;
            case FADE_OUT -> Math.max(0.0F, 1.0F - (float)this.phaseTicks / 40.0F);
            default -> 0.0F;
         };
      }
   }

   private void startFusionSound() {
      Minecraft client = Minecraft.getInstance();
      if (client != null && client.player != null) {
         this.fusionSound = SimpleSoundInstance.forUI(SoundEvent.createVariableRangeEvent(FUSION_SOUND), 1.0F);
         client.getSoundManager().play(this.fusionSound);
      }
   }

   private void ensureTexture() {
      if (this.dynamicTexture != null) {
         this.updateCurrentFrame();
      } else if (!this.frames.isEmpty()) {
         BufferedImage firstFrame = this.frames.get(0);
         NativeImage image = new NativeImage(Format.RGBA, firstFrame.getWidth(), firstFrame.getHeight(), false);

         for (int y = 0; y < firstFrame.getHeight(); y++) {
            for (int x = 0; x < firstFrame.getWidth(); x++) {
               image.setPixelRGBA(x, y, firstFrame.getRGB(x, y));
            }
         }

         this.dynamicTexture = new DynamicTexture(image);
         Minecraft.getInstance().getTextureManager().register(RENDER_TEXTURE, this.dynamicTexture);
         this.updateCurrentFrame();
      }
   }

   private void updateCurrentFrame() {
      if (this.dynamicTexture != null && !this.frames.isEmpty()) {
         int frameIndex = this.effectTicks * 12 / 20 % this.frames.size();
         BufferedImage frame = this.frames.get(frameIndex);
         NativeImage image = this.dynamicTexture.getPixels();
         if (image != null) {
            for (int y = 0; y < frame.getHeight() && y < image.getHeight(); y++) {
               for (int x = 0; x < frame.getWidth() && x < image.getWidth(); x++) {
                  image.setPixelRGBA(x, y, frame.getRGB(x, y));
               }
            }

            this.dynamicTexture.upload();
         }
      }
   }

   private void loadGifFrames() {
      if (!this.framesLoaded) {
         try {
            Minecraft client = Minecraft.getInstance();
            if (client == null || client.getResourceManager() == null) {
               return;
            }

            for (int index = 1; index <= 60; index++) {
               ResourceLocation frameId = new ResourceLocation("revill", String.format("textures/fusion/ezgif-frame-%03d.jpg", index));
               Optional<Resource> resource = client.getResourceManager().getResource(frameId);
               if (resource.isEmpty()) {
                  this.frames.clear();
                  return;
               }

               try (InputStream stream = resource.get().open()) {
                  BufferedImage frame = ImageIO.read(stream);
                  if (frame == null) {
                     this.frames.clear();
                     return;
                  }

                  this.frames.add(frame);
               }
            }

            this.framesLoaded = this.frames.size() == 60;
         } catch (IOException var10) {
            this.frames.clear();
         }
      }
   }

   @Environment(EnvType.CLIENT)
   private static enum Phase {
      IDLE,
      FADE_IN,
      PLAYING,
      FADE_OUT;
   }
}
