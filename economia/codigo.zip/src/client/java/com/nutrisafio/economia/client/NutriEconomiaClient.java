package com.nutrisafio.economia.client;

import com.nutrisafio.economia.NutriEconomia;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NutriEconomiaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(NutriEconomia.GRANJERO, ComercianteRenderer::new);
        EntityRendererRegistry.register(NutriEconomia.CAMBISTA, ComercianteRenderer::new);
        EntityRendererRegistry.register(NutriEconomia.TIENDA, ComercianteRenderer::new);
        EntityRendererRegistry.register(NutriEconomia.BIBLIOTECARIO, ComercianteRenderer::new);
    }
}
