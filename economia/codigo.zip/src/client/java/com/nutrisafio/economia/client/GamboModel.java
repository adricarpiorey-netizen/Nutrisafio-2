package com.nutrisafio.economia.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.nutrisafio.economia.Comerciante;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** Modelo "Gambo" (convertido desde el proyecto CPM). Flota suavemente y gira la cabeza hacia ti. */
public class GamboModel extends HierarchicalModel<Comerciante> {
    private final ModelPart root;
    private final ModelPart flotar;   // todo el cuerpo
    private final ModelPart cabeza;   // la pantalla y el sombrero

    public GamboModel(ModelPart root) {
        this.root = root;
        ModelPart body = root.getChild("body");
        this.flotar = body.getChild("c0").getChild("c0");
        this.cabeza = this.flotar.getChild("c0");
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        JsonModelLoader.render(this.root, poseStack, buffer, packedLight, packedOverlay, color);
    }

    @Override
    public void setupAnim(Comerciante entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        // Flota hacia arriba y abajo
        this.flotar.y += Mth.sin(ageInTicks * 0.08F) * 0.8F;
        // La cabeza mira al jugador
        this.cabeza.yRot += netHeadYaw * Mth.DEG_TO_RAD * 0.5F;
        this.cabeza.xRot += headPitch * Mth.DEG_TO_RAD * 0.3F;
    }
}
