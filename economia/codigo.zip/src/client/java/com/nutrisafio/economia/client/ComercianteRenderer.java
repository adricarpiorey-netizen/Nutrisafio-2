package com.nutrisafio.economia.client;

import com.nutrisafio.economia.Comerciante;
import com.nutrisafio.economia.NutriEconomia;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ComercianteRenderer extends MobRenderer<Comerciante, GamboModel> {
    private static final ResourceLocation TEXTURA = NutriEconomia.id("textures/entity/gambo.png");

    public ComercianteRenderer(EntityRendererProvider.Context context) {
        super(context, new GamboModel(JsonModelLoader.load("gambo")), 0.7F);
    }

    @Override
    public ResourceLocation getTextureLocation(Comerciante entity) {
        return TEXTURA;
    }
}
