package com.nutrisafio.economia;

import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.MerchantMenu;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.Merchant;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;

/**
 * Comerciante quieto (como las tragaperras del Casino). Clic derecho = ventana de intercambio.
 * No se mueve, no se empuja, no se puede matar (solo un jugador en creativo o /kill),
 * no desaparece. Sus intercambios se reabastecen cada dia de Minecraft (20 minutos).
 */
public class Comerciante extends PathfinderMob implements Merchant {

    public enum Tipo { GRANJERO, CAMBISTA, TIENDA, BIBLIOTECARIO }

    /** Ticks de un dia de Minecraft: cada cuanto se reabastecen los intercambios. */
    private static final int REABASTECER = 24000;
    /** Los Granjeros se reabastecen cada 5 minutos (6000 ticks). */
    private static final int REABASTECER_GRANJERO = 6000;
    private static final int SIN_LIMITE = 100000;

    private final Tipo tipo;
    private Player cliente;
    private MerchantOffers ofertas;
    private int reloj = 0;
    /** Cada Bibliotecario tiene sus propios libros (como los aldeanos), guardados con esta semilla. */
    private long semillaLibros;
    /** true si los intercambios vienen de un comando (/summon ... {Offers:...}) en vez de los de fabrica. */
    private boolean personalizadas = false;

    public Comerciante(EntityType<? extends PathfinderMob> type, Level level, Tipo tipo) {
        super(type, level);
        this.tipo = tipo;
        this.setPersistenceRequired();
        this.semillaLibros = level.getRandom().nextLong();
    }

    public Tipo getTipo() {
        return tipo;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.0)
                .add(Attributes.FOLLOW_RANGE, 16.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        // Solo mira a los jugadores que tiene cerca
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 8.0f));
    }

    // ---------------- Quieto e indestructible ----------------
    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void doPush(Entity entity) {
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                || (source.getEntity() instanceof Player p && p.getAbilities().instabuild)) {
            return super.hurt(source, amount);
        }
        return false;
    }

    @Override
    public boolean shouldShowName() {
        return true;
    }

    // ---------------- Abrir la tienda ----------------
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        ItemStack enMano = player.getItemInHand(hand);
        if (enMano.getItem() instanceof net.minecraft.world.item.SpawnEggItem || enMano.is(Items.NAME_TAG)) {
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) return InteractionResult.SUCCESS;
        if (this.cliente != null && this.cliente != player && this.cliente.isAlive()
                && this.cliente.containerMenu instanceof MerchantMenu) {
            player.displayClientMessage(Component.literal("Estoy atendiendo a otro jugador, espera un momento")
                    .withStyle(ChatFormatting.YELLOW), true);
            return InteractionResult.CONSUME;
        }
        if (this.getOffers().isEmpty()) return InteractionResult.CONSUME;
        this.setTradingPlayer(player);
        this.openTradingScreen(player, this.getDisplayName(), 0);
        return InteractionResult.CONSUME;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;
        if (this.cliente != null && (!this.cliente.isAlive() || !(this.cliente.containerMenu instanceof MerchantMenu))) {
            this.cliente = null;
        }
        if (++reloj >= (this.tipo == Tipo.GRANJERO ? REABASTECER_GRANJERO : REABASTECER)) {
            reloj = 0;
            if (ofertas != null) for (MerchantOffer o : ofertas) o.resetUses();
        }
    }

    // ---------------- Merchant ----------------
    @Override
    public void setTradingPlayer(Player player) {
        this.cliente = player;
    }

    @Override
    public Player getTradingPlayer() {
        return this.cliente;
    }

    @Override
    public MerchantOffers getOffers() {
        if (this.ofertas == null) {
            this.ofertas = new MerchantOffers();
            switch (tipo) {
                case GRANJERO -> granjero(this.ofertas);
                case CAMBISTA -> cambista(this.ofertas);
                case TIENDA -> tienda(this.ofertas);
                case BIBLIOTECARIO -> bibliotecario(this.ofertas);
            }
        }
        return this.ofertas;
    }

    @Override
    public void overrideOffers(MerchantOffers offers) {
    }

    @Override
    public void notifyTrade(MerchantOffer offer) {
        offer.increaseUses();
        this.playSound(SoundEvents.VILLAGER_YES, 0.6f, 1.2f);
    }

    @Override
    public void notifyTradeUpdated(ItemStack stack) {
    }

    @Override
    public int getVillagerXp() {
        return 0;
    }

    @Override
    public void overrideXp(int xp) {
    }

    @Override
    public boolean showProgressBar() {
        return false;
    }

    @Override
    public SoundEvent getNotifyTradeSound() {
        return SoundEvents.VILLAGER_YES;
    }

    @Override
    public boolean isClientSide() {
        return this.level().isClientSide;
    }

    // ---------------- Intercambios ----------------
    private static Item item(String id) {
        ResourceLocation rl = ResourceLocation.parse(id);
        return BuiltInRegistries.ITEM.containsKey(rl) ? BuiltInRegistries.ITEM.get(rl) : Items.AIR;
    }

    private static final String D = "dedsafio_nutri:";
    private static Item comun() { return item(D + "dedita"); }
    private static Item verde() { return item(D + "dedita_verde"); }
    private static Item roja() { return item(D + "dedita_roja"); }
    private static Item rosa() { return item(D + "dedita_rosa"); }
    private static Item amarilla() { return item(D + "dedita_amarilla"); }
    private static Item morada() { return item(D + "dedita_morada"); }
    private static Item multicolor() { return item(D + "deditamulticolor"); }

    /** Agrega un intercambio (si algun item no existe porque falta un mod, se salta). */
    private static void oferta(MerchantOffers lista, Item paga, int cuanto, Item paga2, int cuanto2,
                               ItemStack recibe, int usos) {
        if (paga == Items.AIR || recibe.isEmpty() || (paga2 != null && paga2 == Items.AIR)) return;
        Optional<ItemCost> segundo = paga2 == null ? Optional.empty() : Optional.of(new ItemCost(paga2, cuanto2));
        lista.add(new MerchantOffer(new ItemCost(paga, cuanto), segundo, recibe, usos, 0, 0.0f));
    }

    private static void oferta(MerchantOffers lista, Item paga, int cuanto, ItemStack recibe, int usos) {
        oferta(lista, paga, cuanto, null, 0, recibe, usos);
    }

    private static ItemStack st(Item item, int n) {
        return item == Items.AIR ? ItemStack.EMPTY : new ItemStack(item, n);
    }

    /** Granjero: te compra cosas faciles de conseguir y te paga 1 Dedita comun. */
    private static void granjero(MerchantOffers o) {
        int usos = 64;   // antes 16: ahora tardan mucho mas en agotarse
        oferta(o, Items.STICK, 12, st(comun(), 1), usos);
        oferta(o, Items.WHEAT, 12, st(comun(), 1), usos);
        oferta(o, Items.CARROT, 12, st(comun(), 1), usos);
        oferta(o, Items.POTATO, 12, st(comun(), 1), usos);
        oferta(o, Items.BEETROOT, 12, st(comun(), 1), usos);
        oferta(o, Items.BAMBOO, 12, st(comun(), 1), usos);
        oferta(o, Items.SUGAR_CANE, 12, st(comun(), 1), usos);
        oferta(o, Items.PUMPKIN, 6, st(comun(), 1), usos);
        oferta(o, Items.MELON, 6, st(comun(), 1), usos);
    }

    /** Cambista: sube y baja de valor. 1 Verde=5, Roja=10, Rosa=25, Amarilla=50, Morada=100, Multicolor=500. */
    private static void cambista(MerchantOffers o) {
        int u = SIN_LIMITE;
        // Subir de valor
        oferta(o, comun(), 5, st(verde(), 1), u);
        oferta(o, verde(), 2, st(roja(), 1), u);
        oferta(o, roja(), 2, verde(), 1, st(rosa(), 1), u);
        oferta(o, rosa(), 2, st(amarilla(), 1), u);
        oferta(o, amarilla(), 2, st(morada(), 1), u);
        oferta(o, morada(), 5, st(multicolor(), 1), u);
        // Bajar de valor (dar cambio)
        oferta(o, verde(), 1, st(comun(), 5), u);
        oferta(o, roja(), 1, st(verde(), 2), u);
        oferta(o, rosa(), 1, st(verde(), 5), u);
        oferta(o, amarilla(), 1, st(rosa(), 2), u);
        oferta(o, morada(), 1, st(amarilla(), 2), u);
        oferta(o, multicolor(), 1, st(morada(), 5), u);
    }

    /** Tienda: vende cosas a cambio de Deditas. */
    private void tienda(MerchantOffers o) {
        oferta(o, comun(), 3, st(item(D + "deditacasino"), 1), 32);
        oferta(o, comun(), 2, st(item(D + "protector_solar_aplicable"), 1), 16);
        oferta(o, comun(), 3, st(item(D + "procectorsolar"), 1), 16);
        oferta(o, comun(), 3, st(item(D + "bomba_bloqueador"), 1), 16);
        oferta(o, comun(), 2, st(Items.COOKED_BEEF, 8), 16);
        oferta(o, comun(), 3, st(Items.GOLDEN_CARROT, 6), 16);
        oferta(o, verde(), 1, st(Items.IRON_INGOT, 4), 12);
        oferta(o, roja(), 1, st(Items.DIAMOND, 1), 8);
        oferta(o, roja(), 1, verde(), 1, st(Items.GOLDEN_APPLE, 1), 8);
        oferta(o, rosa(), 1, st(item("nutrisafio_mobs:blood_drop"), 3), 8);
        oferta(o, amarilla(), 1, libro(Enchantments.PROTECTION, 4), 4);
        oferta(o, amarilla(), 1, libro(Enchantments.SHARPNESS, 5), 4);
        oferta(o, morada(), 1, libro(Enchantments.MENDING, 1), 2);
        oferta(o, morada(), 2, st(Items.ENCHANTED_GOLDEN_APPLE, 1), 2);
        oferta(o, multicolor(), 1, st(item("dedsafio4:totem_nutria"), 1), 1);
    }

    // ---------------- Bibliotecario ----------------
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putLong("SemillaLibros", this.semillaLibros);
        if (this.personalizadas && this.ofertas != null) {
            MerchantOffers.CODEC.encodeStart(this.registryAccess().createSerializationContext(NbtOps.INSTANCE), this.ofertas)
                    .result().ifPresent(t -> tag.put("Offers", t));
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("SemillaLibros")) {
            this.semillaLibros = tag.getLong("SemillaLibros");
            this.ofertas = null;
        }
        // Intercambios personalizados puestos con un comando, igual que en los aldeanos normales
        if (tag.contains("Offers")) {
            MerchantOffers.CODEC.parse(this.registryAccess().createSerializationContext(NbtOps.INSTANCE), tag.get("Offers"))
                    .resultOrPartial(e -> {})
                    .ifPresent(o -> {
                        this.ofertas = o;
                        this.personalizadas = true;
                    });
        }
    }

    /** Encantamiento normal: (clave, nivel maximo). */
    private record Encanto(ResourceKey<Enchantment> key, int max) {}

    private static final List<Encanto> NORMALES = List.of(
            new Encanto(Enchantments.PROTECTION, 4), new Encanto(Enchantments.FIRE_PROTECTION, 4),
            new Encanto(Enchantments.BLAST_PROTECTION, 4), new Encanto(Enchantments.PROJECTILE_PROTECTION, 4),
            new Encanto(Enchantments.FEATHER_FALLING, 4), new Encanto(Enchantments.RESPIRATION, 3),
            new Encanto(Enchantments.AQUA_AFFINITY, 1), new Encanto(Enchantments.THORNS, 3),
            new Encanto(Enchantments.DEPTH_STRIDER, 3), new Encanto(Enchantments.SHARPNESS, 5),
            new Encanto(Enchantments.SMITE, 5), new Encanto(Enchantments.BANE_OF_ARTHROPODS, 5),
            new Encanto(Enchantments.KNOCKBACK, 2), new Encanto(Enchantments.FIRE_ASPECT, 2),
            new Encanto(Enchantments.LOOTING, 3), new Encanto(Enchantments.SWEEPING_EDGE, 3),
            new Encanto(Enchantments.EFFICIENCY, 5), new Encanto(Enchantments.SILK_TOUCH, 1),
            new Encanto(Enchantments.UNBREAKING, 3), new Encanto(Enchantments.FORTUNE, 3),
            new Encanto(Enchantments.POWER, 5), new Encanto(Enchantments.PUNCH, 2),
            new Encanto(Enchantments.FLAME, 1), new Encanto(Enchantments.INFINITY, 1),
            new Encanto(Enchantments.LUCK_OF_THE_SEA, 3), new Encanto(Enchantments.LURE, 3),
            new Encanto(Enchantments.LOYALTY, 3), new Encanto(Enchantments.IMPALING, 5),
            new Encanto(Enchantments.RIPTIDE, 3), new Encanto(Enchantments.CHANNELING, 1),
            new Encanto(Enchantments.MULTISHOT, 1), new Encanto(Enchantments.QUICK_CHARGE, 3),
            new Encanto(Enchantments.PIERCING, 4));

    /** Libros "tesoro" (los mas valiosos): se pagan con Dedita Morada. */
    private static final List<Encanto> TESOROS = List.of(
            new Encanto(Enchantments.MENDING, 1), new Encanto(Enchantments.FROST_WALKER, 2),
            new Encanto(Enchantments.SOUL_SPEED, 3), new Encanto(Enchantments.SWIFT_SNEAK, 3));

    /**
     * Bibliotecario: como el aldeano, cada uno tiene 6 libros distintos al azar.
     * Precio: nivel bajo = Verde, nivel medio = Roja, nivel maximo = Rosa (o Amarilla si el maximo es IV/V),
     * libro tesoro = Morada. Tambien compra papel y libros, y vende estanterias y etiquetas.
     */
    private void bibliotecario(MerchantOffers o) {
        RandomSource r = RandomSource.create(this.semillaLibros);
        oferta(o, Items.PAPER, 24, st(comun(), 1), 16);
        oferta(o, Items.BOOK, 4, st(comun(), 1), 12);
        List<Encanto> lista = new ArrayList<>(NORMALES);
        for (int i = 0; i < 6 && !lista.isEmpty(); i++) {
            Encanto e = lista.remove(r.nextInt(lista.size()));
            int nivel = 1 + r.nextInt(e.max());
            Item precio;
            if (e.max() == 1) precio = roja();
            else if (nivel == e.max()) precio = e.max() >= 4 ? amarilla() : rosa();
            else if (nivel == 1) precio = verde();
            else precio = roja();
            oferta(o, precio, 1, libro(e.key(), nivel), 4);
        }
        // 1 de cada 2 bibliotecarios tiene ademas un libro tesoro
        if (r.nextBoolean()) {
            Encanto t = TESOROS.get(r.nextInt(TESOROS.size()));
            oferta(o, morada(), 1, libro(t.key(), 1 + r.nextInt(t.max())), 2);
        }
        oferta(o, comun(), 1, st(Items.BOOKSHELF, 1), 16);
        oferta(o, verde(), 1, st(Items.NAME_TAG, 1), 8);
    }

    private ItemStack libro(ResourceKey<Enchantment> key, int nivel) {
        Holder<Enchantment> e = this.level().registryAccess().registryOrThrow(Registries.ENCHANTMENT).getHolderOrThrow(key);
        return EnchantedBookItem.createForEnchantment(new EnchantmentInstance(e, nivel));
    }

    @Override
    public void playAmbientSound() {
    }

    @Override
    public SoundSource getSoundSource() {
        return SoundSource.NEUTRAL;
    }
}
