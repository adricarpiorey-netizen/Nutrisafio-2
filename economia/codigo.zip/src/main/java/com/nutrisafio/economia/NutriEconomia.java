package com.nutrisafio.economia;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SpawnEggItem;

/**
 * Nutrisafio Economia: comerciantes quietos (modelo "Gambo") que usan las Deditas como dinero.
 * - Granjero: te COMPRA palos, cultivos y bambu y te paga con Deditas.
 * - Cambista: cambia Deditas de un valor a otro (como monedas y billetes).
 * - Tienda: te VENDE cosas a cambio de Deditas.
 */
public class NutriEconomia implements ModInitializer {

    public static final String MOD_ID = "nutri_economia";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    private static EntityType<Comerciante> comerciante(String name, Comerciante.Tipo tipo) {
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, id(name),
                EntityType.Builder.<Comerciante>of((type, level) -> new Comerciante(type, level, tipo), MobCategory.MISC)
                        .sized(1.2f, 2.1f)
                        .clientTrackingRange(10)
                        .build(name));
    }

    public static final EntityType<Comerciante> GRANJERO = comerciante("granjero", Comerciante.Tipo.GRANJERO);
    public static final EntityType<Comerciante> CAMBISTA = comerciante("cambista", Comerciante.Tipo.CAMBISTA);
    public static final EntityType<Comerciante> TIENDA = comerciante("tienda", Comerciante.Tipo.TIENDA);

    private static Item huevo(String name, EntityType<Comerciante> type, int c1, int c2) {
        return Registry.register(BuiltInRegistries.ITEM, id(name + "_spawn_egg"),
                new SpawnEggItem(type, c1, c2, new Item.Properties()));
    }

    public static final Item HUEVO_GRANJERO = huevo("granjero", GRANJERO, 0xC9A23A, 0x5BAA3C);
    public static final Item HUEVO_CAMBISTA = huevo("cambista", CAMBISTA, 0xC9A23A, 0xE8E8E8);
    public static final Item HUEVO_TIENDA = huevo("tienda", TIENDA, 0xC9A23A, 0xD9452B);

    public static final CreativeModeTab TAB = Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("economia"),
            FabricItemGroup.builder()
                    .title(Component.translatable("itemGroup.nutri_economia"))
                    .icon(() -> new ItemStack(HUEVO_CAMBISTA))
                    .displayItems((params, output) -> {
                        output.accept(HUEVO_GRANJERO);
                        output.accept(HUEVO_CAMBISTA);
                        output.accept(HUEVO_TIENDA);
                    })
                    .build());

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(GRANJERO, Comerciante.createAttributes());
        FabricDefaultAttributeRegistry.register(CAMBISTA, Comerciante.createAttributes());
        FabricDefaultAttributeRegistry.register(TIENDA, Comerciante.createAttributes());
    }
}
