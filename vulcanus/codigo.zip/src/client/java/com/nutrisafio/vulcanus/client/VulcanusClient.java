package com.nutrisafio.vulcanus.client;

import com.nutrisafio.vulcanus.Vulcanus;
import com.nutrisafio.vulcanus.VulcanusArmorItem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.world.item.Item;

public class VulcanusClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        VulcanusArmorRenderer renderer = new VulcanusArmorRenderer();
        for (Item item : Vulcanus.TODOS) {
            if (item instanceof VulcanusArmorItem) {
                ArmorRenderer.register(renderer, item);
            }
        }
    }
}
