package com.nutrisafio.vulcanus.client;

import com.nutrisafio.vulcanus.VulcanusArmorItem;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;

public class VulcanusClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        VulcanusArmorItem.RENDER_HOOK = (item, consumer) -> consumer.accept(new GeoRenderProvider() {
            private VulcanusArmorRenderer renderer;

            @Override
            public <T extends LivingEntity> HumanoidModel<?> getGeoArmorRenderer(T entity, ItemStack stack, EquipmentSlot slot, HumanoidModel<T> original) {
                if (this.renderer == null) this.renderer = new VulcanusArmorRenderer(item.tectonic);
                return this.renderer;
            }
        });
    }
}
