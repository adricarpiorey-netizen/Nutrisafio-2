package com.nutrisafio.vulcanus.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.nutrisafio.vulcanus.Vulcanus;
import com.nutrisafio.vulcanus.VulcanusArmorItem;
import java.io.DataInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.armortrim.ArmorTrim;

/**
 * Dibuja el modelo 3D de Blockbench de la armadura Vulcanus pegado al cuerpo del jugador.
 * La lava brilla (luz completa) en la version Tectonica y su color cambia con el diseno (trim).
 */
public class VulcanusArmorRenderer implements ArmorRenderer {
    private static final ResourceLocation[] TEXTURES = {
            Vulcanus.id("textures/armor/vulcanus_0.png"),
            Vulcanus.id("textures/armor/vulcanus_1.png")};
    private static final ResourceLocation[] TEXTURES_LAVA = {
            Vulcanus.id("textures/armor/vulcanus_0_lava.png"),
            Vulcanus.id("textures/armor/vulcanus_1_lava.png")};
    private static final int FULL_BRIGHT = 0xF000F0;

    /** Una cara: 4 vertices (x,y,z,u,v) + normal. */
    private record Quad(int tex, boolean glow, float[] v, float nx, float ny, float nz) {}

    /** [slot][parte] -> caras. slot: 0 casco, 1 pechera, 2 pantalon, 3 botas. parte: cabeza, cuerpo, brazoD, brazoI, piernaD, piernaI */
    @SuppressWarnings("unchecked")
    private final List<Quad>[][] quads = new List[4][6];

    public VulcanusArmorRenderer() {
        for (int s = 0; s < 4; s++) for (int p = 0; p < 6; p++) quads[s][p] = new ArrayList<>();
        try (InputStream in = VulcanusArmorRenderer.class.getResourceAsStream("/assets/vulcanus/armor/vulcanus_armor.bin")) {
            DataInputStream data = new DataInputStream(in);
            int n = data.readInt();
            for (int i = 0; i < n; i++) {
                int part = data.readByte(), slot = data.readByte(), tex = data.readByte();
                boolean glow = data.readByte() != 0;
                float[] v = new float[20];
                for (int k = 0; k < 20; k++) v[k] = data.readFloat();
                // normal de la cara
                float ax = v[5] - v[0], ay = v[6] - v[1], az = v[7] - v[2];
                float bx = v[10] - v[0], by = v[11] - v[1], bz = v[12] - v[2];
                float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
                float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (len < 1.0e-6F) { nx = 0; ny = 1; nz = 0; } else { nx /= len; ny /= len; nz /= len; }
                quads[slot][part].add(new Quad(tex, glow, v, nx, ny, nz));
            }
        } catch (Exception e) {
            Vulcanus.LOGGER.error("No pude cargar el modelo 3D de la armadura Vulcanus", e);
        }
    }

    @Override
    public void render(PoseStack matrices, MultiBufferSource buffers, ItemStack stack, LivingEntity entity,
                       EquipmentSlot slot, int light, HumanoidModel<LivingEntity> model) {
        int s = switch (slot) {
            case HEAD -> 0; case CHEST -> 1; case LEGS -> 2; case FEET -> 3; default -> -1;
        };
        if (s < 0) return;
        boolean tectonic = stack.getItem() instanceof VulcanusArmorItem a && a.tectonic;
        int lava = 0xFFFFFF;
        ArmorTrim trim = stack.get(DataComponents.TRIM);
        if (trim != null) {
            TextColor c = trim.material().value().description().getStyle().getColor();
            if (c != null) lava = c.getValue();
        }
        boolean tenir = tectonic && lava != 0xFFFFFF;
        ModelPart[] parts = {model.head, model.body, model.rightArm, model.leftArm, model.rightLeg, model.leftLeg};
        for (int p = 0; p < 6; p++) {
            List<Quad> list = quads[s][p];
            if (list.isEmpty() || !parts[p].visible) continue;
            matrices.pushPose();
            parts[p].translateAndRotate(matrices);
            PoseStack.Pose pose = matrices.last();
            for (int t = 0; t < 4; t++) {
                // t 0/1: textura normal | t 2/3: lava en gris para pintarla del color del diseno
                boolean gris = t >= 2;
                if (gris && !tenir) continue;
                VertexConsumer vc = buffers.getBuffer(RenderType.armorCutoutNoCull(gris ? TEXTURES_LAVA[t - 2] : TEXTURES[t]));
                for (Quad q : list) {
                    if (q.tex != (t & 1)) continue;
                    if (tenir && q.glow != gris) continue;
                    int r = 255, g = 255, b = 255, l = light;
                    if (q.glow) {
                        if (tectonic) {
                            l = FULL_BRIGHT;
                            r = (lava >> 16) & 255; g = (lava >> 8) & 255; b = lava & 255;
                        } else {
                            r = 70; g = 50; b = 45; // brasas apagadas en la version base
                        }
                    }
                    for (int k = 0; k < 4; k++) {
                        int o = k * 5;
                        vc.addVertex(pose, q.v[o], q.v[o + 1], q.v[o + 2])
                                .setColor(r, g, b, 255)
                                .setUv(q.v[o + 3], q.v[o + 4])
                                .setOverlay(OverlayTexture.NO_OVERLAY)
                                .setLight(l)
                                .setNormal(pose, q.nx, q.ny, q.nz);
                    }
                }
            }
            matrices.popPose();
        }
    }
}
