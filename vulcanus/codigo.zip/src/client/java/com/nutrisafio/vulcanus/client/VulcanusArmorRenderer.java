package com.nutrisafio.vulcanus.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.nutrisafio.vulcanus.Vulcanus;
import com.nutrisafio.vulcanus.VulcanusArmorItem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.armortrim.ArmorTrim;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoArmorRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/**
 * Dibuja la armadura Vulcanus en 3D. La lava brilla en la oscuridad y,
 * si la pieza tiene un diseno (trim), la lava toma el color del material del diseno.
 */
public class VulcanusArmorRenderer extends GeoArmorRenderer<VulcanusArmorItem> {
    static final int LAVA = 0xFFFF8A2A;

    public VulcanusArmorRenderer(boolean tectonic) {
        super(new Model(tectonic));
        addRenderLayer(new LavaLayer(this));
    }

    int lavaColor() {
        ItemStack stack = getCurrentStack();
        if (stack == null) return LAVA;
        ArmorTrim trim = stack.get(DataComponents.TRIM);
        if (trim == null) return LAVA;
        TextColor color = trim.material().value().description().getStyle().getColor();
        return color == null ? LAVA : (0xFF000000 | color.getValue());
    }

    static class LavaLayer extends AutoGlowingGeoLayer<VulcanusArmorItem> {
        private final VulcanusArmorRenderer owner;

        LavaLayer(VulcanusArmorRenderer owner) {
            super(owner);
            this.owner = owner;
        }

        @Override
        public void render(PoseStack poseStack, VulcanusArmorItem animatable, BakedGeoModel bakedModel, RenderType renderType,
                           MultiBufferSource bufferSource, VertexConsumer buffer, float partialTick, int packedLight, int packedOverlay) {
            RenderType glow = getRenderType(animatable, bufferSource);
            if (glow == null) return;
            getRenderer().reRender(bakedModel, poseStack, bufferSource, animatable, glow, bufferSource.getBuffer(glow),
                    partialTick, 15728640, packedOverlay, owner.lavaColor());
        }
    }

    static class Model extends GeoModel<VulcanusArmorItem> {
        private final ResourceLocation texture;

        Model(boolean tectonic) {
            this.texture = Vulcanus.id(tectonic ? "textures/armor/vulcanus_tectonic.png" : "textures/armor/vulcanus.png");
        }

        @Override
        public ResourceLocation getModelResource(VulcanusArmorItem animatable) {
            return Vulcanus.id("geo/armor/vulcanus.geo.json");
        }

        @Override
        public ResourceLocation getTextureResource(VulcanusArmorItem animatable) {
            return this.texture;
        }

        @Override
        public ResourceLocation getAnimationResource(VulcanusArmorItem animatable) {
            return Vulcanus.id("animations/armor/vulcanus.animation.json");
        }
    }
}
