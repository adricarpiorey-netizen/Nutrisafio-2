package com.nutrisafio.vulcanus.mixin;

import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Arreglo: algunos mods (Alex's Caves al alimentar/domesticar dinosaurios) crean particulas de un objeto
 * y despues gastan ese mismo objeto. Al enviarse la particula el objeto ya esta vacio y el servidor
 * desconecta a los jugadores cercanos ("Empty ItemStack not allowed").
 * Guardamos una copia del objeto en la particula para que nunca quede vacia.
 */
@Mixin(ItemParticleOption.class)
public class ItemParticleOptionMixin {
    @Shadow @Final @Mutable private ItemStack itemStack;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void vulcanus$copiarObjeto(CallbackInfo ci) {
        ItemStack copia = this.itemStack == null ? ItemStack.EMPTY : this.itemStack.copy();
        this.itemStack = copia.isEmpty() ? new ItemStack(Items.BONE_MEAL) : copia;
    }
}
