package com.nutrisafio.vulcanus;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;

public class Vulcanus implements ModInitializer {
    public static final String MOD_ID = "vulcanus";
    public static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger("vulcanus");

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    static Ingredient deAlexsCaves(String id) {
        Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(id));
        return Ingredient.of(item == Items.AIR ? Items.NETHERITE_INGOT : item);
    }

    static Holder<ArmorMaterial> material(String name, int helmet, int chest, int legs, int boots, int enchant,
                                          float toughness, float knockback, String repair) {
        EnumMap<ArmorItem.Type, Integer> def = new EnumMap<>(ArmorItem.Type.class);
        def.put(ArmorItem.Type.HELMET, helmet);
        def.put(ArmorItem.Type.CHESTPLATE, chest);
        def.put(ArmorItem.Type.LEGGINGS, legs);
        def.put(ArmorItem.Type.BOOTS, boots);
        def.put(ArmorItem.Type.BODY, chest);
        return Registry.registerForHolder(BuiltInRegistries.ARMOR_MATERIAL, id(name),
                new ArmorMaterial(def, enchant, SoundEvents.ARMOR_EQUIP_NETHERITE, () -> deAlexsCaves(repair),
                        List.of(new ArmorMaterial.Layer(id(name))), toughness, knockback));
    }

    // Base: 7 de defensa (como cuero) | Tectonica: 30 de defensa
    public static final Holder<ArmorMaterial> MAT_NORMAL = material("vulcanus", 1, 3, 2, 1, 15, 0.0F, 0.0F, "nutrisafio_mobs:wither_bone");
    public static final Holder<ArmorMaterial> MAT_TECTONICA = material("vulcanus_tectonic", 5, 11, 9, 5, 18, 5.0F, 0.2F, "alexscaves:tectonic_shard");

    public static final List<Item> TODOS = new ArrayList<>();

    static <T extends Item> T item(String name, T item) {
        Registry.register(BuiltInRegistries.ITEM, id(name), item);
        TODOS.add(item);
        return item;
    }

    static Item.Properties props(boolean tectonic) {
        Item.Properties p = new Item.Properties().rarity(tectonic ? Rarity.EPIC : Rarity.UNCOMMON);
        return tectonic ? p.fireResistant() : p;
    }

    static void armadura(String prefijo, Holder<ArmorMaterial> mat, int durabilidad, boolean tectonic) {
        item(prefijo + "_helmet", new VulcanusArmorItem(mat, ArmorItem.Type.HELMET,
                props(tectonic).durability(ArmorItem.Type.HELMET.getDurability(durabilidad)), tectonic));
        item(prefijo + "_chestplate", new VulcanusArmorItem(mat, ArmorItem.Type.CHESTPLATE,
                props(tectonic).durability(ArmorItem.Type.CHESTPLATE.getDurability(durabilidad)), tectonic));
        item(prefijo + "_leggings", new VulcanusArmorItem(mat, ArmorItem.Type.LEGGINGS,
                props(tectonic).durability(ArmorItem.Type.LEGGINGS.getDurability(durabilidad)), tectonic));
        item(prefijo + "_boots", new VulcanusArmorItem(mat, ArmorItem.Type.BOOTS,
                props(tectonic).durability(ArmorItem.Type.BOOTS.getDurability(durabilidad)), tectonic));
    }

    static void herramientas(String prefijo, VulcanusTier t, boolean tectonic) {
        item(prefijo + "_sword", new SwordItem(t, props(tectonic).attributes(SwordItem.createAttributes(t, 3, -2.4F))));
        item(prefijo + "_pickaxe", new PickaxeItem(t, props(tectonic).attributes(PickaxeItem.createAttributes(t, 1.0F, -2.8F))));
        item(prefijo + "_axe", new AxeItem(t, props(tectonic).attributes(AxeItem.createAttributes(t, 5.0F, -3.0F))));
        item(prefijo + "_shovel", new ShovelItem(t, props(tectonic).attributes(ShovelItem.createAttributes(t, 1.5F, -3.0F))));
        item(prefijo + "_hoe", new HoeItem(t, props(tectonic).attributes(HoeItem.createAttributes(t, -4.0F, 0.0F))));
    }


    @Override
    public void onInitialize() {
        armadura("vulcanus", MAT_NORMAL, 7, false);
        herramientas("vulcanus", VulcanusTier.NORMAL, false);
        armadura("vulcanus_tectonic", MAT_TECTONICA, 50, true);
        herramientas("vulcanus_tectonic", VulcanusTier.TECTONICA, true);

        // Pestana propia en el modo creativo
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("vulcanus"), FabricItemGroup.builder()
                .title(Component.literal("Vulcanus"))
                .icon(() -> new ItemStack(BuiltInRegistries.ITEM.get(id("vulcanus_tectonic_chestplate"))))
                .displayItems((params, output) -> TODOS.forEach(output::accept))
                .build());

    }
}
