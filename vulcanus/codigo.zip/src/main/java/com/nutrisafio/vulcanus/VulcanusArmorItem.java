package com.nutrisafio.vulcanus;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Pieza de armadura Vulcanus. Se dibuja en 3D con GeckoLib (puas, cuernos y lava). */
public class VulcanusArmorItem extends ArmorItem implements GeoItem {
    /** Lo llena el lado del cliente con el dibujador 3D. En el servidor no hace nada. */
    public static BiConsumer<VulcanusArmorItem, Consumer<GeoRenderProvider>> RENDER_HOOK = (item, consumer) -> {};

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    public final boolean tectonic;

    public VulcanusArmorItem(Holder<ArmorMaterial> material, ArmorItem.Type type, Properties properties, boolean tectonic) {
        super(material, type, properties);
        this.tectonic = tectonic;
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        RENDER_HOOK.accept(this, consumer);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {}

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        if (this.tectonic) {
            lines.add(Component.literal("Forjada con el corazon del volcan").withStyle(ChatFormatting.GOLD));
        } else {
            lines.add(Component.literal("Mejorala: Plantilla de netherita + Fragmento Tectonico").withStyle(ChatFormatting.DARK_GRAY));
        }
    }
}
