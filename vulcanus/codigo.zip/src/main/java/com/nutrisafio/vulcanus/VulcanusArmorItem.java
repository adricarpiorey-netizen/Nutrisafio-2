package com.nutrisafio.vulcanus;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** Pieza de armadura Vulcanus. El modelo 3D lo dibuja VulcanusArmorRenderer (lado cliente). */
public class VulcanusArmorItem extends ArmorItem {
    public final boolean tectonic;

    public VulcanusArmorItem(Holder<ArmorMaterial> material, ArmorItem.Type type, Properties properties, boolean tectonic) {
        super(material, type, properties);
        this.tectonic = tectonic;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        if (this.tectonic) {
            lines.add(Component.literal("Forjada con el corazon del volcan").withStyle(ChatFormatting.GOLD));
        } else {
            lines.add(Component.literal("Mejorala: Plantilla de netherita + Fragmento Tectonico").withStyle(ChatFormatting.DARK_GRAY));
        }
    }
}
