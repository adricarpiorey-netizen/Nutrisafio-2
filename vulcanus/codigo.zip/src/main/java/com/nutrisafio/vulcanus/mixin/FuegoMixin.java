package com.nutrisafio.vulcanus.mixin;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Nutrisafio: si un jugador se esta quemando, el fuego NO se apaga solo.
 * Solo se apaga con agua (meterse al agua, lluvia o burbujas), o al morir.
 */
@Mixin(Entity.class)
public abstract class FuegoMixin {
    @Inject(method = "baseTick", at = @At("HEAD"))
    private void vulcanus$fuegoEterno(CallbackInfo ci) {
        Entity self = (Entity) (Object) this;
        if (!(self instanceof ServerPlayer p)) return;
        if (p.isCreative() || p.isSpectator()) return;
        int fuego = p.getRemainingFireTicks();
        if (fuego <= 0 || p.isInWaterRainOrBubble() || p.fireImmune()) return;
        // nunca deja que se acabe: cuando baja de 2 segundos lo vuelve a subir a 3
        if (fuego < 40) p.setRemainingFireTicks(60);
    }
}
