package com.nutrisafio.vulcanus;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;

/** Material de las herramientas Vulcanus. */
public enum VulcanusTier implements Tier {
    // Base (dientes y huesos): como las de piedra
    NORMAL(180, 4.0F, 1.0F, 5, "nutrisafio_mobs:wither_bone", BlockTags.INCORRECT_FOR_STONE_TOOL),
    // Mejorada con el Fragmento Tectonico
    TECTONICA(3200, 11.0F, 6.0F, 18, "alexscaves:tectonic_shard", BlockTags.INCORRECT_FOR_NETHERITE_TOOL);

    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchant;
    private final String repair;
    private final TagKey<Block> incorrect;

    VulcanusTier(int uses, float speed, float damage, int enchant, String repair, TagKey<Block> incorrect) {
        this.uses = uses; this.speed = speed; this.damage = damage; this.enchant = enchant; this.repair = repair; this.incorrect = incorrect;
    }

    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return speed; }
    @Override public float getAttackDamageBonus() { return damage; }
    @Override public TagKey<Block> getIncorrectBlocksForDrops() { return incorrect; }
    @Override public int getEnchantmentValue() { return enchant; }
    @Override public Ingredient getRepairIngredient() {
        var item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(repair));
        return Ingredient.of(item == Items.AIR ? Items.NETHERITE_INGOT : item);
    }
}
