package com.nutrisafio.vulcanus.mixin;

import net.minecraft.world.level.NaturalSpawner;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

/**
 * Nutrisafio: los mobs pueden aparecer desde 8 bloques del jugador (en vanilla es 24).
 * El juego compara la distancia al cuadrado: 24*24 = 576  ->  8*8 = 64.
 */
@Mixin(NaturalSpawner.class)
public class SpawnCercaMixin {
    @ModifyConstant(method = "isRightDistanceToPlayerAndSpawnPoint", constant = @Constant(doubleValue = 576.0), require = 0)
    private static double vulcanus$distanciaMinima(double original) {
        return 64.0;
    }
}
