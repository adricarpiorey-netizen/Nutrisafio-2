package com.nutrisafio.cielorojo;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Paquete del servidor al jugador: cielo rojo encendido (true) o apagado (false). */
public record CieloPayload(boolean active) implements CustomPacketPayload {
   public static final CustomPacketPayload.Type<CieloPayload> TYPE =
      new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath("cielorojo", "estado"));
   public static final StreamCodec<RegistryFriendlyByteBuf, CieloPayload> CODEC =
      StreamCodec.composite(ByteBufCodecs.BOOL, CieloPayload::active, CieloPayload::new);

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
