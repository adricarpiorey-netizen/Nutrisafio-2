package com.nutrisafio.cielorojo.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public class RedSkyRenderer {
   private static final ResourceLocation RED_SKY_TEXTURE = ResourceLocation.fromNamespaceAndPath("revill", "textures/environment/vortex.png");
   private static final float TRANSITION_SPEED = 0.01F;
   private boolean active;
   private float transition;

   public void setActive(boolean active) {
      if (active && !this.active) {
         this.transition = 0.0F;
      }

      this.active = active;
   }

   public boolean isActive() {
      return this.transition > 0.01F;
   }

   public boolean shouldTintSky() {
      return this.isActive();
   }

   public float getTransition() {
      return this.transition;
   }

   public void tick(Minecraft client) {
      if (this.active) {
         this.transition = Math.min(1.0F, this.transition + 0.01F);
      } else {
         this.transition = Math.max(0.0F, this.transition - 0.01F);
      }
   }

   public void renderSky(PoseStack matrices, Camera camera, float tickDelta) {
      if (this.isActive()) {
         ;
      }
   }

   public void renderOverlay(GuiGraphics context) {
      if (this.isActive()) {
         int width = context.guiWidth();
         int height = context.guiHeight();
         float reveal = Math.min(1.0F, Math.max(0.0F, this.transition));
         int alpha = (int)(40.0F * reveal);
         int color = alpha << 24 | 0xFF0000;
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         context.fill(0, 0, width, height, color);
         RenderSystem.disableBlend();
      }
   }
}
