package com.nutrisafio.cielorojo.client;

import com.nutrisafio.cielorojo.CieloPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

@Environment(EnvType.CLIENT)
public class CieloRojoClient implements ClientModInitializer {
   public static final RedSkyRenderer SKY = new RedSkyRenderer();
   public static final ZenithAnimationRenderer ZENITH = new ZenithAnimationRenderer();

   @Override
   public void onInitializeClient() {
      ClientPlayNetworking.registerGlobalReceiver(CieloPayload.TYPE, (payload, context) -> {
         if (payload.active()) {
            // Cielo rojo + grieta que se abre con temblor + musica
            SKY.setActive(true);
            ZENITH.start();
            RevillEventAudio.start();
         } else {
            // La musica se apaga, la grieta se cierra con temblor y luego el cielo vuelve a la normalidad
            RevillEventAudio.stop();
            ZENITH.stop(SKY);
         }
      });
      ClientTickEvents.END_CLIENT_TICK.register(client -> SKY.tick(client));
      HudRenderCallback.EVENT.register((context, tickCounter) -> SKY.renderOverlay(context));
      ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
         RevillEventAudio.stop();
         RevillEventAudio.stopRift();
         ZENITH.reset();
         SKY.setActive(false);
      });
   }
}
