package com.nutrisafio.cielorojo.client;


import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public final class ZenithAnimationRenderer {
   private static final int FRAMES_PER_SECOND = 12;
   private static final long FRAME_DURATION_NANOS = 83333333L;
   private static final int EXIT_FRAME_COUNT = 165;
   private static final int LOOP_FRAME_COUNT = 141;
   private static final float HALF_WIDTH = 60.0F;
   private static final float HALF_DEPTH = 30.0F;
   private static final float HEIGHT = 112.0F;
   private static final String FRAME_PREFIX = "textures/environment/zenith/";
   private ZenithAnimationRenderer.State state = ZenithAnimationRenderer.State.IDLE;
   private int frameIndex;
   private long frameElapsedNanos;
   private long lastFrameTimeNanos;

   public void start() {
      if (this.state == ZenithAnimationRenderer.State.IDLE || this.state == ZenithAnimationRenderer.State.CLOSING) {
         this.state = ZenithAnimationRenderer.State.WAITING_FOR_SKY;
         this.frameElapsedNanos = 0L;
         this.lastFrameTimeNanos = 0L;
      }
   }

   public void stop(RedSkyRenderer skyRenderer) {
      if (this.state == ZenithAnimationRenderer.State.IDLE) {
         skyRenderer.setActive(false);
      } else if (this.state != ZenithAnimationRenderer.State.CLOSING) {
         this.state = ZenithAnimationRenderer.State.CLOSING;
         this.frameIndex = 0;
         this.frameElapsedNanos = 0L;
         this.lastFrameTimeNanos = System.nanoTime();
         RevillEventAudio.startRift();
      }
   }

   public float getCameraShakeStrength() {
      float progress;
      if (this.state == ZenithAnimationRenderer.State.OPENING_REVERSE) {
         progress = (float)(164 - this.frameIndex) / 164.0F;
      } else {
         if (this.state != ZenithAnimationRenderer.State.CLOSING) {
            return 0.0F;
         }

         progress = (float)this.frameIndex / 164.0F;
      }

      float fade = Math.min(progress, 1.0F - progress) / 0.1F;
      return Math.max(0.0F, Math.min(1.0F, fade));
   }

   public void reset() {
      RevillEventAudio.stopRift();
      this.state = ZenithAnimationRenderer.State.IDLE;
      this.frameIndex = 0;
      this.frameElapsedNanos = 0L;
      this.lastFrameTimeNanos = 0L;
   }

   public void render(PoseStack matrices, RedSkyRenderer skyRenderer) {
      long now = System.nanoTime();
      if (this.state == ZenithAnimationRenderer.State.WAITING_FOR_SKY && skyRenderer.getTransition() >= 1.0F) {
         this.state = ZenithAnimationRenderer.State.OPENING_REVERSE;
         this.frameIndex = 164;
         this.frameElapsedNanos = 0L;
         this.lastFrameTimeNanos = now;
         RevillEventAudio.startRift();
      }

      if (this.state != ZenithAnimationRenderer.State.IDLE) {
         if (this.lastFrameTimeNanos == 0L) {
            this.lastFrameTimeNanos = now;
         } else {
            this.frameElapsedNanos = this.frameElapsedNanos + (now - this.lastFrameTimeNanos);
            this.lastFrameTimeNanos = now;
         }

         while (this.frameElapsedNanos >= 83333333L) {
            this.frameElapsedNanos -= 83333333L;
            this.advanceFrame(skyRenderer);
            if (this.state == ZenithAnimationRenderer.State.IDLE) {
               break;
            }
         }

         if (this.state != ZenithAnimationRenderer.State.IDLE) {
            ResourceLocation texture = this.getCurrentTexture();
            if (texture != null) {
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               RenderSystem.disableDepthTest();
               RenderSystem.depthMask(false);
               RenderSystem.disableCull();
               RenderSystem.setShader(GameRenderer::getPositionTexShader);
               RenderSystem.setShaderTexture(0, texture);
               Matrix4f matrix = matrices.last().pose();
               BufferBuilder buffer = Tesselator.getInstance().begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
               buffer.addVertex(matrix, -60.0F, 112.0F, -30.0F).setUv(0.0F, 0.0F);
               buffer.addVertex(matrix, -60.0F, 112.0F, 30.0F).setUv(0.0F, 1.0F);
               buffer.addVertex(matrix, 60.0F, 112.0F, 30.0F).setUv(1.0F, 1.0F);
               buffer.addVertex(matrix, 60.0F, 112.0F, -30.0F).setUv(1.0F, 0.0F);
               BufferUploader.drawWithShader(buffer.buildOrThrow());
               RenderSystem.depthMask(true);
               RenderSystem.enableDepthTest();
               RenderSystem.enableCull();
               RenderSystem.disableBlend();
            }
         }
      }
   }

   private void advanceFrame(RedSkyRenderer skyRenderer) {
      switch (this.state) {
         case OPENING_REVERSE:
            this.frameIndex--;
            if (this.frameIndex < 0) {
               this.state = ZenithAnimationRenderer.State.LOOP;
               this.frameIndex = 0;
               RevillEventAudio.stopRift();
            }
            break;
         case LOOP:
            this.frameIndex = (this.frameIndex + 1) % 141;
            break;
         case CLOSING:
            this.frameIndex++;
            if (this.frameIndex >= 165) {
               RevillEventAudio.stopRift();
               this.reset();
               skyRenderer.setActive(false);
            }
      }
   }

   private ResourceLocation getCurrentTexture() {
      return switch (this.state) {
         case OPENING_REVERSE, CLOSING -> this.exitTexture(this.frameIndex);
         case LOOP -> this.loopTexture(this.frameIndex);
         default -> null;
      };
   }

   private ResourceLocation exitTexture(int index) {
      return ResourceLocation.fromNamespaceAndPath("revill", "textures/environment/zenith/" + "salir/frame_%04d.png".formatted(index + 1));
   }

   private ResourceLocation loopTexture(int index) {
      return ResourceLocation.fromNamespaceAndPath("revill", "textures/environment/zenith/" + "loop/frame_%04d.png".formatted(index + 1));
   }

   @Environment(EnvType.CLIENT)
   private static enum State {
      IDLE,
      WAITING_FOR_SKY,
      OPENING_REVERSE,
      LOOP,
      CLOSING;
   }
}
