package com.nutrisafio.cielorojo;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public class CieloRojoMod implements ModInitializer {
   /** Si el cielo rojo esta encendido (se usa para los que entran despues). */
   public static boolean activo = false;

   @Override
   public void onInitialize() {
      PayloadTypeRegistry.playS2C().register(CieloPayload.TYPE, CieloPayload.CODEC);

      CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
         dispatcher.register(Commands.literal("cielo")
            .requires(source -> source.hasPermission(2))
            .then(Commands.literal("on").executes(context -> {
               setActivo(context.getSource().getServer(), true);
               context.getSource().sendSuccess(() -> Component.literal("Cielo rojo activado."), true);
               return 1;
            }))
            .then(Commands.literal("off").executes(context -> {
               setActivo(context.getSource().getServer(), false);
               context.getSource().sendSuccess(() -> Component.literal("Cielo rojo desactivado."), true);
               return 1;
            }))));

      ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
         if (activo) {
            enviar(handler.getPlayer(), true);
         }
      });
   }

   public static void setActivo(MinecraftServer server, boolean valor) {
      activo = valor;
      for (ServerPlayer player : server.getPlayerList().getPlayers()) {
         enviar(player, valor);
      }
   }

   private static void enviar(ServerPlayer player, boolean valor) {
      if (ServerPlayNetworking.canSend(player, CieloPayload.TYPE)) {
         ServerPlayNetworking.send(player, new CieloPayload(valor));
      }
   }
}
