package com.eric.revill.client.network;

import com.eric.revill.client.network.NetClient;
import com.eric.revill.RevillClient;
import com.eric.revill.client.render.ClientWaypointManager;
import com.eric.revill.client.sound.RevillEventAudio;
import com.eric.revill.dedsafio4.Dedsafio4Networking;
import com.eric.revill.mail.MailInboxScreenHandler;
import com.eric.revill.mail.MailNetworking;
import com.eric.revill.network.RevillNetworking;
import com.eric.revill.waypoint.Waypoint;
import com.eric.revill.waypoint.WaypointManager;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

@Environment(EnvType.CLIENT)
public final class RevillClientNetworking {
   private RevillClientNetworking() {
   }

   public static void register() {
      NetClient.on(RevillNetworking.EVENT_STATE, (client, buf) -> {
         boolean active = buf.readBoolean();
         int remainingSeconds = buf.readInt();
         boolean skyActive = buf.readBoolean();
         boolean announcementActive = buf.readBoolean();
         client.execute(() -> {
            if (active) {
               RevillEventAudio.start();
            } else {
               RevillEventAudio.stop();
            }

            if (active && skyActive) {
               RevillClient.SKY_RENDERER.setActive(true);
               RevillClient.ZENITH_ANIMATION_RENDERER.start();
            } else {
               RevillClient.ZENITH_ANIMATION_RENDERER.stop(RevillClient.SKY_RENDERER);
            }

            if (!active || !announcementActive) {
               RevillClient.ANNOUNCEMENT_RENDERER.stop();
            } else if (!RevillClient.ANNOUNCEMENT_RENDERER.isActive()) {
               RevillClient.ANNOUNCEMENT_RENDERER.setActive(true);
            }

            RevillClient.HUD_RENDERER.setEventState(active, remainingSeconds);
         });
      });
      NetClient.on(RevillNetworking.ANNOUNCEMENT, (client, buf) -> {
         int durationSeconds = buf.readInt();
         double flashSpeed = buf.readDouble();
         client.execute(() -> {
            RevillClient.ANNOUNCEMENT_RENDERER.setDurationSeconds(durationSeconds);
            RevillClient.ANNOUNCEMENT_RENDERER.setFlashSpeed(flashSpeed);
            RevillClient.ANNOUNCEMENT_RENDERER.start();
         });
      });
      NetClient.on(RevillNetworking.STOP_EVENT, (client, buf) -> {
         buf.readBoolean();
         client.execute(() -> {
            RevillEventAudio.stop();
            RevillClient.ZENITH_ANIMATION_RENDERER.stop(RevillClient.SKY_RENDERER);
            RevillClient.ANNOUNCEMENT_RENDERER.stop();
            RevillClient.HUD_RENDERER.setEventState(false, 0);
            RevillClient.HUD_RENDERER.stopRoulette();
         });
      });
      NetClient.on(RevillNetworking.ROULETTE, (client, buf) -> {
         String color = buf.readUtf();
         String result = buf.readUtf();
         client.execute(() -> RevillClient.HUD_RENDERER.startRoulette(color, result));
      });
      NetClient.on(RevillNetworking.ROULETTE_ANNOUNCEMENT, (client, buf) -> {
         String color = buf.readUtf(32);
         String message = buf.readUtf(32767);
         client.execute(() -> RevillClient.HUD_RENDERER.showAnnouncementCard(message, color));
      });
      NetClient.on(RevillNetworking.NUTRIA_ANIMATION, (client, buf) -> client.execute(() -> RevillClient.HUD_RENDERER.startNutriaAnimation())
      );
      NetClient.on(RevillNetworking.REVILL_INTRO_DEATH, (client, buf) -> client.execute(() -> RevillClient.HUD_RENDERER.startRevillIntroDeathAnimation())
      );
      NetClient.on(RevillNetworking.SKY_ONLY, (client, buf) -> {
         boolean active = buf.readBoolean();
         client.execute(() -> {
            if (active) {
               // Igual que el evento: cielo rojo + grieta (zenith) que se abre con temblor + musica
               RevillClient.SKY_RENDERER.setActive(true);
               RevillClient.ZENITH_ANIMATION_RENDERER.start();
               RevillEventAudio.start();
            } else {
               // La grieta se cierra (con temblor) y luego el cielo vuelve a la normalidad
               RevillEventAudio.stop();
               RevillClient.ZENITH_ANIMATION_RENDERER.stop(RevillClient.SKY_RENDERER);
            }
         });
      });
      NetClient.on(MailNetworking.INBOX_SYNC, (client, buf) -> {
         int syncId = buf.readVarInt();
         List<MailInboxScreenHandler.MailView> mails = MailNetworking.readInbox(buf);
         client.execute(() -> {
            if (client.player != null && client.player.containerMenu instanceof MailInboxScreenHandler inbox && inbox.containerId == syncId) {
               inbox.setMails(mails);
            }
         });
      });
      NetClient.on(Dedsafio4Networking.DEATH_ACTIONBAR, (client, buf) -> {
         String playerName = buf.readUtf();
         String reason = buf.readUtf();
         boolean self = buf.readBoolean();
         client.execute(() -> RevillClient.HUD_RENDERER.showDeathNotice(playerName, reason, self));
      });
      NetClient.on(Dedsafio4Networking.FUSION_TOGGLE, (client, buf) -> {
         boolean enabled = buf.readBoolean();
         client.execute(() -> RevillClient.FUSION_RENDERER.setEnabled(enabled));
      });
      NetClient.on(WaypointManager.SYNC_WAYPOINTS, (client, buf) -> {
         List<Waypoint> waypoints = WaypointManager.decodeWaypoints(buf);
         client.execute(() -> ClientWaypointManager.setWaypoints(waypoints));
      });
   }
}
