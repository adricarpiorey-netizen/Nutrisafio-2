package com.eric.revill;

import com.eric.revill.client.network.NetClient;
import com.eric.revill.client.network.EconomyClientNetworking;
import com.eric.revill.client.network.RevillClientNetworking;
import com.eric.revill.client.render.CajeroEntityModel;
import com.eric.revill.client.render.CajeroEntityRenderer;
import com.eric.revill.client.render.ClientWaypointManager;
import com.eric.revill.client.render.CurrencyHudRenderer;
import com.eric.revill.client.render.Dedsafio4HudRenderer;
import com.eric.revill.client.render.FusionRenderer;
import com.eric.revill.client.render.RedEventAnnouncementRenderer;
import com.eric.revill.client.render.RedSkyRenderer;
import com.eric.revill.client.render.ZenithAnimationRenderer;
import com.eric.revill.client.sound.RevillEventAudio;
import com.eric.revill.client.ui.AtmDepositScreen;
import com.eric.revill.client.ui.Dedsafio4Screen;
import com.eric.revill.client.ui.MailComposeScreen;
import com.eric.revill.client.ui.MailInboxScreen;
import com.eric.revill.dedsafio4.Dedsafio4Networking;
import com.eric.revill.economy.AtmScreenHandler;
import com.eric.revill.entity.ModEntities;
import com.eric.revill.mail.MailComposeScreenHandler;
import com.eric.revill.mail.MailInboxScreenHandler;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;

@Environment(EnvType.CLIENT)
public class RevillClient implements ClientModInitializer {
   public static final RedSkyRenderer SKY_RENDERER = new RedSkyRenderer();
   public static final RedEventAnnouncementRenderer ANNOUNCEMENT_RENDERER = new RedEventAnnouncementRenderer();
   public static final Dedsafio4HudRenderer HUD_RENDERER = new Dedsafio4HudRenderer();
   public static final FusionRenderer FUSION_RENDERER = new FusionRenderer();
   public static final ZenithAnimationRenderer ZENITH_ANIMATION_RENDERER = new ZenithAnimationRenderer();

   public void onInitializeClient() {
      RevillClientNetworking.register();
      EconomyClientNetworking.register();
      EntityModelLayerRegistry.registerModelLayer(CajeroEntityModel.LAYER, CajeroEntityModel::getTexturedModelData);
      EntityRendererRegistry.register(ModEntities.CAJERO, CajeroEntityRenderer::new);
      MenuScreens.register(AtmScreenHandler.TYPE, AtmDepositScreen::new);
      MenuScreens.register(MailInboxScreenHandler.TYPE, MailInboxScreen::new);
      MenuScreens.register(MailComposeScreenHandler.TYPE, MailComposeScreen::new);
      HudRenderCallback.EVENT.register((HudRenderCallback)(context, tickDelta) -> {
         HUD_RENDERER.render(context);
         CurrencyHudRenderer.render(context);
         Minecraft client = Minecraft.getInstance();
         if (client != null) {
            ANNOUNCEMENT_RENDERER.render(context, client.font, context.guiWidth(), context.guiHeight());
         }
      });
      NetClient.on(Dedsafio4Networking.OPEN_MENU, (client, buf) -> client.execute(() -> {
            if (client.player != null) {
               client.setScreen(new Dedsafio4Screen());
            }
         }));
      NetClient.on(Dedsafio4Networking.DEATH_ANIMATION, (client, buf) -> client.execute(() -> HUD_RENDERER.startDeathAnimation())
      );
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> {
         FUSION_RENDERER.tick();
         HUD_RENDERER.tick();
         HUD_RENDERER.handleAnnouncementCardKey(client);
         ClientWaypointManager.tick();
         CurrencyHudRenderer.tick();
         ANNOUNCEMENT_RENDERER.tick(client);
         SKY_RENDERER.tick(client);
      });
      ClientCommandRegistrationCallback.EVENT
         .register(
            (ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> {
               dispatcher.register(
                  (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("fusion").executes(context -> {
                     FUSION_RENDERER.toggle();
                     return 1;
                  })).then(ClientCommandManager.literal("entrar").executes(context -> {
                     FUSION_RENDERER.setEnabled(true);
                     return 1;
                  }))).then(ClientCommandManager.literal("salir").executes(context -> {
                     FUSION_RENDERER.setEnabled(false);
                     return 1;
                  }))
               );
               dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("revill").executes(context -> {
                  FUSION_RENDERER.toggle();
                  return 1;
               })).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("fusion").executes(context -> {
                  FUSION_RENDERER.toggle();
                  return 1;
               })).then(ClientCommandManager.literal("entrar").executes(context -> {
                  FUSION_RENDERER.setEnabled(true);
                  return 1;
               }))).then(ClientCommandManager.literal("salir").executes(context -> {
                  FUSION_RENDERER.setEnabled(false);
                  return 1;
               }))));
            }
         );
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> {
         ClientWaypointManager.clear();
         RevillEventAudio.stop();
         RevillEventAudio.stopRift();
         SKY_RENDERER.setActive(false);
         ZENITH_ANIMATION_RENDERER.reset();
         ANNOUNCEMENT_RENDERER.stop();
         HUD_RENDERER.setEventState(false, 0);
         FUSION_RENDERER.reset();
      });
   }
}
