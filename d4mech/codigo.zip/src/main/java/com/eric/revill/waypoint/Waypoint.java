package com.eric.revill.waypoint;

import net.minecraft.core.BlockPos;

public class Waypoint {
   private final String id;
   private final String name;
   private final BlockPos pos;
   private final String icon;
   private final int color;
   private final String dimension;

   public Waypoint(String id, String name, BlockPos pos, String icon, int color, String dimension) {
      this.id = id;
      this.name = name;
      this.pos = pos;
      this.icon = icon;
      this.color = color;
      this.dimension = dimension;
   }

   public String getId() {
      return this.id;
   }

   public String getName() {
      return this.name;
   }

   public BlockPos getPos() {
      return this.pos;
   }

   public String getIcon() {
      return this.icon;
   }

   public int getColor() {
      return this.color;
   }

   public String getDimension() {
      return this.dimension;
   }
}
