package com.eric.revill.mail;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

public class Mail {
   private final UUID senderId;
   private final String senderName;
   private final String subject;
   private final String message;
   private final List<ItemStack> items;
   private boolean read;

   public Mail(UUID senderId, String senderName, String subject, String message, List<ItemStack> items) {
      this.senderId = senderId;
      this.senderName = senderName;
      this.subject = subject;
      this.message = message;
      this.items = new ArrayList<>();

      for (ItemStack stack : items) {
         if (!stack.isEmpty()) {
            this.items.add(stack.copy());
         }
      }
   }

   public UUID getSenderId() {
      return this.senderId;
   }

   public String getSenderName() {
      return this.senderName;
   }

   public String getSubject() {
      return this.subject;
   }

   public String getMessage() {
      return this.message;
   }

   public List<ItemStack> getItems() {
      return this.items;
   }

   public boolean isRead() {
      return this.read;
   }

   public void setRead(boolean read) {
      this.read = read;
   }

   public Component getDisplayTitle() {
      return Component.literal(this.senderName + " — " + this.subject);
   }
}
