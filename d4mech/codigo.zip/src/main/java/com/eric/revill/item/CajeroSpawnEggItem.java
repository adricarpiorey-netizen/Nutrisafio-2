package com.eric.revill.item;

import com.eric.revill.entity.CajeroEntity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.phys.AABB;

public final class CajeroSpawnEggItem extends SpawnEggItem {
   public CajeroSpawnEggItem(EntityType<? extends Mob> entityType, int primaryColor, int secondaryColor, Properties settings) {
      super(entityType, primaryColor, secondaryColor, settings);
   }

   public InteractionResult useOn(UseOnContext context) {
      if (!context.getLevel().isClientSide && context.getPlayer() != null) {
         AABB spawnArea = new AABB(context.getClickedPos()).inflate(3.0);
         List<UUID> existingEntities = new ArrayList<>();

         for (CajeroEntity entity : context.getLevel().getEntitiesOfClass(CajeroEntity.class, spawnArea, ignored -> true)) {
            existingEntities.add(entity.getUUID());
         }

         InteractionResult result = super.useOn(context);
         if (!result.consumesAction()) {
            return result;
         } else {
            Player spawner = context.getPlayer();
            Iterator var6 = context.getLevel()
               .getEntitiesOfClass(CajeroEntity.class, spawnArea, candidate -> !existingEntities.contains(candidate.getUUID()))
               .iterator();
            if (var6.hasNext()) {
               CajeroEntity entity = (CajeroEntity)var6.next();
               entity.initializeSpawnFacing(spawner);
            }

            return result;
         }
      } else {
         return super.useOn(context);
      }
   }
}
