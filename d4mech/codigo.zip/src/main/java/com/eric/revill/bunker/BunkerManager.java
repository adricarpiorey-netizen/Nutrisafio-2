package com.eric.revill.bunker;

import com.eric.revill.event.RedEventState;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public final class BunkerManager {
   private static final Bunker EMPTY_BUNKER = new Bunker();
   private static Bunker activeBunker = new Bunker();

   private BunkerManager() {
   }

   public static void setBunker(MinecraftServer server, BlockPos firstCorner, BlockPos secondCorner) {
      if (server != null) {
         ServerLevel world = server.overworld();
         activeBunker = new Bunker();
         activeBunker.setDimension(world.dimension().location().toString());
         activeBunker.setFirstCorner(firstCorner);
         activeBunker.setSecondCorner(secondCorner);
      }
   }

   public static Bunker getBunker() {
      return activeBunker == null ? EMPTY_BUNKER : activeBunker;
   }

   public static void clear() {
      activeBunker = EMPTY_BUNKER;
   }

   public static boolean isConfigured() {
      return getBunker().isConfigured();
   }

   public static boolean isPlayerInside(ServerPlayer player) {
      return player == null ? false : getBunker().contains(player.blockPosition());
   }

   public static void applyToState(RedEventState state) {
      if (state != null) {
         state.setBunker(getBunker());
      }
   }
}
