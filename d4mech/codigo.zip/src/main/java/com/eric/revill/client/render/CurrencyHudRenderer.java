package com.eric.revill.client.render;

import com.eric.revill.economy.CurrencyType;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

@Environment(EnvType.CLIENT)
public final class CurrencyHudRenderer {
   private static final int[] BALANCES = new int[3];
   private static final double[] DISPLAYED = new double[3];
   private static int changedTicks;
   private static boolean increased;

   private CurrencyHudRenderer() {
   }

   public static void setBalances(int blue, int red, int green) {
      int[] next = new int[]{Math.max(0, blue), Math.max(0, red), Math.max(0, green)};

      for (int index = 0; index < BALANCES.length; index++) {
         if (next[index] != BALANCES[index]) {
            increased = next[index] > BALANCES[index];
            changedTicks = 24;
            BALANCES[index] = next[index];
         }
      }
   }

   public static int[] getBalances() {
      return (int[])BALANCES.clone();
   }

   public static void tick() {
      for (int index = 0; index < DISPLAYED.length; index++) {
         DISPLAYED[index] = DISPLAYED[index] + ((double)BALANCES[index] - DISPLAYED[index]) * 0.28;
         if (Math.abs((double)BALANCES[index] - DISPLAYED[index]) < 0.5) {
            DISPLAYED[index] = (double)BALANCES[index];
         }
      }

      if (changedTicks > 0) {
         changedTicks--;
      }
   }

   public static void render(GuiGraphics context) {
      Minecraft client = Minecraft.getInstance();
      if (client != null && client.player != null && !client.options.hideGui) {
         CurrencyType[] visibleTypes = getVisibleTypes();
         if (visibleTypes.length != 0) {
            int padding = 5;
            int itemSize = 16;
            int gap = 8;
            int maxDigits = 1;

            for (CurrencyType type : visibleTypes) {
               int index = type.ordinal();
               maxDigits = Math.max(maxDigits, Integer.toString(BALANCES[index]).length());
            }

            int panelWidth = padding * 2 + visibleTypes.length * (itemSize + gap + maxDigits * 6);
            int panelHeight = padding * 2 + itemSize;
            int left = context.guiWidth() - panelWidth - 10;
            int top = 10;
            context.fill(left + 4, top, left + panelWidth - 4, top + panelHeight, -921561829);
            context.fill(left + 2, top + 2, left + panelWidth - 2, top + panelHeight - 2, -921561829);
            context.fill(left, top + 4, left + panelWidth, top + panelHeight - 4, -921561829);
            context.fill(left + 4, top + 3, left + panelWidth - 4, top + 4, -805306369);

            for (int i = 0; i < visibleTypes.length; i++) {
               CurrencyType type = visibleTypes[i];
               int index = type.ordinal();
               int x = left + padding + i * (itemSize + gap + maxDigits * 6);
               int textWidth = client.font.width(format(DISPLAYED[index]));
               int iconX = x + textWidth + 4;
               int color = changedTicks > 0 ? (increased ? -9443958 : -37006) : -920587;
               context.drawString(client.font, Component.literal(format(DISPLAYED[index])), x, top + padding + 4, color);
               RenderSystem.setShaderColor(1.35F, 1.35F, 1.35F, 1.0F);

               try {
                  context.renderItem(new ItemStack(type.item()), iconX, top + padding);
               } finally {
                  RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
               }
            }
         }
      }
   }

   private static CurrencyType[] getVisibleTypes() {
      CurrencyType[] all = CurrencyType.values();
      List<CurrencyType> visible = new ArrayList<>();

      for (CurrencyType type : all) {
         if (type == CurrencyType.AZUL || BALANCES[type.ordinal()] > 0) {
            visible.add(type);
         }
      }

      if (visible.isEmpty()) {
         visible.add(CurrencyType.AZUL);
      }

      return visible.toArray(new CurrencyType[0]);
   }

   private static String format(double value) {
      return String.format(Locale.ROOT, "%,d", Math.round(value));
   }
}
