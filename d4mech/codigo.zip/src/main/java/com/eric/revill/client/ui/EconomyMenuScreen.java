package com.eric.revill.client.ui;

import com.eric.revill.client.network.NetClient;
import com.eric.revill.economy.EconomyNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;

@Environment(EnvType.CLIENT)
public final class EconomyMenuScreen extends Screen {
   private static final String[] ACTIONS = new String[]{"Añadir", "Quitar", "Ver"};
   private static final String[] TYPES = new String[]{"Azul", "Roja", "Verde"};
   private int selectedAction = 0;
   private int selectedType = 0;
   private int amount = 1;

   public EconomyMenuScreen() {
      super(Component.literal("Coins"));
   }

   protected void init() {
      int centerX = this.width / 2;
      int centerY = this.height / 2;
      this.addRenderableWidget(Button.builder(Component.literal(ACTIONS[0]), button -> {
         this.selectedAction = 0;
         this.sendAction();
      }).bounds(centerX - 170, centerY - 80, 120, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal(ACTIONS[1]), button -> {
         this.selectedAction = 1;
         this.sendAction();
      }).bounds(centerX - 170, centerY - 50, 120, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal(ACTIONS[2]), button -> {
         this.selectedAction = 2;
         this.sendAction();
      }).bounds(centerX - 170, centerY - 20, 120, 20).build());
      this.addRenderableWidget(
         Button.builder(Component.literal("Tipo: " + TYPES[this.selectedType]), button -> this.selectedType = (this.selectedType + 1) % TYPES.length)
            .bounds(centerX + 10, centerY - 80, 170, 20)
            .build()
      );
      this.addRenderableWidget(
         Button.builder(Component.literal("-"), button -> this.amount = Math.max(1, this.amount - 1)).bounds(centerX + 10, centerY - 50, 40, 20).build()
      );
      this.addRenderableWidget(
         Button.builder(Component.literal("+"), button -> this.amount = Math.min(10000, this.amount + 1)).bounds(centerX + 60, centerY - 50, 40, 20).build()
      );
      this.addRenderableWidget(Button.builder(Component.literal("Cantidad: " + this.amount), button -> {
      }).bounds(centerX + 110, centerY - 50, 70, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("Cerrar"), button -> this.onClose()).bounds(centerX - 60, centerY + 30, 120, 20).build());
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      context.fill(0, 0, this.width, this.height, -16777216);
      super.render(context, mouseX, mouseY, delta);
      int centerX = this.width / 2;
      int centerY = this.height / 2;
      context.drawCenteredString(this.font, Component.literal("Menú de monedas"), centerX, centerY - 120, -1);
      context.drawCenteredString(this.font, Component.literal("Acción actual: " + ACTIONS[this.selectedAction]), centerX, centerY - 100, -1);
      context.drawCenteredString(this.font, Component.literal("Tipo: " + TYPES[this.selectedType]), centerX + 90, centerY - 85, -1);
      context.drawCenteredString(this.font, Component.literal("Cantidad: " + this.amount), centerX + 90, centerY - 25, -1);
   }

   private void sendAction() {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeVarInt(this.selectedAction);
      buf.writeVarInt(this.selectedType);
      buf.writeVarInt(this.amount);
      NetClient.send(EconomyNetworking.COINS_ACTION, buf);
      this.onClose();
   }

   public boolean isPauseScreen() {
      return false;
   }

   @Override
   public void renderBackground(GuiGraphics context, int mouseX, int mouseY, float delta) {
   }
}
