package com.eric.revill.mail;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;

public class MailInboxScreenHandler extends AbstractContainerMenu {
   public static final MenuType<MailInboxScreenHandler> TYPE = net.minecraft.core.Registry.register(net.minecraft.core.registries.BuiltInRegistries.MENU,
      ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mail_inbox"),
      new net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType<>(MailInboxScreenHandler::new, MailNetworking.INBOX_CODEC)
   );
   private final List<MailInboxScreenHandler.MailView> mails;

   public MailInboxScreenHandler(int syncId, Inventory playerInventory) {
      super(TYPE, syncId);
      this.mails = new ArrayList<>();
   }

   public MailInboxScreenHandler(int syncId, Inventory playerInventory, List<MailInboxScreenHandler.MailView> data) {
      super(TYPE, syncId);
      this.mails = new ArrayList<>(data);
   }

   public static ExtendedScreenHandlerFactory<List<MailInboxScreenHandler.MailView>> inboxFactory() {
      return new ExtendedScreenHandlerFactory<List<MailInboxScreenHandler.MailView>>() {
         public List<MailInboxScreenHandler.MailView> getScreenOpeningData(ServerPlayer player) {
            return MailNetworking.toViews(MailManager.INSTANCE.snapshot(player.getUUID()));
         }

         public Component getDisplayName() {
            return Component.literal("Buzón de correo");
         }

         public AbstractContainerMenu createMenu(int syncId, Inventory inventory, Player player) {
            return new MailInboxScreenHandler(syncId, inventory);
         }
      };
   }

   public static MenuType<MailInboxScreenHandler> initialize() {
      return TYPE;
   }

   public List<MailInboxScreenHandler.MailView> getMails() {
      return this.mails;
   }

   public void setMails(List<MailInboxScreenHandler.MailView> updatedMails) {
      this.mails.clear();
      this.mails.addAll(updatedMails);
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public boolean clickMenuButton(Player player, int id) {
      return false;
   }

   public ItemStack quickMoveStack(Player player, int slotIndex) {
      return ItemStack.EMPTY;
   }

   public static final class MailView {
      private final String sender;
      private final String message;
      private final boolean read;
      private final List<ItemStack> items;

      public MailView(String sender, String message, boolean read, List<ItemStack> items) {
         this.sender = sender;
         this.message = message;
         this.read = read;
         this.items = items;
      }

      public String sender() {
         return this.sender;
      }

      public String message() {
         return this.message;
      }

      public boolean read() {
         return this.read;
      }

      public List<ItemStack> items() {
         return this.items;
      }
   }
}
