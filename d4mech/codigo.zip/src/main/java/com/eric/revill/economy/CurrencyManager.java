package com.eric.revill.economy;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

public final class CurrencyManager {
   private static final String STATE_ID = "dedsafio4_economy";

   private CurrencyManager() {
   }

   public static int getCurrency(MinecraftServer server, UUID playerId, CurrencyType type) {
      return state(server).get(playerId, type);
   }

   public static int[] getCurrencies(MinecraftServer server, UUID playerId) {
      CurrencyManager.AccountState state = state(server);
      return new int[]{state.get(playerId, CurrencyType.AZUL), state.get(playerId, CurrencyType.ROJA), state.get(playerId, CurrencyType.VERDE)};
   }

   public static void addCurrency(MinecraftServer server, UUID playerId, CurrencyType type, int amount) {
      if (amount > 0) {
         CurrencyManager.AccountState state = state(server);
         state.set(playerId, type, Math.addExact(state.get(playerId, type), amount));
         state.setDirty();
         syncOnlinePlayer(server, playerId);
      }
   }

   public static boolean subtractCurrency(MinecraftServer server, UUID playerId, CurrencyType type, int amount) {
      if (amount <= 0) {
         return false;
      } else {
         CurrencyManager.AccountState state = state(server);
         int balance = state.get(playerId, type);
         if (balance < amount) {
            return false;
         } else {
            state.set(playerId, type, balance - amount);
            state.setDirty();
            syncOnlinePlayer(server, playerId);
            return true;
         }
      }
   }

   public static boolean subtractCurrencies(MinecraftServer server, UUID playerId, int[] amounts) {
      if (amounts.length != CurrencyType.values().length) {
         return false;
      } else {
         CurrencyManager.AccountState state = state(server);

         for (CurrencyType type : CurrencyType.values()) {
            int amount = amounts[type.ordinal()];
            if (amount < 0 || state.get(playerId, type) < amount) {
               return false;
            }
         }

         for (CurrencyType typex : CurrencyType.values()) {
            state.set(playerId, typex, state.get(playerId, typex) - amounts[typex.ordinal()]);
         }

         state.setDirty();
         syncOnlinePlayer(server, playerId);
         return true;
      }
   }

   public static void setCurrency(MinecraftServer server, UUID playerId, CurrencyType type, int amount) {
      CurrencyManager.AccountState state = state(server);
      state.set(playerId, type, Math.max(0, amount));
      state.setDirty();
      syncOnlinePlayer(server, playerId);
   }

   public static void sync(ServerPlayer player) {
      EconomyNetworking.syncBalances(player, getCurrencies(player.getServer(), player.getUUID()));
   }

   private static void syncOnlinePlayer(MinecraftServer server, UUID playerId) {
      ServerPlayer player = server.getPlayerList().getPlayer(playerId);
      if (player != null) {
         sync(player);
      }
   }

   private static CurrencyManager.AccountState state(MinecraftServer server) {
      ServerLevel world = server.overworld();
      return (CurrencyManager.AccountState)world.getDataStorage()
         .computeIfAbsent(new SavedData.Factory<>(CurrencyManager.AccountState::new, (tag, lookup) -> CurrencyManager.AccountState.fromNbt(tag), null), "dedsafio4_economy");
   }

   private static final class AccountState extends SavedData {
      private final Map<UUID, int[]> balances = new HashMap<>();

      private int get(UUID playerId, CurrencyType type) {
         int[] values = this.balances.get(playerId);
         return values == null ? 0 : values[type.ordinal()];
      }

      private void set(UUID playerId, CurrencyType type, int value) {
         int[] values = this.balances.computeIfAbsent(playerId, ignored -> new int[CurrencyType.values().length]);
         values[type.ordinal()] = value;
      }

      private static CurrencyManager.AccountState fromNbt(CompoundTag nbt) {
         CurrencyManager.AccountState state = new CurrencyManager.AccountState();

         for (String uuidKey : nbt.getAllKeys()) {
            try {
               UUID playerId = UUID.fromString(uuidKey);
               CompoundTag playerNbt = nbt.getCompound(uuidKey);
               int[] values = new int[CurrencyType.values().length];

               for (CurrencyType type : CurrencyType.values()) {
                  values[type.ordinal()] = Math.max(0, playerNbt.getInt(type.key()));
               }

               state.balances.put(playerId, values);
            } catch (IllegalArgumentException var11) {
            }
         }

         return state;
      }

      public CompoundTag save(CompoundTag nbt, net.minecraft.core.HolderLookup.Provider registries) {
         this.balances.forEach((playerId, values) -> {
            CompoundTag playerNbt = new CompoundTag();

            for (CurrencyType type : CurrencyType.values()) {
               playerNbt.putInt(type.key(), values[type.ordinal()]);
            }

            nbt.put(playerId.toString(), playerNbt);
         });
         return nbt;
      }
   }
}
