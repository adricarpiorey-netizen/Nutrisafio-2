package com.eric.revill.mail;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public final class MailManager {
   public static final MailManager INSTANCE = new MailManager();
   private final Map<UUID, List<Mail>> inboxes = new ConcurrentHashMap<>();

   private MailManager() {
   }

   public List<Mail> getInbox(UUID playerId) {
      return this.inboxes.computeIfAbsent(playerId, ignored -> new ArrayList<>());
   }

   public int getUnreadCount(UUID playerId) {
      int count = 0;

      for (Mail mail : this.getInbox(playerId)) {
         if (!mail.isRead()) {
            count++;
         }
      }

      return count;
   }

   public boolean hasUnread(UUID playerId) {
      return this.getUnreadCount(playerId) > 0;
   }

   public void send(UUID recipientId, UUID senderId, String senderName, String subject, String message, List<ItemStack> items) {
      Mail mail = new Mail(senderId, senderName, subject, message, items);
      this.getInbox(recipientId).add(0, mail);
   }

   public void markRead(UUID playerId, int index) {
      List<Mail> mails = this.getInbox(playerId);
      if (index >= 0 && index < mails.size()) {
         mails.get(index).setRead(true);
      }
   }

   public void claimItems(UUID playerId, int index, Player player) {
      List<Mail> mails = this.getInbox(playerId);
      if (index >= 0 && index < mails.size()) {
         Mail mail = mails.get(index);
         Iterator<ItemStack> items = mail.getItems().iterator();

         while (items.hasNext()) {
            ItemStack stack = items.next();
            if (stack.isEmpty()) {
               items.remove();
            } else {
               ItemStack remainder = stack.copy();
               if (!player.getInventory().add(remainder) && !remainder.isEmpty()) {
                  player.drop(remainder, false);
               }

               items.remove();
            }
         }
      }
   }

   public Mail getMail(UUID playerId, int index) {
      List<Mail> mails = this.getInbox(playerId);
      return index >= 0 && index < mails.size() ? mails.get(index) : null;
   }

   public List<Mail> snapshot(UUID playerId) {
      return Collections.unmodifiableList(new ArrayList<>(this.getInbox(playerId)));
   }

   public void notifyRecipient(ServerPlayer recipient, String senderName) {
      recipient.displayClientMessage(Component.literal("Has recibido un correo de " + senderName + "."), false);
   }
}
