package com.eric.revill.client.network;

import com.eric.revill.client.network.NetClient;
import com.eric.revill.client.render.CurrencyHudRenderer;
import com.eric.revill.client.ui.AtmScreen;
import com.eric.revill.client.ui.AtmWithdrawScreen;
import com.eric.revill.client.ui.EconomyMenuScreen;
import com.eric.revill.economy.EconomyNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.FriendlyByteBuf;

@Environment(EnvType.CLIENT)
public final class EconomyClientNetworking {
   private EconomyClientNetworking() {
   }

   public static void register() {
      NetClient.on(EconomyNetworking.OPEN_ATM, (client, buf) -> client.execute(() -> client.setScreen(new AtmScreen()))
      );
      NetClient.on(EconomyNetworking.OPEN_COINS_MENU, (client, buf) -> client.execute(() -> client.setScreen(new EconomyMenuScreen()))
      );
      NetClient.on(EconomyNetworking.OPEN_WITHDRAW_UI, (client, buf) -> client.execute(() -> client.setScreen(new AtmWithdrawScreen()))
      );
      NetClient.on(EconomyNetworking.BALANCE_SYNC, (client, buf) -> {
         int blue = buf.readVarInt();
         int red = buf.readVarInt();
         int green = buf.readVarInt();
         client.execute(() -> CurrencyHudRenderer.setBalances(blue, red, green));
      });
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> CurrencyHudRenderer.setBalances(0, 0, 0));
   }

   public static void sendWithdrawRequest(int blue, int red, int green) {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeVarInt(blue);
      buf.writeVarInt(red);
      buf.writeVarInt(green);
      NetClient.send(EconomyNetworking.WITHDRAW, buf);
   }
}
