package com.eric.revill.network;

import com.eric.revill.dedsafio4.Dedsafio4Networking;
import com.eric.revill.economy.EconomyNetworking;
import com.eric.revill.mail.MailNetworking;
import com.eric.revill.waypoint.WaypointManager;
import io.netty.buffer.Unpooled;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Capa de compatibilidad: en 1.20.1 los paquetes eran "ID + bytes".
 * En 1.21.1 cada paquete necesita un tipo (CustomPacketPayload).
 * Aqui se crea un tipo generico por cada ID que solo transporta los bytes.
 */
public final class Net {
   public record Data(CustomPacketPayload.Type<Data> type, byte[] bytes) implements CustomPacketPayload {
   }

   public interface ServerHandler {
      void handle(MinecraftServer server, ServerPlayer player, RegistryFriendlyByteBuf buf);
   }

   private static final Map<ResourceLocation, CustomPacketPayload.Type<Data>> TYPES = new HashMap<>();

   private Net() {
   }

   public static CustomPacketPayload.Type<Data> type(ResourceLocation id) {
      CustomPacketPayload.Type<Data> t = TYPES.get(id);
      if (t == null) {
         throw new IllegalStateException("Paquete no registrado: " + id);
      }
      return t;
   }

   private static void register(ResourceLocation id) {
      if (TYPES.containsKey(id)) {
         return;
      }
      CustomPacketPayload.Type<Data> t = new CustomPacketPayload.Type<>(id);
      StreamCodec<RegistryFriendlyByteBuf, Data> codec = StreamCodec.of((buf, p) -> {
         buf.writeVarInt(p.bytes().length);
         buf.writeBytes(p.bytes());
      }, buf -> {
         int len = buf.readVarInt();
         byte[] b = new byte[len];
         buf.readBytes(b);
         return new Data(t, b);
      });
      PayloadTypeRegistry.playS2C().register(t, codec);
      PayloadTypeRegistry.playC2S().register(t, codec);
      TYPES.put(id, t);
   }

   private static void registerAllIn(Class<?> c) {
      for (Field f : c.getDeclaredFields()) {
         if (Modifier.isStatic(f.getModifiers()) && f.getType() == ResourceLocation.class) {
            try {
               f.setAccessible(true);
               register((ResourceLocation)f.get(null));
            } catch (IllegalAccessException e) {
               throw new RuntimeException(e);
            }
         }
      }
   }

   /** Registra todos los IDs de paquetes del mod (llamar en el inicio comun). */
   public static void init() {
      registerAllIn(RevillNetworking.class);
      registerAllIn(Dedsafio4Networking.class);
      registerAllIn(EconomyNetworking.class);
      registerAllIn(MailNetworking.class);
      registerAllIn(WaypointManager.class);
   }

   public static byte[] bytesOf(FriendlyByteBuf buf) {
      byte[] b = new byte[buf.readableBytes()];
      buf.getBytes(buf.readerIndex(), b);
      return b;
   }

   public static RegistryFriendlyByteBuf wrap(byte[] bytes, RegistryAccess access) {
      return new RegistryFriendlyByteBuf(Unpooled.wrappedBuffer(bytes), access);
   }

   public static RegistryFriendlyByteBuf create(RegistryAccess access) {
      return new RegistryFriendlyByteBuf(Unpooled.buffer(), access);
   }

   public static void send(ServerPlayer player, ResourceLocation id, FriendlyByteBuf buf) {
      if (player != null && ServerPlayNetworking.canSend(player, type(id))) {
         ServerPlayNetworking.send(player, new Data(type(id), bytesOf(buf)));
      }
   }

   public static void onServer(ResourceLocation id, ServerHandler handler) {
      ServerPlayNetworking.registerGlobalReceiver(type(id), (payload, context) -> {
         ServerPlayer player = context.player();
         handler.handle(player.server, player, wrap(payload.bytes(), player.registryAccess()));
      });
   }
}
