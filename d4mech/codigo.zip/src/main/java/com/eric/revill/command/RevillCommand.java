package com.eric.revill.command;

import com.eric.revill.RevillMod;
import com.eric.revill.bunker.BunkerManager;
import com.eric.revill.config.RevillConfig;
import com.eric.revill.event.RedEventManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public final class RevillCommand {
   private RevillCommand() {
   }

   public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(
         (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal(
                                    "revill"
                                 )
                                 .requires(source -> source.hasPermission(2)))
                              .then(Commands.literal("start").executes(context -> {
                                 RedEventManager.INSTANCE.startRedEvent(((CommandSourceStack)context.getSource()).getServer());
                                 return 1;
                              })))
                           .then(Commands.literal("stop").executes(context -> {
                              RedEventManager.INSTANCE.stopRedEvent(((CommandSourceStack)context.getSource()).getServer(), true);
                              ((CommandSourceStack)context.getSource()).sendSuccess(() -> Component.literal("El Evento Rojo ha sido cancelado."), false);
                              return 1;
                           })))
                        .then(Commands.literal("status").executes(context -> {
                           RedEventManager.INSTANCE.displayStatus((CommandSourceStack)context.getSource());
                           return 1;
                        })))
                     .then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("fusion").executes(context -> {
                        Dedsafio4Command.setFusion((CommandSourceStack)context.getSource(), !RevillMod.FUSION_ACTIVE);
                        return 1;
                     })).then(Commands.literal("entrar").executes(context -> {
                        Dedsafio4Command.setFusion((CommandSourceStack)context.getSource(), true);
                        return 1;
                     }))).then(Commands.literal("salir").executes(context -> {
                        Dedsafio4Command.setFusion((CommandSourceStack)context.getSource(), false);
                        return 1;
                     }))))
                  .then(
                     ((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("bunker")
                              .then(
                                 Commands.literal("set")
                                    .then(
                                       Commands.argument("x1", IntegerArgumentType.integer())
                                          .then(
                                             Commands.argument("y1", IntegerArgumentType.integer())
                                                .then(
                                                   Commands.argument("z1", IntegerArgumentType.integer())
                                                      .then(
                                                         Commands.argument("x2", IntegerArgumentType.integer())
                                                            .then(
                                                               Commands.argument("y2", IntegerArgumentType.integer())
                                                                  .then(Commands.argument("z2", IntegerArgumentType.integer()).executes(context -> {
                                                                     int x1 = IntegerArgumentType.getInteger(context, "x1");
                                                                     int y1 = IntegerArgumentType.getInteger(context, "y1");
                                                                     int z1 = IntegerArgumentType.getInteger(context, "z1");
                                                                     int x2 = IntegerArgumentType.getInteger(context, "x2");
                                                                     int y2 = IntegerArgumentType.getInteger(context, "y2");
                                                                     int z2 = IntegerArgumentType.getInteger(context, "z2");
                                                                     BlockPos pos1 = new BlockPos(x1, y1, z1);
                                                                     BlockPos pos2 = new BlockPos(x2, y2, z2);
                                                                     BunkerManager.setBunker(((CommandSourceStack)context.getSource()).getServer(), pos1, pos2);
                                                                     ((CommandSourceStack)context.getSource())
                                                                        .sendSuccess(() -> Component.literal("Búnker actualizado."), false);
                                                                     return 1;
                                                                  }))
                                                            )
                                                      )
                                                )
                                          )
                                    )
                              ))
                           .then(Commands.literal("show").executes(context -> {
                              if (BunkerManager.isConfigured()) {
                                 ((CommandSourceStack)context.getSource()).sendSuccess(() -> Component.literal("Búnker configurado."), false);
                              } else {
                                 ((CommandSourceStack)context.getSource()).sendSuccess(() -> Component.literal("Búnker no configurado."), false);
                              }

                              return 1;
                           })))
                        .then(Commands.literal("clear").executes(context -> {
                           BunkerManager.clear();
                           ((CommandSourceStack)context.getSource()).sendSuccess(() -> Component.literal("Búnker limpiado."), false);
                           return 1;
                        }))
                  ))
               .then(((LiteralArgumentBuilder)Commands.literal("meteorites").then(Commands.literal("on").executes(context -> {
                  RedEventManager.INSTANCE.getConfig().meteoritesEnabled = true;
                  ((CommandSourceStack)context.getSource()).sendSuccess(() -> Component.literal("Meteoritos activados."), false);
                  return 1;
               }))).then(Commands.literal("off").executes(context -> {
                  RedEventManager.INSTANCE.getConfig().meteoritesEnabled = false;
                  ((CommandSourceStack)context.getSource()).sendSuccess(() -> Component.literal("Meteoritos desactivados."), false);
                  return 1;
               }))))
            .then(
               Commands.literal("config")
                  .executes(
                     context -> {
                        RevillConfig config = RedEventManager.INSTANCE.getConfig();
                        ((CommandSourceStack)context.getSource())
                           .sendSuccess(
                              () -> Component.literal(
                                    "Configuración: duration="
                                       + config.durationSeconds
                                       + ", meteoritesMaxActive="
                                       + config.meteoritesMaxActive
                                       + ", destroyBlocks="
                                       + config.meteoritesDestroyBlocks
                                 ),
                              false
                           );
                        return 1;
                     }
                  )
            )
      );
   }
}
