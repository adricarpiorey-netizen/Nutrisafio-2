package com.eric.revill.meteor;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Display.BlockDisplay;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public class Meteor {
   private final Vec3 start;
   private final Vec3 target;
   private Vec3 position;
   private Vec3 velocity;
   private final double speed;
   private final BlockDisplay display;
   private boolean active = true;
   private boolean exploded;

   public Meteor(Vec3 start, Vec3 target, double speed, BlockDisplay display) {
      this.start = start;
      this.target = target;
      this.position = start;
      this.speed = speed;
      this.display = display;
      Vec3 direction = target.subtract(start).normalize();
      this.velocity = direction.scale(speed);
      this.updateDisplayPosition();
   }

   public void tick(ServerLevel world) {
      if (this.active) {
         this.position = this.position.add(this.velocity);
         this.updateDisplayPosition();
         if (this.position.distanceTo(this.target) <= 2.5 || this.collidesWithTerrain(world)) {
            this.active = false;
            this.exploded = true;
         }
      }
   }

   public void removeDisplay() {
      if (!this.display.isRemoved()) {
         this.display.discard();
      }
   }

   private void updateDisplayPosition() {
      this.display.setPos(this.position.x, this.position.y, this.position.z);
   }

   private boolean collidesWithTerrain(ServerLevel world) {
      int radius = 2;
      int minX = (int)Math.floor(this.position.x - (double)radius);
      int maxX = (int)Math.floor(this.position.x + (double)radius);
      int minY = (int)Math.floor(this.position.y - (double)radius);
      int maxY = (int)Math.floor(this.position.y + (double)radius);
      int minZ = (int)Math.floor(this.position.z - (double)radius);
      int maxZ = (int)Math.floor(this.position.z + (double)radius);

      for (int x = minX; x <= maxX; x++) {
         for (int y = minY; y <= maxY; y++) {
            for (int z = minZ; z <= maxZ; z++) {
               BlockPos blockPos = new BlockPos(x, y, z);
               BlockState state = world.getBlockState(blockPos);
               if (!state.getCollisionShape(world, blockPos).isEmpty()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   public Vec3 getPosition() {
      return this.position;
   }

   public Vec3 getTarget() {
      return this.target;
   }

   public double getSpeed() {
      return this.speed;
   }

   public boolean isActive() {
      return this.active;
   }

   public boolean hasExploded() {
      return this.exploded;
   }

   public void setExploded(boolean exploded) {
      this.exploded = exploded;
   }
}
