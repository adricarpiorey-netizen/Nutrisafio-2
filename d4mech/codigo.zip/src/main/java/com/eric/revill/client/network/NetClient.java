package com.eric.revill.client.network;

import com.eric.revill.network.Net;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public final class NetClient {
   public interface ClientHandler {
      void handle(Minecraft client, RegistryFriendlyByteBuf buf);
   }

   private NetClient() {
   }

   public static void on(ResourceLocation id, ClientHandler handler) {
      ClientPlayNetworking.registerGlobalReceiver(Net.type(id), (payload, context) -> {
         Minecraft client = context.client();
         handler.handle(client, Net.wrap(payload.bytes(), client.level != null ? client.level.registryAccess() : context.player().registryAccess()));
      });
   }

   public static void send(ResourceLocation id, FriendlyByteBuf buf) {
      if (ClientPlayNetworking.canSend(Net.type(id))) {
         ClientPlayNetworking.send(new Net.Data(Net.type(id), Net.bytesOf(buf)));
      }
   }
}
