package com.eric.revill.mail;

import com.eric.revill.network.Net;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public final class MailNetworking {
   public static final ResourceLocation OPEN_COMPOSE = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mail_compose_open");
   public static final ResourceLocation RETURN_INBOX = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mail_return_inbox");
   public static final ResourceLocation SEND_MAIL = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mail_send");
   public static final ResourceLocation MARK_READ = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mail_mark_read");
   public static final ResourceLocation CLAIM_ITEMS = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mail_claim_items");
   public static final ResourceLocation INBOX_SYNC = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mail_inbox_sync");

   public static final net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, List<MailInboxScreenHandler.MailView>> INBOX_CODEC = net.minecraft.network.codec.StreamCodec.of(
      (buf, views) -> {
         int count = Math.min(views.size(), 100);
         buf.writeVarInt(count);
         for (int index = 0; index < count; index++) {
            MailInboxScreenHandler.MailView v = views.get(index);
            buf.writeUtf(v.sender(), 64);
            buf.writeUtf(v.message(), 512);
            buf.writeBoolean(v.read());
            int itemCount = Math.min(v.items().size(), 9);
            buf.writeVarInt(itemCount);
            for (int i = 0; i < itemCount; i++) {
               ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, v.items().get(i));
            }
         }
      },
      MailNetworking::readInbox
   );

   private MailNetworking() {
   }

   public static List<MailInboxScreenHandler.MailView> toViews(List<Mail> mails) {
      List<MailInboxScreenHandler.MailView> out = new ArrayList<>();
      for (Mail mail : mails) {
         out.add(new MailInboxScreenHandler.MailView(mail.getSenderName(), mail.getMessage(), mail.isRead(), new ArrayList<>(mail.getItems())));
      }
      return out;
   }

   public static void registerServer() {
      Net.onServer(OPEN_COMPOSE, (server, player, buf) -> server.execute(() -> player.openMenu(MailComposeScreenHandler.factory()))
      );
      Net.onServer(RETURN_INBOX, (server, player, buf) -> server.execute(() -> {
            if (player.containerMenu instanceof MailComposeScreenHandler) {
               player.openMenu(MailInboxScreenHandler.inboxFactory());
            }
         }));
      Net.onServer(SEND_MAIL, (server, player, buf) -> {
         String recipientName = buf.readUtf(64);
         String message = buf.readUtf(512);
         server.execute(() -> sendMail(player, recipientName, message));
      });
      Net.onServer(MARK_READ, (server, player, buf) -> {
         int syncId = buf.readVarInt();
         int index = buf.readVarInt();
         server.execute(() -> updateMail(player, syncId, index, false));
      });
      Net.onServer(CLAIM_ITEMS, (server, player, buf) -> {
         int syncId = buf.readVarInt();
         int index = buf.readVarInt();
         server.execute(() -> updateMail(player, syncId, index, true));
      });
   }

   public static void writeInbox(net.minecraft.network.RegistryFriendlyByteBuf buf, List<Mail> mails) {
      int count = Math.min(mails.size(), 100);
      buf.writeVarInt(count);

      for (int index = 0; index < count; index++) {
         Mail mail = mails.get(index);
         buf.writeUtf(mail.getSenderName(), 64);
         buf.writeUtf(mail.getMessage(), 512);
         buf.writeBoolean(mail.isRead());
         int itemCount = Math.min(mail.getItems().size(), 9);
         buf.writeVarInt(itemCount);

         for (int itemIndex = 0; itemIndex < itemCount; itemIndex++) {
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, mail.getItems().get(itemIndex));
         }
      }
   }

   public static List<MailInboxScreenHandler.MailView> readInbox(net.minecraft.network.RegistryFriendlyByteBuf buf) {
      int count = Math.min(buf.readVarInt(), 100);
      List<MailInboxScreenHandler.MailView> mails = new ArrayList<>(count);

      for (int index = 0; index < count; index++) {
         String sender = buf.readUtf(64);
         String message = buf.readUtf(512);
         boolean read = buf.readBoolean();
         int itemCount = Math.min(buf.readVarInt(), 9);
         List<ItemStack> items = new ArrayList<>(itemCount);

         for (int itemIndex = 0; itemIndex < itemCount; itemIndex++) {
            items.add(ItemStack.OPTIONAL_STREAM_CODEC.decode(buf));
         }

         mails.add(new MailInboxScreenHandler.MailView(sender, message, read, items));
      }

      return mails;
   }

   public static void syncInbox(ServerPlayer player, MailInboxScreenHandler handler) {
      net.minecraft.network.RegistryFriendlyByteBuf buf = Net.create(player.registryAccess());
      buf.writeVarInt(handler.containerId);
      writeInbox(buf, MailManager.INSTANCE.snapshot(player.getUUID()));
      Net.send(player, INBOX_SYNC, buf);
   }

   private static void sendMail(ServerPlayer sender, String recipientName, String message) {
      if (sender.containerMenu instanceof MailComposeScreenHandler composeHandler) {
         ServerPlayer recipient = sender.getServer().getPlayerList().getPlayerByName(recipientName.trim());
         if (recipient != null && !message.isBlank()) {
            List<ItemStack> attachments = new ArrayList<>();

            for (int slot = 0; slot < composeHandler.getAttachments().getContainerSize(); slot++) {
               ItemStack stack = composeHandler.getAttachments().getItem(slot);
               if (!stack.isEmpty()) {
                  attachments.add(stack.copy());
               }
            }

            MailManager.INSTANCE.send(recipient.getUUID(), sender.getUUID(), sender.getName().getString(), "Correo", message, attachments);
            composeHandler.clearAttachments();
            MailManager.INSTANCE.notifyRecipient(recipient, sender.getName().getString());
            sender.displayClientMessage(Component.literal("Correo enviado."), true);
            sender.closeContainer();
         } else {
            sender.displayClientMessage(Component.literal(recipient == null ? "Destinatario no conectado." : "El mensaje no puede estar vacío."), true);
         }
      }
   }

   private static void updateMail(ServerPlayer player, int syncId, int index, boolean claim) {
      if (player.containerMenu instanceof MailInboxScreenHandler inbox && inbox.containerId == syncId) {
         if (claim) {
            MailManager.INSTANCE.claimItems(player.getUUID(), index, player);
         } else {
            MailManager.INSTANCE.markRead(player.getUUID(), index);
         }

         syncInbox(player, inbox);
         return;
      }
   }
}
