package com.eric.revill.client.ui;

import com.eric.revill.client.network.NetClient;
import com.eric.revill.client.render.ClientWaypointManager;
import com.eric.revill.dedsafio4.Dedsafio4Manager;
import com.eric.revill.dedsafio4.Dedsafio4Networking;
import com.eric.revill.event.RevillTask;
import com.eric.revill.waypoint.Waypoint;
import com.eric.revill.waypoint.WaypointManager;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

@Environment(EnvType.CLIENT)
public class Dedsafio4Screen extends Screen {
   private static final String[] PAGES = new String[]{"INICIO", "CAMBIOS", "WAYPOINTS"};
   private static final String[] COLORS = new String[]{"roja", "verde", "naranja", "rosada"};
   private static final String[] ICONS = new String[]{"star", "bunker", "home", "flag", "warning"};
   private static final RevillTask[] REVILL_TASKS = RevillTask.values();
   private final List<Dedsafio4Manager.Dedsafio4Change> currentChanges = new ArrayList<>();
   private int currentPageIndex = 0;
   private int selectedDayIndex = 0;
   private int colorIndex = 0;
   private int revillTaskIndex;
   private int iconIndex = 0;
   private double scrollAmount = 0.0;
   private int maxScroll = 0;
   private EditBox messageField;
   private Button colorButton;
   private Button revillTaskButton;
   private EditBox wpNameField;
   private EditBox wpXField;
   private EditBox wpYField;
   private EditBox wpZField;
   private Button wpIconBtn;
   private String editingWaypointId = null;
   private EditBox editNameField;
   private EditBox editXField;
   private EditBox editYField;
   private EditBox editZField;
   private final List<Dedsafio4Screen.ActionButton> actionButtons = new ArrayList<>();

   public Dedsafio4Screen() {
      super(Component.literal("DEDSAFIO 4"));
   }

   private Font getSafeTextRenderer() {
      if (this.font != null) {
         return this.font;
      } else {
         Minecraft client = Minecraft.getInstance();
         return client != null ? client.font : null;
      }
   }

   protected void init() {
      super.init();
      this.clearWidgets();
      this.actionButtons.clear();
      Font tr = this.getSafeTextRenderer();
      if (tr != null) {
         int centerX = this.width / 2;
         int navGap = 6;
         int navWidth = Math.min(126, (this.width - 24 - navGap * (PAGES.length - 1)) / PAGES.length);
         int navStartX = centerX - (navWidth * PAGES.length + navGap * (PAGES.length - 1)) / 2;

         for (int i = 0; i < PAGES.length; i++) {
            int pageIndex = i;
            String label = (i == this.currentPageIndex ? "[ " : "") + PAGES[i] + (i == this.currentPageIndex ? " ]" : "");
            this.addRenderableWidget(Button.builder(Component.literal(label), button -> {
               this.currentPageIndex = pageIndex;
               this.scrollAmount = 0.0;
               this.editingWaypointId = null;
               this.refreshData();
               this.init();
            }).bounds(navStartX + i * (navWidth + navGap), 12, navWidth, 20).build());
         }

         if (this.isWaypointsTab()) {
            this.initWaypointsView(tr, centerX);
         } else if (this.isChangesTab()) {
            this.initDayTabs(centerX);
         } else {
            this.initControlPanelView(tr, centerX);
         }

         this.refreshData();
      }
   }

   private boolean isWaypointsTab() {
      return this.currentPageIndex == 2;
   }

   private boolean isChangesTab() {
      return this.currentPageIndex == 1;
   }

   private void initDayTabs(int centerX) {
      int gap = 4;
      int buttonWidth = Math.min(74, (this.width - 28 - gap * 5) / 6);
      int startX = centerX - (buttonWidth * 6 + gap * 5) / 2;

      for (int day = 0; day < 6; day++) {
         int dayIndex = day;
         String label = (day == this.selectedDayIndex ? "[" : "") + "DÍA " + (day + 1) + (day == this.selectedDayIndex ? "]" : "");
         this.addRenderableWidget(Button.builder(Component.literal(label), button -> {
            this.selectedDayIndex = dayIndex;
            this.scrollAmount = 0.0;
            this.refreshData();
            this.init();
         }).bounds(startX + day * (buttonWidth + gap), 41, buttonWidth, 20).build());
      }
   }

   private void initControlPanelView(Font tr, int centerX) {
      int formWidth = Math.min(380, this.width - 32);
      int formLeft = centerX - formWidth / 2;
      this.messageField = new EditBox(tr, formLeft, 70, formWidth, 20, Component.literal("Mensaje"));
      this.messageField.setMaxLength(240);
      this.messageField.setHint(Component.literal("Mensaje adicional (opcional)"));
      this.addRenderableWidget(this.messageField);
      this.revillTaskButton = Button.builder(Component.literal("Tarea REVILL: " + REVILL_TASKS[this.revillTaskIndex].label()), button -> {
         this.revillTaskIndex = (this.revillTaskIndex + 1) % REVILL_TASKS.length;
         this.revillTaskButton.setMessage(Component.literal("Tarea REVILL: " + REVILL_TASKS[this.revillTaskIndex].label()));
      }).bounds(formLeft, 96, formWidth, 20).build();
      this.addRenderableWidget(this.revillTaskButton);
      int groupWidth = Math.min(260, this.width - 24);
      int groupLeft = centerX - groupWidth / 2;
      this.colorButton = Button.builder(Component.literal("Color: " + COLORS[this.colorIndex].toUpperCase()), button -> {
         this.colorIndex = (this.colorIndex + 1) % COLORS.length;
         this.colorButton.setMessage(Component.literal("Color: " + COLORS[this.colorIndex].toUpperCase()));
      }).bounds(groupLeft, 128, 112, 20).build();
      this.addRenderableWidget(this.colorButton);
      this.addRenderableWidget(
         Button.builder(Component.literal("LANZAR RULETA"), button -> this.sendCustomRoulette()).bounds(groupLeft + 118, 128, groupWidth - 118, 20).build()
      );
      int eventButtonWidth = (groupWidth - 6) / 2;
      this.addRenderableWidget(
         Button.builder(Component.literal("INICIAR REVILL"), button -> this.sendStartRevill()).bounds(groupLeft, 158, eventButtonWidth, 20).build()
      );
      this.addRenderableWidget(
         Button.builder(Component.literal("PARAR REVILL"), button -> this.sendStopRevill())
            .bounds(groupLeft + eventButtonWidth + 6, 158, eventButtonWidth, 20)
            .build()
      );
   }

   private void initWaypointsView(Font tr, int centerX) {
      Minecraft client = Minecraft.getInstance();
      BlockPos playerPos = client != null && client.player != null ? client.player.blockPosition() : BlockPos.ZERO;
      int rowY = 54;
      this.wpNameField = new EditBox(tr, centerX - 240, rowY, 120, 18, Component.literal("Nombre"));
      this.wpNameField.setMaxLength(32);
      this.wpNameField.setValue("Punto " + (ClientWaypointManager.getWaypoints().size() + 1));
      this.addRenderableWidget(this.wpNameField);
      this.wpIconBtn = Button.builder(Component.literal("Icono: " + ICONS[this.iconIndex].toUpperCase()), button -> {
         this.iconIndex = (this.iconIndex + 1) % ICONS.length;
         this.wpIconBtn.setMessage(Component.literal("Icono: " + ICONS[this.iconIndex].toUpperCase()));
      }).bounds(centerX - 115, rowY, 75, 18).build();
      this.addRenderableWidget(this.wpIconBtn);
      this.wpXField = new EditBox(tr, centerX - 35, rowY, 40, 18, Component.literal("X"));
      this.wpXField.setValue(String.valueOf(playerPos.getX()));
      this.addRenderableWidget(this.wpXField);
      this.wpYField = new EditBox(tr, centerX + 10, rowY, 35, 18, Component.literal("Y"));
      this.wpYField.setValue(String.valueOf(playerPos.getY()));
      this.addRenderableWidget(this.wpYField);
      this.wpZField = new EditBox(tr, centerX + 50, rowY, 40, 18, Component.literal("Z"));
      this.wpZField.setValue(String.valueOf(playerPos.getZ()));
      this.addRenderableWidget(this.wpZField);
      this.addRenderableWidget(Button.builder(Component.literal("+ AQUÍ"), button -> this.sendCreateWaypointHere()).bounds(centerX + 95, rowY, 55, 18).build());
      this.addRenderableWidget(
         Button.builder(Component.literal("+ CON COORDENADAS"), button -> this.sendCreateWaypointCustom()).bounds(centerX + 155, rowY, 95, 18).build()
      );
   }

   private void refreshData() {
      this.currentChanges.clear();
      if (this.isChangesTab()) {
         this.currentChanges.addAll(Dedsafio4Manager.getChangesForDay(this.selectedDayIndex + 1));
      }

      this.recalculateScroll();
   }

   private void recalculateScroll() {
      int listTop = this.isWaypointsTab() ? 82 : (this.isChangesTab() ? 84 : this.height);
      int listBottom = this.height - 15;
      int contentHeight = 0;
      int cardWidth = Math.min(540, this.width - 60);
      if (this.isWaypointsTab()) {
         for (Waypoint wp : ClientWaypointManager.getWaypoints()) {
            int h = wp.getId().equals(this.editingWaypointId) ? 75 : 44;
            contentHeight += h + 8;
         }
      } else if (this.isChangesTab()) {
         for (Dedsafio4Manager.Dedsafio4Change change : this.currentChanges) {
            contentHeight += this.getChangeCardHeight(change, cardWidth) + 8;
         }
      }

      int visibleHeight = Math.max(50, listBottom - listTop);
      this.maxScroll = Math.max(0, contentHeight - visibleHeight);
      this.scrollAmount = Mth.clamp(this.scrollAmount, 0.0, (double)this.maxScroll);
   }

   private int getChangeCardHeight(Dedsafio4Manager.Dedsafio4Change change, int cardWidth) {
      List<String> wrapped = this.wrapText(change.description(), cardWidth - 110);
      int textHeight = Math.max(1, wrapped.size()) * 10;
      return Math.max(45, 24 + textHeight);
   }

   private List<String> wrapText(String text, int maxWidth) {
      List<String> lines = new ArrayList<>();
      if (text != null && !text.isBlank()) {
         Font tr = this.getSafeTextRenderer();
         if (tr == null) {
            lines.add(text);
            return lines;
         } else {
            String[] words = text.split("\\s+");
            StringBuilder current = new StringBuilder();

            for (String word : words) {
               String candidate = current.length() == 0 ? word : current + " " + word;
               if (tr.width(candidate) > maxWidth && current.length() > 0) {
                  lines.add(current.toString());
                  current = new StringBuilder(word);
               } else {
                  current = new StringBuilder(candidate);
               }
            }

            if (current.length() > 0) {
               lines.add(current.toString());
            }

            return lines;
         }
      } else {
         return lines;
      }
   }

   public void render(GuiGraphics context, int mouseX, int mouseY, float delta) {
      context.fill(0, 0, this.width, this.height, -1207959552);
      super.render(context, mouseX, mouseY, delta);
      Font tr = this.getSafeTextRenderer();
      if (tr != null) {
         int centerX = this.width / 2;
         if (this.isWaypointsTab()) {
            this.renderWaypointsView(context, tr, centerX, mouseX, mouseY);
         } else if (this.isChangesTab()) {
            this.renderControlPanelView(context, tr, centerX, mouseX, mouseY);
         } else {
            this.renderHomeView(context, tr, centerX);
         }
      }
   }

   private void renderHomeView(GuiGraphics context, Font tr, int centerX) {
      context.drawCenteredString(tr, Component.literal("CENTRO DE CONTROL"), centerX, 44, -1);
      context.fill(centerX - 132, 61, centerX + 132, 62, -6474700);
   }

   private void renderControlPanelView(GuiGraphics context, Font tr, int centerX, int mouseX, int mouseY) {
      context.drawCenteredString(tr, Component.literal("CAMBIOS DE DIFICULTAD · DÍA " + (this.selectedDayIndex + 1)), centerX, 66, -1);
      int listTop = 84;
      int listBottom = this.height - 15;
      int cardWidth = Math.min(540, this.width - 60);
      int cardLeft = centerX - cardWidth / 2;
      this.actionButtons.clear();
      int currentY = listTop - (int)this.scrollAmount;
      context.enableScissor(cardLeft - 10, listTop, cardLeft + cardWidth + 10, listBottom);

      for (Dedsafio4Manager.Dedsafio4Change change : this.currentChanges) {
         int cardHeight = this.getChangeCardHeight(change, cardWidth);
         if (currentY + cardHeight >= listTop && currentY <= listBottom) {
            boolean active = Dedsafio4Manager.isEnabled(change.id());
            int bgColor = active ? 1712995104 : 1428301098;
            int borderColor = active ? -12331410 : -11184811;
            context.fill(cardLeft, currentY, cardLeft + cardWidth, currentY + cardHeight, bgColor);
            context.renderOutline(cardLeft, currentY, cardWidth, cardHeight, borderColor);
            String statusText = active ? "[ACTIVO]" : "[INACTIVO]";
            String title = change.title() + " " + statusText;
            context.drawString(tr, title, cardLeft + 10, currentY + 6, 16777215, true);
            String explanation = change.description() != null && !change.description().isBlank() ? change.description() : change.rouletteText();
            List<String> wrapped = this.wrapText(explanation, cardWidth - 110);
            int lineY = currentY + 18;

            for (String line : wrapped) {
               if (lineY + 9 <= currentY + cardHeight) {
                  context.drawString(tr, "§f" + line, cardLeft + 10, lineY, 16777215, false);
                  lineY += 10;
               }
            }

            int btnWidth = 95;
            int btnHeight = 18;
            int btnX = cardLeft + cardWidth - btnWidth - 8;
            int btnY = currentY + cardHeight / 2 - btnHeight / 2;
            boolean hovered = mouseX >= btnX && mouseX <= btnX + btnWidth && mouseY >= btnY && mouseY <= btnY + btnHeight;
            int btnBg = hovered ? -6750208 : -10092544;
            context.fill(btnX, btnY, btnX + btnWidth, btnY + btnHeight, btnBg);
            context.renderOutline(btnX, btnY, btnWidth, btnHeight, -3394765);
            context.drawCenteredString(tr, Component.literal("RULETA"), btnX + btnWidth / 2, btnY + 5, 16777215);
            String changeId = change.id();
            this.actionButtons.add(new Dedsafio4Screen.ActionButton(btnX, btnY, btnWidth, btnHeight, () -> this.sendApplyChange(changeId)));
         }

         currentY += cardHeight + 8;
      }

      context.disableScissor();
      this.renderScrollbar(context, cardLeft + cardWidth + 4, listTop, listBottom);
   }

   private void renderWaypointsView(GuiGraphics context, Font tr, int centerX, int mouseX, int mouseY) {
      context.drawCenteredString(tr, Component.literal("GESTIÓN DE WAYPOINTS"), centerX, 36, -1);
      int listTop = 82;
      int listBottom = this.height - 15;
      int cardWidth = Math.min(540, this.width - 60);
      int cardLeft = centerX - cardWidth / 2;
      this.actionButtons.clear();
      int currentY = listTop - (int)this.scrollAmount;
      List<Waypoint> waypoints = ClientWaypointManager.getWaypoints();
      context.enableScissor(cardLeft - 10, listTop, cardLeft + cardWidth + 10, listBottom);
      if (waypoints.isEmpty()) {
         context.drawCenteredString(tr, Component.literal("No hay waypoints creados. Crea uno usando el panel de arriba."), centerX, listTop + 20, 16777215);
      }

      for (Waypoint wp : waypoints) {
         boolean isEditing = wp.getId().equals(this.editingWaypointId);
         int cardHeight = isEditing ? 75 : 44;
         if (currentY + cardHeight >= listTop && currentY <= listBottom) {
            context.fill(cardLeft, currentY, cardLeft + cardWidth, currentY + cardHeight, 1712726574);
            context.renderOutline(cardLeft, currentY, cardWidth, cardHeight, -16711732);
            String iconSymbol = this.formatIconSymbol(wp.getIcon());
            String title = "§f" + iconSymbol + " §f§l" + wp.getName() + " §f(" + wp.getDimension() + ")";
            context.drawString(tr, title, cardLeft + 10, currentY + 6, 16777215, true);
            BlockPos pos = wp.getPos();
            String posText = String.format("§fPosición: X: %d  Y: %d  Z: %d", pos.getX(), pos.getY(), pos.getZ());
            context.drawString(tr, posText, cardLeft + 10, currentY + 20, 16777215, false);
            int btnWidth = 60;
            int btnHeight = 18;
            int editBtnX = cardLeft + cardWidth - 135;
            int deleteBtnX = cardLeft + cardWidth - 68;
            int btnY = currentY + 10;
            boolean editHovered = mouseX >= editBtnX && mouseX <= editBtnX + btnWidth && mouseY >= btnY && mouseY <= btnY + btnHeight;
            context.fill(editBtnX, btnY, editBtnX + btnWidth, btnY + btnHeight, editHovered ? -16750968 : -16759706);
            context.renderOutline(editBtnX, btnY, btnWidth, btnHeight, -16724737);
            context.drawCenteredString(tr, Component.literal(isEditing ? "CANCELAR" : "EDITAR"), editBtnX + btnWidth / 2, btnY + 5, 16777215);
            String wpId = wp.getId();
            this.actionButtons.add(new Dedsafio4Screen.ActionButton(editBtnX, btnY, btnWidth, btnHeight, () -> {
               if (isEditing) {
                  this.editingWaypointId = null;
                  this.init();
               } else {
                  this.startEditingWaypoint(wp);
               }
            }));
            boolean deleteHovered = mouseX >= deleteBtnX && mouseX <= deleteBtnX + btnWidth && mouseY >= btnY && mouseY <= btnY + btnHeight;
            context.fill(deleteBtnX, btnY, deleteBtnX + btnWidth, btnY + btnHeight, deleteHovered ? -6750208 : -10092544);
            context.renderOutline(deleteBtnX, btnY, btnWidth, btnHeight, -52429);
            context.drawCenteredString(tr, Component.literal("BORRAR"), deleteBtnX + btnWidth / 2, btnY + 5, 16777215);
            this.actionButtons
               .add(new Dedsafio4Screen.ActionButton(deleteBtnX, btnY, deleteBtnX + btnWidth, btnY + btnHeight, () -> this.sendRemoveWaypoint(wpId)));
            if (isEditing) {
               context.drawString(tr, "Editar Nombre y Coordenadas:", cardLeft + 10, currentY + 36, 16777215, false);
               int saveBtnX = cardLeft + cardWidth - 85;
               int saveBtnY = currentY + 48;
               boolean saveHovered = mouseX >= saveBtnX && mouseX <= saveBtnX + 75 && mouseY >= saveBtnY && mouseY <= saveBtnY + 18;
               context.fill(saveBtnX, saveBtnY, saveBtnX + 75, saveBtnY + 18, saveHovered ? -16733628 : -16746701);
               context.renderOutline(saveBtnX, saveBtnY, 75, 18, -11141291);
               context.drawCenteredString(tr, Component.literal("GUARDAR"), saveBtnX + 37, saveBtnY + 5, 16777215);
               this.actionButtons.add(new Dedsafio4Screen.ActionButton(saveBtnX, saveBtnY, 75, 18, () -> this.saveEditingWaypoint(wp)));
            }
         }

         currentY += cardHeight + 8;
      }

      context.disableScissor();
      this.renderScrollbar(context, cardLeft + cardWidth + 4, listTop, listBottom);
   }

   private void startEditingWaypoint(Waypoint wp) {
      this.editingWaypointId = wp.getId();
      Font tr = this.getSafeTextRenderer();
      if (tr != null) {
         int cardWidth = Math.min(540, this.width - 60);
         int centerX = this.width / 2;
         int cardLeft = centerX - cardWidth / 2;
         int listTop = 82;
         int currentY = listTop - (int)this.scrollAmount;

         for (Waypoint item : ClientWaypointManager.getWaypoints()) {
            if (item.getId().equals(wp.getId())) {
               int fieldsY = currentY + 48;
               this.editNameField = new EditBox(tr, cardLeft + 10, fieldsY, 110, 18, Component.literal("Nombre"));
               this.editNameField.setValue(wp.getName());
               this.addRenderableWidget(this.editNameField);
               BlockPos pos = wp.getPos();
               this.editXField = new EditBox(tr, cardLeft + 125, fieldsY, 40, 18, Component.literal("X"));
               this.editXField.setValue(String.valueOf(pos.getX()));
               this.addRenderableWidget(this.editXField);
               this.editYField = new EditBox(tr, cardLeft + 170, fieldsY, 35, 18, Component.literal("Y"));
               this.editYField.setValue(String.valueOf(pos.getY()));
               this.addRenderableWidget(this.editYField);
               this.editZField = new EditBox(tr, cardLeft + 210, fieldsY, 40, 18, Component.literal("Z"));
               this.editZField.setValue(String.valueOf(pos.getZ()));
               this.addRenderableWidget(this.editZField);
               break;
            }

            currentY += (item.getId().equals(this.editingWaypointId) ? 75 : 44) + 8;
         }

         this.recalculateScroll();
      }
   }

   private void saveEditingWaypoint(Waypoint oldWp) {
      if (this.editNameField != null) {
         String name = this.editNameField.getValue().isBlank() ? oldWp.getName() : this.editNameField.getValue();
         int x = this.parseIntOrDefault(this.editXField != null ? this.editXField.getValue() : "", oldWp.getPos().getX());
         int y = this.parseIntOrDefault(this.editYField != null ? this.editYField.getValue() : "", oldWp.getPos().getY());
         int z = this.parseIntOrDefault(this.editZField != null ? this.editZField.getValue() : "", oldWp.getPos().getZ());
         this.sendEditWaypoint(oldWp.getId(), name, oldWp.getIcon(), new BlockPos(x, y, z), oldWp.getColor(), oldWp.getDimension());
         this.editingWaypointId = null;
         this.init();
      }
   }

   private String formatIconSymbol(String icon) {
      return switch (icon) {
         case "bunker" -> "[\ud83d\udee1]";
         case "home" -> "[\ud83c\udfe0]";
         case "flag" -> "[\ud83d\udea9]";
         case "warning" -> "[⚠]";
         default -> "[★]";
      };
   }

   private int parseIntOrDefault(String text, int defaultValue) {
      try {
         return Integer.parseInt(text.trim());
      } catch (Exception var4) {
         return defaultValue;
      }
   }

   private void renderScrollbar(GuiGraphics context, int scrollBarX, int listTop, int listBottom) {
      if (this.maxScroll > 0) {
         int barHeight = listBottom - listTop;
         int thumbHeight = Math.max(15, barHeight * barHeight / (barHeight + this.maxScroll));
         int thumbY = listTop + (int)(this.scrollAmount * (double)(barHeight - thumbHeight) / (double)this.maxScroll);
         context.fill(scrollBarX, listTop, scrollBarX + 3, listBottom, 1157627903);
         context.fill(scrollBarX, thumbY, scrollBarX + 3, thumbY + thumbHeight, -12285697);
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0) {
         for (Dedsafio4Screen.ActionButton btn : this.actionButtons) {
            if (mouseX >= (double)btn.x()
               && mouseX <= (double)(btn.x() + btn.width())
               && mouseY >= (double)btn.y()
               && mouseY <= (double)(btn.y() + btn.height())) {
               btn.action().run();
               return true;
            }
         }
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double amount) {
      if (this.maxScroll > 0) {
         this.scrollAmount = Mth.clamp(this.scrollAmount - amount * 20.0, 0.0, (double)this.maxScroll);
         return true;
      } else {
         return super.mouseScrolled(mouseX, mouseY, horizontalAmount, amount);
      }
   }

   private void sendCustomRoulette() {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeUtf(COLORS[this.colorIndex]);
      buf.writeUtf(this.messageField != null ? this.messageField.getValue() : "");
      NetClient.send(Dedsafio4Networking.CUSTOM_ROULETTE, buf);
      this.onClose();
   }

   private void sendStartRevill() {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeUtf(REVILL_TASKS[this.revillTaskIndex].id());
      buf.writeUtf(this.messageField != null ? this.messageField.getValue() : "");
      NetClient.send(Dedsafio4Networking.START_REVILL, buf);
      this.onClose();
   }

   private void sendStopRevill() {
      NetClient.send(Dedsafio4Networking.STOP_REVILL, PacketByteBufs.empty());
      this.onClose();
   }

   private void sendApplyChange(String id) {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeUtf(id);
      NetClient.send(Dedsafio4Networking.APPLY_CHANGE, buf);
      this.onClose();
   }

   private void sendCreateWaypointHere() {
      FriendlyByteBuf buf = PacketByteBufs.create();
      String name = this.wpNameField != null && !this.wpNameField.getValue().isBlank() ? this.wpNameField.getValue() : "Punto de Interés";
      String icon = ICONS[this.iconIndex];
      buf.writeUtf(name);
      buf.writeUtf(icon);
      NetClient.send(WaypointManager.ADD_WAYPOINT, buf);
      this.init();
   }

   private void sendCreateWaypointCustom() {
      Minecraft client = Minecraft.getInstance();
      BlockPos playerPos = client != null && client.player != null ? client.player.blockPosition() : BlockPos.ZERO;
      String dim = client != null && client.player != null ? client.player.level().dimension().location().toString() : "minecraft:overworld";
      String name = this.wpNameField != null && !this.wpNameField.getValue().isBlank() ? this.wpNameField.getValue() : "Punto Personalizado";
      String icon = ICONS[this.iconIndex];
      int x = this.parseIntOrDefault(this.wpXField != null ? this.wpXField.getValue() : "", playerPos.getX());
      int y = this.parseIntOrDefault(this.wpYField != null ? this.wpYField.getValue() : "", playerPos.getY());
      int z = this.parseIntOrDefault(this.wpZField != null ? this.wpZField.getValue() : "", playerPos.getZ());
      String id = "wp_" + System.currentTimeMillis();
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeUtf(id);
      buf.writeUtf(name);
      buf.writeUtf(icon);
      buf.writeBlockPos(new BlockPos(x, y, z));
      buf.writeInt(-16711732);
      buf.writeUtf(dim);
      NetClient.send(WaypointManager.EDIT_WAYPOINT, buf);
      this.init();
   }

   private void sendEditWaypoint(String id, String name, String icon, BlockPos pos, int color, String dim) {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeUtf(id);
      buf.writeUtf(name);
      buf.writeUtf(icon);
      buf.writeBlockPos(pos);
      buf.writeInt(color);
      buf.writeUtf(dim);
      NetClient.send(WaypointManager.EDIT_WAYPOINT, buf);
   }

   private void sendRemoveWaypoint(String id) {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeUtf(id);
      NetClient.send(WaypointManager.REMOVE_WAYPOINT, buf);
      this.init();
   }

   @Environment(EnvType.CLIENT)
   private static record ActionButton(int x, int y, int width, int height, Runnable action) {
   }

   @Override
   public void renderBackground(GuiGraphics context, int mouseX, int mouseY, float delta) {
   }
}
