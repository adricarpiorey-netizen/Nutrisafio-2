package com.eric.revill.item;

import com.eric.revill.entity.ModEntities;
import com.eric.revill.mail.ModMailBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents.ModifyEntries;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item.Properties;

public final class ModItems {
   public static final ResourceLocation NUTRITOTEM_GROUP_ID = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "nutritotem_group");
   public static final ResourceKey<CreativeModeTab> NUTRITOTEM_GROUP_KEY = ResourceKey.create(Registries.CREATIVE_MODE_TAB, NUTRITOTEM_GROUP_ID);
   public static final Item DEDITA = (Item)Registry.register(
      BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "dedita"), new Item(new Properties().stacksTo(99))
   );
   public static final Item DEDITA_ROJA = (Item)Registry.register(
      BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "dedita_roja"), new Item(new Properties().stacksTo(99))
   );
   public static final Item DEDITA_ROSA = (Item)Registry.register(
      BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "dedita_rosa"), new Item(new Properties().stacksTo(99))
   );
   public static final Item DEDITA_VERDE = (Item)Registry.register(
      BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "dedita_verde"), new Item(new Properties().stacksTo(99))
   );
   public static final Item CAJERO_SPAWN_EGG = (Item)Registry.register(
      BuiltInRegistries.ITEM,
      ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "cajero_spawn_egg"),
      new CajeroSpawnEggItem(ModEntities.CAJERO, 2503224, 5416959, new Properties())
   );
   public static final Item PALITOMAGICO = (Item)Registry.register(
      BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "palitomagico"), new MagicStickItem(new Properties())
   );
   public static final CreativeModeTab NUTRITOTEM_GROUP = (CreativeModeTab)Registry.register(
      BuiltInRegistries.CREATIVE_MODE_TAB,
      NUTRITOTEM_GROUP_ID,
      FabricItemGroup.builder()
         .icon(() -> new ItemStack(Items.TOTEM_OF_UNDYING))
         .title(Component.translatable("itemGroup.dedsafio-4-mechanics.nutritotem_group"))
         .displayItems((displayContext, entries) -> {
            entries.accept(Items.TOTEM_OF_UNDYING);
            entries.accept(DEDITA);
            entries.accept(DEDITA_ROJA);
            entries.accept(DEDITA_ROSA);
            entries.accept(DEDITA_VERDE);
            entries.accept(CAJERO_SPAWN_EGG);
            entries.accept(PALITOMAGICO);
            entries.accept(ModMailBlocks.MAILBOX_ITEM);
         })
         .build()
   );

   private ModItems() {
   }

   public static void initialize() {
      ItemGroupEvents.modifyEntriesEvent(NUTRITOTEM_GROUP_KEY).register((ModifyEntries)entries -> {
         entries.accept(Items.TOTEM_OF_UNDYING);
         entries.accept(DEDITA);
         entries.accept(DEDITA_ROJA);
         entries.accept(DEDITA_ROSA);
         entries.accept(DEDITA_VERDE);
         entries.accept(CAJERO_SPAWN_EGG);
         entries.accept(PALITOMAGICO);
         entries.accept(ModMailBlocks.MAILBOX_ITEM);
      });
   }
}
