package com.eric.revill.bunker;

import net.minecraft.core.BlockPos;

public class Bunker {
   private String dimension = "";
   private BlockPos firstCorner;
   private BlockPos secondCorner;

   public boolean isConfigured() {
      return this.dimension != null && !this.dimension.isEmpty() && this.firstCorner != null && this.secondCorner != null;
   }

   public boolean contains(BlockPos pos) {
      if (this.isConfigured() && pos != null) {
         int minX = Math.min(this.firstCorner.getX(), this.secondCorner.getX());
         int maxX = Math.max(this.firstCorner.getX(), this.secondCorner.getX());
         int minY = Math.min(this.firstCorner.getY(), this.secondCorner.getY());
         int maxY = Math.max(this.firstCorner.getY(), this.secondCorner.getY());
         int minZ = Math.min(this.firstCorner.getZ(), this.secondCorner.getZ());
         int maxZ = Math.max(this.firstCorner.getZ(), this.secondCorner.getZ());
         return pos.getX() >= minX && pos.getX() <= maxX && pos.getY() >= minY && pos.getY() <= maxY && pos.getZ() >= minZ && pos.getZ() <= maxZ;
      } else {
         return false;
      }
   }

   public String getDimension() {
      return this.dimension;
   }

   public void setDimension(String dimension) {
      this.dimension = dimension;
   }

   public BlockPos getFirstCorner() {
      return this.firstCorner;
   }

   public void setFirstCorner(BlockPos firstCorner) {
      this.firstCorner = firstCorner;
   }

   public BlockPos getSecondCorner() {
      return this.secondCorner;
   }

   public void setSecondCorner(BlockPos secondCorner) {
      this.secondCorner = secondCorner;
   }
}
