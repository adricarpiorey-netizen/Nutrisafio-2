package com.eric.revill.mail;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public final class ModMailBlocks {
   public static final Block MAILBOX = (Block)Registry.register(
      BuiltInRegistries.BLOCK, ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mailbox"), new MailboxBlock(Properties.ofFullCopy(Blocks.OAK_PLANKS).noOcclusion())
   );
   public static final Item MAILBOX_ITEM = (Item)Registry.register(
      BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "mailbox"), new BlockItem(MAILBOX, new net.minecraft.world.item.Item.Properties())
   );

   private ModMailBlocks() {
   }

   public static void initialize() {
   }
}
