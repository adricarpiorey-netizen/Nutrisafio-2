package com.eric.revill.client.render;

import com.eric.revill.entity.CajeroEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public final class CajeroEntityRenderer extends EntityRenderer<CajeroEntity> {
   private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "textures/entity/cajeroent.png");
   private final CajeroEntityModel model;

   public CajeroEntityRenderer(Context context) {
      super(context);
      this.model = new CajeroEntityModel(context.bakeLayer(CajeroEntityModel.LAYER));
      this.shadowRadius = 0.0F;
   }

   public void render(CajeroEntity entity, float yaw, float tickDelta, PoseStack matrices, MultiBufferSource vertexConsumers, int light) {
      matrices.pushPose();
      matrices.mulPose(Axis.YP.rotationDegrees(180.0F - entity.getViewYRot(tickDelta)));
      matrices.translate(0.0F, 1.5F, 0.0F);
      matrices.scale(1.0F, -1.0F, 1.0F);
      this.model.setupAnim(entity, 0.0F, 0.0F, (float)entity.tickCount + tickDelta, 0.0F, 0.0F);
      this.model.renderToBuffer(matrices, vertexConsumers.getBuffer(this.model.renderType(TEXTURE)), light, OverlayTexture.NO_OVERLAY, -1);
      matrices.popPose();
      super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
   }

   public ResourceLocation getTextureLocation(CajeroEntity entity) {
      return TEXTURE;
   }
}
