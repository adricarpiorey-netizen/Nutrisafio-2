package com.eric.revill.event;

import com.eric.revill.bunker.Bunker;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

public class RedEventState extends SavedData {
   private boolean active;
   private int remainingSeconds;
   private boolean skyActive;
   private boolean announcementActive;
   private String taskId = RevillTask.BUNKER.id();
   private Bunker bunker = new Bunker();
   private int meteoritesActive;
   private String worldKey = "";

   public static RedEventState fromNbt(CompoundTag nbt) {
      RedEventState state = new RedEventState();
      state.active = nbt.getBoolean("active");
      state.remainingSeconds = nbt.getInt("remainingSeconds");
      state.skyActive = nbt.getBoolean("skyActive");
      state.announcementActive = nbt.getBoolean("announcementActive");
      state.taskId = nbt.contains("taskId") ? nbt.getString("taskId") : RevillTask.BUNKER.id();
      state.meteoritesActive = nbt.getInt("meteoritesActive");
      state.worldKey = nbt.getString("worldKey");
      Bunker bunker = new Bunker();
      bunker.setDimension(nbt.getString("bunkerDimension"));
      if (nbt.contains("bunkerPos1")) {
         CompoundTag pos1 = nbt.getCompound("bunkerPos1");
         bunker.setFirstCorner(new BlockPos(pos1.getInt("x"), pos1.getInt("y"), pos1.getInt("z")));
      }

      if (nbt.contains("bunkerPos2")) {
         CompoundTag pos2 = nbt.getCompound("bunkerPos2");
         bunker.setSecondCorner(new BlockPos(pos2.getInt("x"), pos2.getInt("y"), pos2.getInt("z")));
      }

      state.bunker = bunker;
      return state;
   }

   public CompoundTag save(CompoundTag nbt, net.minecraft.core.HolderLookup.Provider registries) {
      nbt.putBoolean("active", this.active);
      nbt.putInt("remainingSeconds", this.remainingSeconds);
      nbt.putBoolean("skyActive", this.skyActive);
      nbt.putBoolean("announcementActive", this.announcementActive);
      nbt.putString("taskId", this.taskId);
      nbt.putInt("meteoritesActive", this.meteoritesActive);
      nbt.putString("worldKey", this.worldKey);
      nbt.putString("bunkerDimension", this.bunker.getDimension());
      if (this.bunker.getFirstCorner() != null) {
         BlockPos pos = this.bunker.getFirstCorner();
         CompoundTag pos1 = new CompoundTag();
         pos1.putInt("x", pos.getX());
         pos1.putInt("y", pos.getY());
         pos1.putInt("z", pos.getZ());
         nbt.put("bunkerPos1", pos1);
      }

      if (this.bunker.getSecondCorner() != null) {
         BlockPos pos = this.bunker.getSecondCorner();
         CompoundTag pos2 = new CompoundTag();
         pos2.putInt("x", pos.getX());
         pos2.putInt("y", pos.getY());
         pos2.putInt("z", pos.getZ());
         nbt.put("bunkerPos2", pos2);
      }

      return nbt;
   }

   public boolean isActive() {
      return this.active;
   }

   public void setActive(boolean active) {
      this.active = active;
      this.setDirty();
   }

   public int getRemainingSeconds() {
      return this.remainingSeconds;
   }

   public void setRemainingSeconds(int remainingSeconds) {
      this.remainingSeconds = remainingSeconds;
      this.setDirty();
   }

   public boolean isSkyActive() {
      return this.skyActive;
   }

   public void setSkyActive(boolean skyActive) {
      this.skyActive = skyActive;
      this.setDirty();
   }

   public boolean isAnnouncementActive() {
      return this.announcementActive;
   }

   public void setAnnouncementActive(boolean announcementActive) {
      this.announcementActive = announcementActive;
      this.setDirty();
   }

   public String getTaskId() {
      return this.taskId;
   }

   public void setTaskId(String taskId) {
      this.taskId = RevillTask.fromId(taskId).id();
      this.setDirty();
   }

   public Bunker getBunker() {
      return this.bunker;
   }

   public void setBunker(Bunker bunker) {
      this.bunker = bunker;
      this.setDirty();
   }

   public int getMeteoritesActive() {
      return this.meteoritesActive;
   }

   public void setMeteoritesActive(int meteoritesActive) {
      this.meteoritesActive = meteoritesActive;
      this.setDirty();
   }

   public String getWorldKey() {
      return this.worldKey;
   }

   public void setWorldKey(String worldKey) {
      this.worldKey = worldKey;
      this.setDirty();
   }
}
