package com.eric.revill.entity;

import com.eric.revill.economy.EconomyNetworking;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class CajeroEntity extends Mob {
   private boolean spawnFacingInitialized;

   public CajeroEntity(EntityType<? extends CajeroEntity> entityType, Level world) {
      super(entityType, world);
      this.setPersistenceRequired();
   }

   public void tick() {
      super.tick();
      this.setNoGravity(true);
      this.noPhysics = true;
      this.setDeltaMovement(Vec3.ZERO);
      this.setXRot(0.0F);
      if (!this.level().isClientSide && !this.spawnFacingInitialized) {
         Player spawner = null;
         double closestDistance = 256.0;

         for (Player player : this.level().players()) {
            if (!player.isSpectator()) {
               double distance = this.distanceToSqr(player);
               if (distance < closestDistance) {
                  closestDistance = distance;
                  spawner = player;
               }
            }
         }

         this.initializeSpawnFacing(spawner);
      }
   }

   public void initializeSpawnFacing(Player player) {
      float yaw = this.getYRot();
      if (player != null) {
         double dx = player.getX() - this.getX();
         double dz = player.getZ() - this.getZ();
         if (dx != 0.0 || dz != 0.0) {
            yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
         }
      }

      yaw = (float)Math.round(yaw / 90.0F) * 90.0F;
      this.setYRot(yaw);
      this.setYBodyRot(yaw);
      this.setYHeadRot(yaw);
      this.spawnFacingInitialized = true;
   }

   public boolean isPushable() {
      return false;
   }

   public void push(Entity entity) {
   }

   public boolean hurt(DamageSource source, float amount) {
      if (source.getEntity() instanceof Player player && player.isCreative()) {
         this.discard();
         return true;
      }

      return false;
   }

   public boolean removeWhenFarAway(double distanceSquared) {
      return false;
   }

   public InteractionResult mobInteract(Player player, InteractionHand hand) {
      if (this.level().isClientSide) {
         return InteractionResult.SUCCESS;
      } else {
         if (player instanceof ServerPlayer serverPlayer) {
            EconomyNetworking.openAtm(serverPlayer);
         }

         return InteractionResult.CONSUME;
      }
   }

   public void addAdditionalSaveData(CompoundTag nbt) {
      nbt.putBoolean("SpawnFacingInitialized", this.spawnFacingInitialized);
   }

   public void readAdditionalSaveData(CompoundTag nbt) {
      this.spawnFacingInitialized = nbt.getBoolean("SpawnFacingInitialized");
   }
}
