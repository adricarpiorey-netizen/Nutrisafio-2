package com.eric.revill.network;

import com.eric.revill.network.Net;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public final class RevillNetworking {
   public static final ResourceLocation EVENT_STATE = ResourceLocation.fromNamespaceAndPath("revill", "event_state");
   public static final ResourceLocation ANNOUNCEMENT = ResourceLocation.fromNamespaceAndPath("revill", "announcement");
   public static final ResourceLocation STOP_EVENT = ResourceLocation.fromNamespaceAndPath("revill", "stop_event");
   public static final ResourceLocation ROULETTE = ResourceLocation.fromNamespaceAndPath("revill", "roulette");
   public static final ResourceLocation ROULETTE_ANNOUNCEMENT = ResourceLocation.fromNamespaceAndPath("revill", "roulette_announcement");
   public static final ResourceLocation NUTRIA_ANIMATION = ResourceLocation.fromNamespaceAndPath("revill", "nutria_animation");
   public static final ResourceLocation NUTRIA_ANIMATION_COMPLETE = ResourceLocation.fromNamespaceAndPath("revill", "nutria_animation_complete");
   public static final ResourceLocation REVILL_INTRO_DEATH = ResourceLocation.fromNamespaceAndPath("revill", "revill_intro_death");
   public static final ResourceLocation SKY_ONLY = ResourceLocation.fromNamespaceAndPath("revill", "sky_only");
   /** Cielo rojo de adorno (sin evento). Se guarda aqui para enviarlo a quien entre despues. */
   public static boolean skyOnlyActive = false;
   public static final ResourceLocation REVILL_INTRO_COMPLETE = ResourceLocation.fromNamespaceAndPath("revill", "revill_intro_complete");

   private RevillNetworking() {
   }

   public static void sendEventState(MinecraftServer server, boolean active, int remainingSeconds, boolean skyActive, boolean announcementActive) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeBoolean(active);
            buf.writeInt(remainingSeconds);
            buf.writeBoolean(skyActive);
            buf.writeBoolean(announcementActive);
            Net.send(player, EVENT_STATE, buf);
         }
      }
   }

   public static void sendAnnouncement(MinecraftServer server, int durationSeconds, double flashSpeed) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeInt(durationSeconds);
            buf.writeDouble(flashSpeed);
            Net.send(player, ANNOUNCEMENT, buf);
         }
      }
   }

   public static void sendStopEvent(MinecraftServer server) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeBoolean(false);
            Net.send(player, STOP_EVENT, buf);
         }
      }
   }

   public static void sendRoulette(MinecraftServer server, String color, String result) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeUtf(color);
            buf.writeUtf(result);
            Net.send(player, ROULETTE, buf);
         }
      }
   }

   public static void sendRouletteAnnouncement(MinecraftServer server, String color, String message) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            FriendlyByteBuf buf = PacketByteBufs.create();
            buf.writeUtf(color == null ? "naranja" : color, 32);
            buf.writeUtf(message, 32767);
            Net.send(player, ROULETTE_ANNOUNCEMENT, buf);
         }
      }
   }

   public static void sendRouletteAnnouncement(MinecraftServer server, String message) {
      sendRouletteAnnouncement(server, "naranja", message);
   }

   public static void sendNutriaAnimation(MinecraftServer server) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            Net.send(player, NUTRIA_ANIMATION, PacketByteBufs.empty());
         }
      }
   }

   public static void sendSkyOnly(ServerPlayer player, boolean active) {
      FriendlyByteBuf buf = PacketByteBufs.create();
      buf.writeBoolean(active);
      Net.send(player, SKY_ONLY, buf);
   }

   public static void setSkyOnly(MinecraftServer server, boolean active) {
      skyOnlyActive = active;
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            sendSkyOnly(player, active);
         }
      }
   }

   public static void sendRevillIntroDeath(MinecraftServer server) {
      if (server != null) {
         for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            Net.send(player, REVILL_INTRO_DEATH, PacketByteBufs.empty());
         }
      }
   }
}
