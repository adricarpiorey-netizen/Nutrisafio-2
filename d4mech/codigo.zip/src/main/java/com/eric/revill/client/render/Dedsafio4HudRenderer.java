package com.eric.revill.client.render;

import com.eric.revill.client.network.NetClient;
import com.eric.revill.client.sound.RevillEventAudio;
import com.eric.revill.network.RevillNetworking;
import com.mojang.blaze3d.platform.InputConstants;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

@Environment(EnvType.CLIENT)
public class Dedsafio4HudRenderer {
   private static final int ROULETTE_DURATION_TICKS = 280;
   private static final int DEATH_FRAME_COUNT = 163;
   private static final int NUTRIA_FRAME_COUNT = 98;
   private static final int NUTRIA_DURATION_TICKS = 164;
   private boolean rouletteActive;
   private boolean eventActive;
   private boolean deathAnimationActive;
   private boolean revillIntroDeathAnimation;
   private boolean nutriaAnimationActive;
   private boolean nutriaAnnouncementPending;
   private String rouletteColor = "roja";
   private String rouletteResult = "";
   private boolean deathNoticeActive;
   private boolean announcementCardActive;
   private boolean hideCardKeyDown;
   private String announcementCardText = "";
   private String announcementCardColor = "naranja";
   private String deathNoticeName = "";
   private String deathNoticeReason = "";
   private boolean deathNoticeIsSelf;
   private int rouletteAge;
   private int deathAge;
   private int nutriaAnimationAge;
   private int eventSeconds;
   private int deathNoticeAge;

   public void startRoulette(String color, String result) {
      this.rouletteActive = true;
      this.rouletteColor = color != null ? color.toLowerCase() : "roja";
      this.rouletteResult = result;
      this.rouletteAge = 0;
   }

   public void setEventState(boolean active, int remainingSeconds) {
      this.eventActive = active;
      this.eventSeconds = Math.max(0, remainingSeconds);
   }

   public void stopRoulette() {
      this.rouletteActive = false;
   }

   public void startNutriaAnimation() {
      this.nutriaAnimationActive = true;
      this.nutriaAnnouncementPending = true;
      this.nutriaAnimationAge = 0;
      RevillEventAudio.startNutria();
   }

   public void showAnnouncementCard(String message) {
      this.showAnnouncementCard(message, "naranja");
   }

   public void showAnnouncementCard(String message, String color) {
      this.announcementCardText = message == null ? "" : message;
      this.announcementCardColor = color == null ? "naranja" : color.toLowerCase();
      this.announcementCardActive = !this.announcementCardText.isBlank();
   }

   public void handleAnnouncementCardKey(Minecraft client) {
      boolean keyDown = client != null && client.screen == null && InputConstants.isKeyDown(client.getWindow().getWindow(), 79);
      if (keyDown && !this.hideCardKeyDown && this.announcementCardActive) {
         this.announcementCardActive = false;
      }

      this.hideCardKeyDown = keyDown;
   }

   public void startDeathAnimation() {
      this.deathAnimationActive = true;
      this.revillIntroDeathAnimation = false;
      this.deathAge = 0;
   }

   public void startRevillIntroDeathAnimation() {
      this.rouletteActive = false;
      this.deathAnimationActive = true;
      this.revillIntroDeathAnimation = true;
      this.deathAge = 0;
      RevillEventAudio.startDeathIntro();
   }

   public void showDeathNotice(String playerName, String reason, boolean self) {
      this.deathNoticeActive = true;
      this.deathNoticeName = playerName == null ? "Jugador" : playerName;
      this.deathNoticeReason = reason != null && !reason.isBlank() ? reason : "muerte";
      this.deathNoticeIsSelf = self;
      this.deathNoticeAge = 0;
   }

   public void tick() {
      if (this.rouletteActive) {
         this.rouletteAge++;
         if (this.rouletteAge >= 280) {
            this.rouletteActive = false;
         }
      }

      if (this.deathAnimationActive) {
         this.deathAge++;
         if (this.deathAge >= 163 && (!this.revillIntroDeathAnimation || !RevillEventAudio.isDeathIntroPlaying())) {
            this.deathAnimationActive = false;
            if (this.revillIntroDeathAnimation) {
               this.revillIntroDeathAnimation = false;
               RevillEventAudio.start();
               NetClient.send(RevillNetworking.REVILL_INTRO_COMPLETE, PacketByteBufs.empty());
            }
         }
      }

      if (this.nutriaAnimationActive && ++this.nutriaAnimationAge >= 164) {
         this.nutriaAnimationActive = false;
      }

      if (this.nutriaAnnouncementPending && this.nutriaAnimationAge > 1 && !RevillEventAudio.isNutriaPlaying()) {
         this.nutriaAnnouncementPending = false;
         NetClient.send(RevillNetworking.NUTRIA_ANIMATION_COMPLETE, PacketByteBufs.empty());
      }

      if (this.deathNoticeActive && ++this.deathNoticeAge > 80) {
         this.deathNoticeActive = false;
      }
   }

   public void render(GuiGraphics context) {
      Minecraft client = Minecraft.getInstance();
      if (client != null && client.font != null) {
         if (this.eventActive) {
            String timer = String.format("%02d:%02d", this.eventSeconds / 60, this.eventSeconds % 60);
            int x = (context.guiWidth() - client.font.width(timer)) / 2;
            context.drawString(client.font, Component.literal(timer), x, 8, -43691);
         }

         if (this.announcementCardActive) {
            this.renderAnnouncementCard(context, client);
         }

         int centerX = context.guiWidth() / 2;
         int centerY = context.guiHeight() / 2;
         if (this.rouletteActive) {
            int frameCount = this.rouletteFrameCount(this.rouletteColor);
            int frame = Math.max(1, Math.min(frameCount, 1 + this.rouletteAge * frameCount / 280));
            ResourceLocation texture = ResourceLocation.parse(
               "dedsafio-4-mechanics", "textures/gui/roulette/" + this.rouletteColor + "/" + this.rouletteColor + "-" + frame + ".png"
            );
            int scale = 175;
            int x = centerX - 87;
            int y = centerY - 87 - 18;
            context.blit(texture, x, y, 0.0F, 0.0F, 175, 175, 175, 175);
         }

         if (this.nutriaAnimationActive) {
            int frame = Math.min(98, 1 + this.nutriaAnimationAge * 98 / 164);
            ResourceLocation texture = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "textures/gui/nutria/nutria-" + frame + ".png");
            int width = context.guiWidth();
            int height = context.guiHeight();
            context.blit(texture, 0, 0, 0.0F, 0.0F, width, height, width, height);
         }

         if (this.deathAnimationActive) {
            int frame = Math.max(1, Math.min(163, this.deathAge));
            ResourceLocation texture = ResourceLocation.fromNamespaceAndPath("dedsafio-4-mechanics", "textures/gui/death/muerte-" + frame + ".png");
            context.blit(texture, centerX - 128, centerY - 128, 0.0F, 0.0F, 256, 256, 256, 256);
         }

         if (this.deathNoticeActive) {
            String message = this.deathNoticeName + " murió por " + this.deathNoticeReason;
            int textColor = -48060;
            int y = 12;
            context.drawCenteredString(client.font, Component.literal(message), centerX, y, textColor);
         }
      }
   }

   private void renderAnnouncementCard(GuiGraphics context, Minecraft client) {
      int left = 8;
      int top = 8;
      int maxWidth = Math.min(320, context.guiWidth() - 24);
      List<String> lines = this.wrapAnnouncement(this.announcementCardText, client, maxWidth - 16);
      int cardWidth = 16;

      for (String line : lines) {
         cardWidth = Math.max(cardWidth, client.font.width(line) + 16);
      }

      int cardHeight = lines.size() * 10 + 12;
      int textColor = this.toCardColor(this.announcementCardColor);
      context.fill(left, top, left + cardWidth, top + cardHeight, Integer.MIN_VALUE);

      for (int index = 0; index < lines.size(); index++) {
         context.drawString(client.font, Component.literal(lines.get(index)), left + 8, top + 6 + index * 10, textColor);
      }

      String hideText = "Ocultar tarjeta O";
      int hideWidth = client.font.width(hideText);
      context.drawString(client.font, Component.literal(hideText), left + (cardWidth - hideWidth) / 2, top + cardHeight + 3, textColor);
   }

   private List<String> wrapAnnouncement(String message, Minecraft client, int maxWidth) {
      List<String> lines = new ArrayList<>();

      for (String paragraph : message.split("\\n", -1)) {
         if (paragraph.isEmpty()) {
            lines.add("");
         } else {
            StringBuilder line = new StringBuilder();

            for (String word : paragraph.split("\\s+")) {
               String candidate = line.length() == 0 ? word : line + " " + word;
               if (client.font.width(candidate) > maxWidth && line.length() > 0) {
                  lines.add(line.toString());
                  line = new StringBuilder(word);
               } else {
                  line = new StringBuilder(candidate);
               }
            }

            if (line.length() > 0) {
               lines.add(line.toString());
            }
         }
      }

      return lines;
   }

   private int rouletteFrameCount(String color) {
      return switch (color) {
         case "naranja" -> 413;
         case "roja" -> 418;
         case "verde" -> 415;
         case "rosada" -> 389;
         default -> 413;
      };
   }

   private int toCardColor(String color) {
      String var2 = color == null ? "naranja" : color.toLowerCase();

      return switch (var2) {
         case "roja" -> -43691;
         case "verde" -> -11141291;
         case "rosada" -> -34868;
         case "naranja" -> -22016;
         default -> -10662;
      };
   }
}
