package com.eric.revill.mixin;

import com.eric.revill.RevillClient;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin({ClientLevel.class})
public abstract class ClientWorldMixin {
   @Inject(
      method = {"getSkyColor"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void dedsafio4$tintSkyRed(Vec3 cameraPosition, float tickDelta, CallbackInfoReturnable<Vec3> callbackInfo) {
      if (RevillClient.FUSION_RENDERER.isBlackWorld()) {
         callbackInfo.setReturnValue(Vec3.ZERO);
      } else {
         Vec3 vanilla = (Vec3)callbackInfo.getReturnValue();
         if (vanilla != null) {
            double t = (double)RevillClient.SKY_RENDERER.getTransition();
            double r = vanilla.x + (0.92 - vanilla.x) * t;
            double g = vanilla.y + (0.018 - vanilla.y) * t;
            double b = vanilla.z + (0.025 - vanilla.z) * t;
            callbackInfo.setReturnValue(new Vec3(r, g, b));
         }
      }
   }

   @Inject(
      method = {"getCloudColor"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void dedsafio4$tintCloudsRed(float tickDelta, CallbackInfoReturnable<Vec3> callbackInfo) {
      if (RevillClient.FUSION_RENDERER.isBlackWorld()) {
         callbackInfo.setReturnValue(Vec3.ZERO);
      } else {
         if (RevillClient.SKY_RENDERER.shouldTintSky()) {
            Vec3 vanilla = (Vec3)callbackInfo.getReturnValue();
            if (vanilla != null) {
               double t = (double)RevillClient.SKY_RENDERER.getTransition();
               double r = vanilla.x + (0.92 - vanilla.x) * t;
               double g = vanilla.y + (0.018 - vanilla.y) * t;
               double b = vanilla.z + (0.025 - vanilla.z) * t;
               callbackInfo.setReturnValue(new Vec3(r, g, b));
            }
         }
      }
   }
}
