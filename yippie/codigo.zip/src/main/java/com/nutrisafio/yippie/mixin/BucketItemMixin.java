package com.nutrisafio.yippie.mixin;

import com.nutrisafio.yippie.NutriYippie;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Si un jugador echa agua con el balde justo encima de la hierba, tambien puede salir un Yippie. */
@Mixin(BucketItem.class)
public abstract class BucketItemMixin {
    @Shadow @Final private Fluid content;

    @Inject(method = "emptyContents", at = @At("HEAD"))
    private void nutriYippie$baldeSobreHierba(Player player, Level level, BlockPos pos, BlockHitResult hit,
                                             CallbackInfoReturnable<Boolean> cir) {
        if (!(level instanceof ServerLevel server) || player == null || player.isCreative() || player.isSpectator()) return;
        if (this.content != Fluids.WATER) return;
        if (NutriYippie.esHierba(level.getBlockState(pos))) {
            NutriYippie.intentarSacarYippie(server, pos);
        }
    }
}
