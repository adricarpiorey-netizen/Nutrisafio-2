package com.nutrisafio.yippie.mixin;

import com.nutrisafio.yippie.NutriYippie;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.WaterFluid;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cuando el agua que corre rompe hierba, tambien puede salir un Yippie. */
@Mixin(WaterFluid.class)
public abstract class WaterFluidMixin {
    @Inject(method = "beforeDestroyingBlock", at = @At("HEAD"))
    private void nutriYippie$aguaRompeHierba(LevelAccessor level, BlockPos pos, BlockState state, CallbackInfo ci) {
        if (level instanceof ServerLevel server && NutriYippie.esHierba(state)
                && NutriYippie.hayJugadorCerca(server, pos)) {
            NutriYippie.intentarSacarYippie(server, pos);
        }
    }
}
