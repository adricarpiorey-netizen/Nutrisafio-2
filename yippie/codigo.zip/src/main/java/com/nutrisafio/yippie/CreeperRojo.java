package com.nutrisafio.yippie;

import net.minecraft.core.Holder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Creeper Rojo: igual que un creeper, pero
 * - explota con la fuerza de un creeper ELECTRICO (sin verse electrico),
 * - y a los jugadores cerca les pone un efecto malo al azar.
 * Suelta polvora y gotas de sangre.
 */
public class CreeperRojo extends Creeper {

    public CreeperRojo(EntityType<? extends Creeper> type, Level level) {
        super(type, level);
    }

    /** Hace que la explosion sea la de un creeper electrico (el doble de fuerte). */
    @Override
    public boolean isPowered() {
        return true;
    }

    @Override
    public void remove(RemovalReason reason) {
        // El creeper se "descarta" justo despues de explotar
        if (reason == RemovalReason.DISCARDED && !this.level().isClientSide && this.getSwelling(1.0f) >= 0.9f) {
            efectosMalos();
        }
        super.remove(reason);
    }

    private void efectosMalos() {
        for (Player p : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(7.0))) {
            if (p.isCreative() || p.isSpectator() || !p.isAlive()) continue;
            int n = this.random.nextInt(8);
            Holder<MobEffect> efecto;
            int segundos;
            int nivel = 0;
            switch (n) {
                case 0 -> { efecto = MobEffects.DARKNESS; segundos = 10; }
                case 1 -> { efecto = MobEffects.POISON; segundos = 8; }
                case 2 -> { efecto = MobEffects.MOVEMENT_SLOWDOWN; segundos = 10; nivel = 1; }
                case 3 -> { efecto = MobEffects.WEAKNESS; segundos = 15; }
                case 4 -> { efecto = MobEffects.CONFUSION; segundos = 10; }
                case 5 -> { efecto = MobEffects.BLINDNESS; segundos = 6; }
                case 6 -> { efecto = MobEffects.HUNGER; segundos = 15; nivel = 1; }
                default -> { efecto = MobEffects.DIG_SLOWDOWN; segundos = 15; nivel = 1; }
            }
            p.addEffect(new MobEffectInstance(efecto, segundos * 20, nivel));
        }
    }
}
