package com.nutrisafio.yippie;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;

/**
 * Yippie: un creeper chiquito (del tamano de un bloque).
 * - Tiene la mitad de vida de un creeper (5 corazones).
 * - Cuando se te acerca, se infla y explota el DOBLE de rapido que un creeper.
 * - La explosion NO rompe bloques y hace siempre 8 puntos de dano (4 corazones). Suena "yippee" al explotar.
 */
public class Yippie extends Monster {

    /** Ticks que tarda en explotar desde que empieza a inflarse (creeper = 30). */
    public static final int MECHA = 15;
    private static final float FUERZA = 5.0f;          // creeper = 3, creeper electrico = 6
    private static final float DANO = 8.0f;            // 8 puntos = 4 corazones
    private static final double DIST_INFLAR = 3.0;     // empieza a inflarse a esta distancia
    private static final double DIST_CANCELAR = 6.0;   // si te alejas mas, se desinfla

    private static final EntityDataAccessor<Integer> DATA_INFLADO =
            SynchedEntityData.defineId(Yippie.class, EntityDataSerializers.INT);

    private int inflado;
    private int infladoAntes;

    public Yippie(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)       // creeper = 20
                .add(Attributes.MOVEMENT_SPEED, 0.3)    // creeper = 0.25
                .add(Attributes.FOLLOW_RANGE, 20.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_INFLADO, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.1, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
    }

    /** No muerde: solo se acerca para explotar. */
    @Override
    public boolean doHurtTarget(Entity target) {
        return false;
    }

    /** Para el renderer: 0 = normal, 1 = a punto de explotar. */
    public float getInflado(float partialTick) {
        return (this.infladoAntes + (this.inflado - this.infladoAntes) * partialTick) / (float) (MECHA - 2);
    }

    @Override
    public void tick() {
        if (this.isAlive()) {
            this.infladoAntes = this.inflado;
            if (!this.level().isClientSide) {
                LivingEntity objetivo = this.getTarget();
                boolean cerca = objetivo != null && objetivo.isAlive() && this.hasLineOfSight(objetivo)
                        && this.distanceTo(objetivo) < DIST_INFLAR;
                boolean lejos = objetivo == null || !objetivo.isAlive() || this.distanceTo(objetivo) > DIST_CANCELAR;
                int antes = this.entityData.get(DATA_INFLADO);
                int ahora = antes;
                if (cerca || (antes > 0 && !lejos)) ahora = antes + 1;
                else if (antes > 0) ahora = Math.max(0, antes - 1);
                if (antes == 0 && ahora > 0) {
                    this.playSound(SoundEvents.CREEPER_PRIMED, 1.0f, 1.6f);   // mas agudo: es chiquito
                }
                this.entityData.set(DATA_INFLADO, ahora);
                if (ahora >= MECHA) {
                    explotar();
                    return;
                }
            }
            this.inflado = this.entityData.get(DATA_INFLADO);
        }
        super.tick();
    }

    /** La explosion hace siempre 4 puntos de dano (2 corazones) a quien alcance. */
    private static final ExplosionDamageCalculator DANO_FIJO = new ExplosionDamageCalculator() {
        @Override
        public float getEntityDamageAmount(Explosion explosion, Entity entity) {
            return super.getEntityDamageAmount(explosion, entity) > 0 ? DANO : 0.0f;
        }
    };

    private void explotar() {
        this.dead = true;
        // Sonido "yippee" (lo escuchan los jugadores cercanos)
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), NutriYippie.SONIDO_YIPPEE,
                net.minecraft.sounds.SoundSource.HOSTILE, 2.0f, 1.0f);
        // No rompe bloques (ExplosionInteraction.NONE)
        this.level().explode(this, null, DANO_FIJO, this.getX(), this.getY(), this.getZ(), FUERZA, false,
                Level.ExplosionInteraction.NONE);
        this.discard();
    }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.world.damagesource.DamageSource source) {
        return SoundEvents.CREEPER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.CREEPER_DEATH;
    }
}
