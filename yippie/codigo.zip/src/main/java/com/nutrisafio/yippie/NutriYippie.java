package com.nutrisafio.yippie;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.level.block.Blocks;

/**
 * Nutrisafio Yippie: un creeper chiquito que sale al romper pasto (10 % de probabilidad).
 */
public class NutriYippie implements ModInitializer {

    public static final String MOD_ID = "nutri_yippie";

    /** Probabilidad de que salga un Yippie al romper pasto (0.10 = 10 %). */
    public static final float PROBABILIDAD = 0.10f;

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    public static final EntityType<Yippie> YIPPIE = Registry.register(BuiltInRegistries.ENTITY_TYPE, id("yippie"),
            EntityType.Builder.of(Yippie::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.0f)
                    .clientTrackingRange(8)
                    .build("yippie"));

    public static final Item HUEVO = Registry.register(BuiltInRegistries.ITEM, id("yippie_spawn_egg"),
            new SpawnEggItem(YIPPIE, 0xF4EEFF, 0xB98CF0, new Item.Properties()));

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(YIPPIE, Yippie.createAttributes());
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS).register(entries -> entries.accept(HUEVO));

        // Al romper un bloque de pasto o hierba: 10 % de que salga un Yippie
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> {
            if (!(level instanceof ServerLevel server) || player.isCreative() || player.isSpectator()) return;
            if (!(state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.SHORT_GRASS) || state.is(Blocks.TALL_GRASS))) return;
            if (server.random.nextFloat() >= PROBABILIDAD) return;
            Yippie y = YIPPIE.create(server);
            if (y == null) return;
            y.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, server.random.nextFloat() * 360f, 0f);
            server.addFreshEntity(y);
            server.sendParticles(ParticleTypes.POOF, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 12, 0.3, 0.3, 0.3, 0.02);
            server.playSound(null, pos, SoundEvents.CHICKEN_EGG, SoundSource.HOSTILE, 1.0f, 1.8f);
        });
    }
}
