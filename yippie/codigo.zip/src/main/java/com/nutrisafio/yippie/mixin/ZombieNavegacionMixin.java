package com.nutrisafio.yippie.mixin;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Drowned;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Los zombies buscan camino como las aranas (van directo a la pared para treparla). */
@Mixin(Mob.class)
public abstract class ZombieNavegacionMixin {
    @Inject(method = "createNavigation", at = @At("HEAD"), cancellable = true)
    private void nutriYippie$navegacionArana(Level level, CallbackInfoReturnable<PathNavigation> cir) {
        if ((Object) this instanceof Zombie && !((Object) this instanceof Drowned)) {
            cir.setReturnValue(new WallClimberNavigation((Mob) (Object) this, level));
        }
    }
}
