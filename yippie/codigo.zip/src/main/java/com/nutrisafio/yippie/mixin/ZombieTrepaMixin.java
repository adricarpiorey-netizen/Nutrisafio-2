package com.nutrisafio.yippie.mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Zombie;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Los zombies trepan paredes como las aranas: si chocan contra una pared, suben. */
@Mixin(LivingEntity.class)
public abstract class ZombieTrepaMixin {
    @Inject(method = "onClimbable", at = @At("HEAD"), cancellable = true)
    private void nutriYippie$zombieTrepa(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof Zombie z && z.horizontalCollision) {
            cir.setReturnValue(true);
        }
    }
}
