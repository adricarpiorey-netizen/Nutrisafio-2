package com.nutrisafio.yippie.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.nutrisafio.yippie.Yippie;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/** Modelo "YIPPIE" (convertido del proyecto CPM). Camina en cuatro patas y mueve la cabeza. */
public class YippieModel extends HierarchicalModel<Yippie> {
    private final ModelPart root;
    private final ModelPart cabeza;
    private final ModelPart pataDelIzq, pataDelDer, pataTrasIzq, pataTrasDer;

    public YippieModel(ModelPart root) {
        this.root = root;
        this.cabeza = root.getChild("head");
        this.pataDelIzq = root.getChild("left_arm");
        this.pataDelDer = root.getChild("right_arm");
        this.pataTrasIzq = root.getChild("left_leg");
        this.pataTrasDer = root.getChild("right_leg");
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        JsonModelLoader.render(this.root, poseStack, buffer, packedLight, packedOverlay, color);
    }

    @Override
    public void setupAnim(Yippie entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        this.cabeza.yRot += netHeadYaw * Mth.DEG_TO_RAD * 0.7F;
        this.cabeza.xRot += headPitch * Mth.DEG_TO_RAD * 0.5F;
        float paso = Mth.cos(limbSwing * 1.2F) * 1.2F * limbSwingAmount;
        this.pataDelIzq.xRot += paso;
        this.pataTrasDer.xRot += paso;
        this.pataDelDer.xRot -= paso;
        this.pataTrasIzq.xRot -= paso;
        // Cuando se infla, tiembla un poquito
        float inflado = entity.getInflado(0f);
        if (inflado > 0) this.cabeza.zRot += Mth.sin(ageInTicks * 2.5F) * 0.08F * inflado;
    }
}
