package com.nutrisafio.yippie.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nutrisafio.yippie.NutriYippie;
import com.nutrisafio.yippie.Yippie;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Se infla y parpadea en blanco antes de explotar, igual que un creeper. */
public class YippieRenderer extends MobRenderer<Yippie, YippieModel> {
    private static final ResourceLocation TEXTURA = NutriYippie.id("textures/entity/yippie.png");

    public YippieRenderer(EntityRendererProvider.Context context) {
        super(context, new YippieModel(JsonModelLoader.load("yippie")), 0.35F);
    }

    @Override
    public ResourceLocation getTextureLocation(Yippie entity) {
        return TEXTURA;
    }

    @Override
    protected void scale(Yippie entity, PoseStack poseStack, float partialTick) {
        float f = entity.getInflado(partialTick);
        float g = 1.0F + Mth.sin(f * 100.0F) * f * 0.01F;
        f = Mth.clamp(f, 0.0F, 1.0F);
        f *= f;
        f *= f;
        float h = (1.0F + f * 0.4F) * g;
        float i = (1.0F + f * 0.1F) / g;
        poseStack.scale(h, i, h);
    }

    @Override
    protected float getWhiteOverlayProgress(Yippie entity, float partialTick) {
        float f = entity.getInflado(partialTick);
        return (int) (f * 10.0F) % 2 == 0 ? 0.0F : Mth.clamp(f, 0.5F, 1.0F);
    }
}
