package com.nutrisafio.yippie.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nutrisafio.yippie.CreeperRojo;
import com.nutrisafio.yippie.NutriYippie;
import net.minecraft.client.model.CreeperModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** El modelo del creeper normal, pintado de rojo (sin el brillo de creeper electrico). */
public class CreeperRojoRenderer extends MobRenderer<CreeperRojo, CreeperModel<CreeperRojo>> {
    private static final ResourceLocation TEXTURA = NutriYippie.id("textures/entity/creeper_rojo.png");

    public CreeperRojoRenderer(EntityRendererProvider.Context context) {
        super(context, new CreeperModel<>(context.bakeLayer(ModelLayers.CREEPER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(CreeperRojo entity) {
        return TEXTURA;
    }

    @Override
    protected void scale(CreeperRojo entity, PoseStack poseStack, float partialTick) {
        float f = entity.getSwelling(partialTick);
        float g = 1.0F + Mth.sin(f * 100.0F) * f * 0.01F;
        f = Mth.clamp(f, 0.0F, 1.0F);
        f *= f;
        f *= f;
        float h = (1.0F + f * 0.4F) * g;
        float i = (1.0F + f * 0.1F) / g;
        poseStack.scale(h, i, h);
    }

    @Override
    protected float getWhiteOverlayProgress(CreeperRojo entity, float partialTick) {
        float f = entity.getSwelling(partialTick);
        return (int) (f * 10.0F) % 2 == 0 ? 0.0F : Mth.clamp(f, 0.5F, 1.0F);
    }
}
