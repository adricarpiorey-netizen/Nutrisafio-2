package com.nutrisafio.yippie.client;

import com.nutrisafio.yippie.NutriYippie;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NutriYippieClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(NutriYippie.YIPPIE, YippieRenderer::new);
    }
}
