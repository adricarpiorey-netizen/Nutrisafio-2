package com.nutrisafio.dedsafio;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Corazon (igual que en Dedsafio 3): al comerlo, tu vida maxima sube medio corazon para siempre. */
public class CorazonItem extends Item {

    public CorazonItem(Properties properties) {
        super(properties);
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 30;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (!level.isClientSide) {
            AttributeInstance vida = entity.getAttribute(Attributes.MAX_HEALTH);
            if (vida != null) vida.setBaseValue(vida.getBaseValue() + 1.0);
        }
        return result;
    }
}
