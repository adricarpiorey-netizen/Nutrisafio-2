package com.nutrisafio.dedsafio.mobs;

import com.nutrisafio.dedsafio.DedsafioNutri;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Flashbang: te persigue y explota dejandote la pantalla en blanco y un pitido en los oidos. */
public class Flashbang extends MonstruoGeo {
    private int espera = 0;

    public Flashbang(EntityType<? extends Monster> type, Level level) { super(type, level); }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MOVEMENT_SPEED, 0.3).add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.ATTACK_DAMAGE, 3.0).add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, false));
        this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
        this.goalSelector.addGoal(3, new RandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(5, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    @Override
    public void baseTick() {
        super.baseTick();
        espera = Explosivo.perseguir(this, espera, 20.0, 30, 3.0, () -> {
            this.level().playSound(null, this.blockPosition(), DedsafioNutri.SONIDO_FLASHBANG, SoundSource.HOSTILE, 2.0f, 1.0f);
            for (Player p : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(5.0))) {
                if (!p.isCreative() && !p.isSpectator()) p.playNotifySound(DedsafioNutri.SONIDO_RING, SoundSource.HOSTILE, 1.0f, 1.0f);
            }
            Explosivo.explotar(this, 4.0f, 5.0, DedsafioNutri.FLASHBANG_EFECTO, 100);
        });
    }

    @Override protected String animQuieto() { return "idle"; }
    @Override protected String animCaminar() { return "walk"; }
}
