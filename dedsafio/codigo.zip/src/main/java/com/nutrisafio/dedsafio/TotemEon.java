package com.nutrisafio.dedsafio;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Totem Eon (item del mod DEDSAFIO4): funciona con solo tenerlo en el inventario,
 * no hace falta tenerlo en la mano. Al usarse muestra la animacion con la imagen
 * del Totem Eon y avisa en el chat "uso un Totem Eon".
 */
public final class TotemEon {
    public static final String ID_EON = "dedsafio4:totem_eon";

    /** Paquete al jugador para que vea la animacion con la imagen del Totem Eon. */
    public record PopPayload() implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<PopPayload> TYPE =
                new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath("dedsafio_nutri", "pop_eon"));
        public static final StreamCodec<RegistryFriendlyByteBuf, PopPayload> CODEC = StreamCodec.unit(new PopPayload());

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // Fase temprana: se revisa ANTES que el mod DEDSAFIO4 y que el totem normal
    private static final ResourceLocation TEMPRANO = ResourceLocation.fromNamespaceAndPath("dedsafio_nutri", "totem_eon");

    private TotemEon() {
    }

    public static void registrar() {
        PayloadTypeRegistry.playS2C().register(PopPayload.TYPE, PopPayload.CODEC);
        ServerLivingEntityEvents.ALLOW_DEATH.addPhaseOrdering(TEMPRANO, Event.DEFAULT_PHASE);
        ServerLivingEntityEvents.ALLOW_DEATH.register(TEMPRANO, (entity, source, amount) ->
                !(entity instanceof ServerPlayer jugador) || !usar(jugador, source));
    }

    private static Item item(String id) {
        return BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(id)).orElse(null);
    }

    private static boolean es(ItemStack stack, String id) {
        Item it = item(id);
        return it != null && stack.is(it);
    }

    /** Devuelve true si el Totem Eon salvo al jugador. */
    private static boolean usar(ServerPlayer p, DamageSource source) {
        // /kill y el vacio no se pueden evitar (igual que un totem normal)
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return false;
        }
        Item eon = item(ID_EON);
        if (eon == null) {
            return false;
        }
        // Si tiene otro totem EN LA MANO, ese funciona como siempre
        for (InteractionHand mano : InteractionHand.values()) {
            ItemStack s = p.getItemInHand(mano);
            if (s.is(Items.TOTEM_OF_UNDYING) || es(s, "dedsafio4:totem_nutria")
                    || es(s, "dedsafio4:totem_hieron_gollem") || es(s, "dedsafio4:cucharon_resurreccion")) {
                return false;
            }
        }
        // Buscar el Totem Eon: primero en las manos, despues en todo el inventario
        ItemStack encontrado = null;
        for (InteractionHand mano : InteractionHand.values()) {
            ItemStack s = p.getItemInHand(mano);
            if (s.is(eon)) {
                encontrado = s;
                break;
            }
        }
        if (encontrado == null) {
            Inventory inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (s.is(eon)) {
                    encontrado = s;
                    break;
                }
            }
        }
        if (encontrado == null) {
            return false;
        }

        ItemStack usado = encontrado.copyWithCount(1);
        encontrado.shrink(1);

        // Mismos efectos que el Totem Eon del mod DEDSAFIO4
        p.setHealth(1.0F);
        p.removeAllEffects();
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 100, 1));
        p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 800, 0));

        ServerLevel nivel = p.serverLevel();
        nivel.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1.0, p.getZ(), 60, 0.5, 1.0, 0.5, 0.6);
        nivel.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1.0F, 1.0F);

        // Animacion en pantalla con la imagen del Totem Eon
        if (ServerPlayNetworking.canSend(p, PopPayload.TYPE)) {
            ServerPlayNetworking.send(p, new PopPayload());
        }

        p.awardStat(Stats.ITEM_USED.get(eon));
        CriteriaTriggers.USED_TOTEM.trigger(p, usado);

        Component aviso = Component.literal("✦ ").withStyle(ChatFormatting.GOLD)
                .append(Component.literal(p.getGameProfile().getName()).withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD))
                .append(Component.literal(" usó un ").withStyle(ChatFormatting.GOLD))
                .append(Component.literal("Tótem Eón").withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD));
        p.server.getPlayerList().broadcastSystemMessage(aviso, false);

        // Tambien cuenta para el Nucleeper (1 %), igual que los otros totems
        p.server.getCommands().performPrefixedCommand(
                p.createCommandSourceStack().withSuppressedOutput().withPermission(4), "function totem_nuclear:popeo");
        return true;
    }
}
