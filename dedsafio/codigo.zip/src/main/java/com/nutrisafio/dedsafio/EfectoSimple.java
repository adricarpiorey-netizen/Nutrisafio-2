package com.nutrisafio.dedsafio;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Efecto sin logica propia (su efecto lo maneja el mod o la pantalla del jugador). */
public class EfectoSimple extends MobEffect {
    public EfectoSimple(MobEffectCategory category, int color) {
        super(category, color);
    }
}
