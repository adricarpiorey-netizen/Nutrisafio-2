package com.nutrisafio.dedsafio.mobs;

import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;

/** Logica compartida del Flashbang y el Creeper Pastel (igual que en Dedsafio 3). */
final class Explosivo {
    private Explosivo() {}

    /**
     * Persigue al jugador en supervivencia mas cercano; despues de esperar unos ticks,
     * si esta lo bastante cerca, explota.
     * @return el nuevo valor del contador de espera
     */
    static int perseguir(Mob mob, int espera, double rango, int esperaMax, double distExplota, Runnable explotar) {
        if (mob.level().isClientSide) return espera;
        Player p = mob.level().getNearestPlayer(mob, rango);
        if (p instanceof ServerPlayer sp && sp.gameMode.getGameModeForPlayer() == GameType.SURVIVAL) {
            mob.getNavigation().moveTo(p, 1.0);
            if (espera < esperaMax) return espera + 1;
            if (mob.distanceTo(p) <= distExplota) explotar.run();
        }
        return espera;
    }

    static void explotar(Mob mob, float fuerza, double radioEfecto, Holder<MobEffect> efecto, int duracion) {
        if (mob.level().isClientSide || mob.isRemoved()) return;
        mob.level().explode(mob, mob.getX(), mob.getY(), mob.getZ(), fuerza, false, Level.ExplosionInteraction.MOB);
        for (Player p : mob.level().getEntitiesOfClass(Player.class, mob.getBoundingBox().inflate(radioEfecto))) {
            if (!p.isCreative() && !p.isSpectator()) p.addEffect(new MobEffectInstance(efecto, duracion, 0, true, true));
        }
        mob.remove(Entity.RemovalReason.KILLED);
    }
}
