package com.nutrisafio.dedsafio;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import com.nutrisafio.dedsafio.mobs.*;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;

/**
 * Nutrisafio Dedsafio: cosas del mod "Dedsafio 3" (Pakinhop y ForzakenNeon, licencia MIT)
 * adaptadas a Fabric 1.21.1 para el servidor Nutrisafio.
 * Incluye: Casino, Deditas, mobs (Infernal Bull, Ranas, Revil, Reviil, Tiki Guardian, Flashbang,
 * Creeper Pastel), Sacos de Shulker, Protector Solar y Repelente anti-bombas.
 */
public class DedsafioNutri implements ModInitializer {

    public static final String MOD_ID = "dedsafio_nutri";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    private static Item item(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, id(name), item);
    }

    private static Item dedita(String name, Rarity rarity) {
        return item(name, new Item(new Item.Properties().stacksTo(64).rarity(rarity)));
    }

    // ---------------- Deditas ----------------
    public static final Item DEDITA = dedita("dedita", Rarity.COMMON);
    public static final Item DEDITACASINO = dedita("deditacasino", Rarity.RARE);
    public static final Item DEDITA_ROJA = dedita("dedita_roja", Rarity.RARE);
    public static final Item DEDITA_VERDE = dedita("dedita_verde", Rarity.RARE);
    public static final Item DEDITA_ROSA = dedita("dedita_rosa", Rarity.RARE);
    public static final Item DEDITA_AMARILLA = dedita("dedita_amarilla", Rarity.RARE);
    public static final Item DEDITA_MORADA = dedita("dedita_morada", Rarity.RARE);
    public static final Item DEDITAMULTICOLOR = dedita("deditamulticolor", Rarity.RARE);
    public static final Item DEDITA_MISION = dedita("dedita_mision", Rarity.RARE);

    // ---------------- Premios del Casino ----------------
    public static final Item BROCOLI = item("brocoli", new Item(new Item.Properties().stacksTo(64)));
    public static final Item CORAZON = item("corazon", new CorazonItem(new Item.Properties()
            .stacksTo(64).rarity(Rarity.RARE)
            .food(new FoodProperties.Builder().nutrition(0).saturationModifier(0.1f).alwaysEdible().build())));

    // ---------------- Casino ----------------
    public static final EntityType<CasinoEntity> CASINO = Registry.register(BuiltInRegistries.ENTITY_TYPE, id("casino"),
            EntityType.Builder.of(CasinoEntity::new, MobCategory.MISC)
                    .sized(0.6f, 2.3f)
                    .clientTrackingRange(10)
                    .build("casino"));

    public static final Item CASINO_SPAWN_EGG = item("casino_spawn_egg",
            new SpawnEggItem(CASINO, 0x2B2B2B, 0xE8A13A, new Item.Properties()));

    // ---------------- Efectos ----------------
    private static Holder<MobEffect> efecto(String name, MobEffectCategory cat, int color) {
        return Registry.registerForHolder(BuiltInRegistries.MOB_EFFECT, id(name), new EfectoSimple(cat, color));
    }

    public static final Holder<MobEffect> BLOQUEADOR = efecto("bloqueador", MobEffectCategory.BENEFICIAL, 0xF5C542);
    public static final Holder<MobEffect> REPELENTE = efecto("repelente", MobEffectCategory.BENEFICIAL, 0x7BC96F);
    public static final Holder<MobEffect> FLASHBANG_EFECTO = efecto("flashbang", MobEffectCategory.HARMFUL, 0xEEEEEE);
    public static final Holder<MobEffect> TORTAZO = efecto("tortazo", MobEffectCategory.HARMFUL, 0xF2A7C3);

    // ---------------- Sonidos ----------------
    private static SoundEvent sonido(String name) {
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id(name), SoundEvent.createVariableRangeEvent(id(name)));
    }

    public static final SoundEvent SONIDO_FLASHBANG = sonido("flashbang");
    public static final SoundEvent SONIDO_RING = sonido("ring");

    // ---------------- Mobs ----------------
    private static <T extends Entity> EntityType<T> mob(String name, EntityType.EntityFactory<T> f, float w, float h) {
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, id(name),
                EntityType.Builder.of(f, MobCategory.MONSTER).sized(w, h).clientTrackingRange(10).build(name));
    }

    public static final EntityType<InfernalBull> INFERNAL_BULL = mob("infernal_bull", InfernalBull::new, 2.0f, 2.0f);
    public static final EntityType<Rana> RANA = mob("rana", Rana::new, 0.7f, 0.7f);
    public static final EntityType<RanaGigante> RANA_GIGANTE = mob("rana_gigante", RanaGigante::new, 0.6f, 1.8f);
    public static final EntityType<Reviil> REVIIL = mob("reviil", Reviil::new, 3.0f, 6.6f);
    public static final EntityType<Revil> REVIL = mob("revil", Revil::new, 2.4f, 5.7f);
    public static final EntityType<TikiGuardian> TIKI_GUARDIAN = mob("tiki_guardian", TikiGuardian::new, 4.5f, 5.0f);
    public static final EntityType<Flashbang> FLASHBANG = mob("flashbang", Flashbang::new, 0.6f, 2.0f);
    public static final EntityType<CreeperPastel> CREEPER_PASTEL = mob("creeper_pastel", CreeperPastel::new, 0.6f, 1.8f);

    private static Item huevo(String name, EntityType<? extends Mob> type, int c1, int c2) {
        return item(name + "_spawn_egg", new SpawnEggItem(type, c1, c2, new Item.Properties()));
    }

    public static final Item HUEVO_INFERNAL_BULL = huevo("infernal_bull", INFERNAL_BULL, 0x3A0A06, 0xF06A1A);
    public static final Item HUEVO_RANA = huevo("rana", RANA, 0x3F7A2A, 0xC9E36B);
    public static final Item HUEVO_RANA_GIGANTE = huevo("rana_gigante", RANA_GIGANTE, 0x2E5E22, 0xE8D27A);
    public static final Item HUEVO_REVIIL = huevo("reviil", REVIIL, 0x1C1C1C, 0xB01818);
    public static final Item HUEVO_REVIL = huevo("revil", REVIL, 0x2A2A2A, 0x8E1E1E);
    public static final Item HUEVO_TIKI = huevo("tiki_guardian", TIKI_GUARDIAN, 0x6B4423, 0x3DBE6B);
    public static final Item HUEVO_FLASHBANG = huevo("flashbang", FLASHBANG, 0x555555, 0xFFFFFF);
    public static final Item HUEVO_CREEPER_PASTEL = huevo("creeper_pastel", CREEPER_PASTEL, 0xF7B6D2, 0xFFF4E0);

    // ---------------- Sacos de Shulker ----------------
    public static final String[] COLORES = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
            "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
    public static final Item SACO = item("shulkerbag", new SacoItem(new Item.Properties().stacksTo(1)));
    public static final Item[] SACOS_COLOR = new Item[COLORES.length];
    static {
        for (int i = 0; i < COLORES.length; i++)
            SACOS_COLOR[i] = item(COLORES[i] + "_shulker_bag", new SacoItem(new Item.Properties().stacksTo(1)));
    }

    // ---------------- Protector Solar y Repelente ----------------
    public static final Item PROTECTOR_SOLAR = item("procectorsolar",
            new ProtectorItem(new Item.Properties().stacksTo(64), () -> BLOQUEADOR, true));
    public static final Item PROTECTOR_SOLAR_APLICABLE = item("protector_solar_aplicable",
            new ProtectorItem(new Item.Properties().stacksTo(64), () -> BLOQUEADOR, false));
    public static final Item REPELENTE_ANTIBOMBAS = item("bomba_bloqueador",
            new ProtectorItem(new Item.Properties().stacksTo(64), () -> REPELENTE, false));

    // ---------------- Pestana del creativo ----------------
    public static final CreativeModeTab TAB = Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("dedsafio"),
            FabricItemGroup.builder()
                    .title(Component.translatable("itemGroup.dedsafio_nutri"))
                    .icon(() -> new ItemStack(DEDITACASINO))
                    .displayItems((params, output) -> {
                        output.accept(CASINO_SPAWN_EGG);
                        output.accept(DEDITA);
                        output.accept(DEDITACASINO);
                        output.accept(DEDITA_ROJA);
                        output.accept(DEDITA_VERDE);
                        output.accept(DEDITA_ROSA);
                        output.accept(DEDITA_AMARILLA);
                        output.accept(DEDITA_MORADA);
                        output.accept(DEDITAMULTICOLOR);
                        output.accept(DEDITA_MISION);
                        output.accept(BROCOLI);
                        output.accept(CORAZON);
                        output.accept(HUEVO_INFERNAL_BULL);
                        output.accept(HUEVO_RANA);
                        output.accept(HUEVO_RANA_GIGANTE);
                        output.accept(HUEVO_REVIL);
                        output.accept(HUEVO_REVIIL);
                        output.accept(HUEVO_TIKI);
                        output.accept(HUEVO_FLASHBANG);
                        output.accept(HUEVO_CREEPER_PASTEL);
                        output.accept(SACO);
                        for (Item s : SACOS_COLOR) output.accept(s);
                        output.accept(PROTECTOR_SOLAR);
                        output.accept(PROTECTOR_SOLAR_APLICABLE);
                        output.accept(REPELENTE_ANTIBOMBAS);
                    })
                    .build());

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(CASINO, CasinoEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(INFERNAL_BULL, InfernalBull.createAttributes());
        FabricDefaultAttributeRegistry.register(RANA, Rana.createAttributes());
        FabricDefaultAttributeRegistry.register(RANA_GIGANTE, RanaGigante.createAttributes());
        FabricDefaultAttributeRegistry.register(REVIIL, Reviil.createAttributes());
        FabricDefaultAttributeRegistry.register(REVIL, Revil.createAttributes());
        FabricDefaultAttributeRegistry.register(TIKI_GUARDIAN, TikiGuardian.createAttributes());
        FabricDefaultAttributeRegistry.register(FLASHBANG, Flashbang.createAttributes());
        FabricDefaultAttributeRegistry.register(CREEPER_PASTEL, CreeperPastel.createAttributes());
    }
}
