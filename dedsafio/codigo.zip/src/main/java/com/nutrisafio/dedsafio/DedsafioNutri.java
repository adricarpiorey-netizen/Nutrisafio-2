package com.nutrisafio.dedsafio;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;

/**
 * Nutrisafio Dedsafio: cosas del mod "Dedsafio 3" (Pakinhop y ForzakenNeon, licencia MIT)
 * adaptadas a Fabric 1.21.1 para el servidor Nutrisafio.
 * Etapa 1: el Casino y las Deditas.
 */
public class DedsafioNutri implements ModInitializer {

    public static final String MOD_ID = "dedsafio_nutri";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    private static Item item(String name, Item item) {
        return Registry.register(BuiltInRegistries.ITEM, id(name), item);
    }

    private static Item dedita(String name, Rarity rarity) {
        return item(name, new Item(new Item.Properties().stacksTo(64).rarity(rarity)));
    }

    // ---------------- Deditas ----------------
    public static final Item DEDITA = dedita("dedita", Rarity.COMMON);
    public static final Item DEDITACASINO = dedita("deditacasino", Rarity.RARE);
    public static final Item DEDITA_ROJA = dedita("dedita_roja", Rarity.RARE);
    public static final Item DEDITA_VERDE = dedita("dedita_verde", Rarity.RARE);
    public static final Item DEDITA_ROSA = dedita("dedita_rosa", Rarity.RARE);
    public static final Item DEDITA_AMARILLA = dedita("dedita_amarilla", Rarity.RARE);
    public static final Item DEDITA_MORADA = dedita("dedita_morada", Rarity.RARE);
    public static final Item DEDITAMULTICOLOR = dedita("deditamulticolor", Rarity.RARE);
    public static final Item DEDITA_MISION = dedita("dedita_mision", Rarity.RARE);

    // ---------------- Premios del Casino ----------------
    public static final Item BROCOLI = item("brocoli", new Item(new Item.Properties().stacksTo(64)));
    public static final Item CORAZON = item("corazon", new CorazonItem(new Item.Properties()
            .stacksTo(64).rarity(Rarity.RARE)
            .food(new FoodProperties.Builder().nutrition(0).saturationModifier(0.1f).alwaysEdible().build())));

    // ---------------- Casino ----------------
    public static final EntityType<CasinoEntity> CASINO = Registry.register(BuiltInRegistries.ENTITY_TYPE, id("casino"),
            EntityType.Builder.of(CasinoEntity::new, MobCategory.MISC)
                    .sized(0.6f, 2.3f)
                    .clientTrackingRange(10)
                    .build("casino"));

    public static final Item CASINO_SPAWN_EGG = item("casino_spawn_egg",
            new SpawnEggItem(CASINO, 0x2B2B2B, 0xE8A13A, new Item.Properties()));

    // ---------------- Pestana del creativo ----------------
    public static final CreativeModeTab TAB = Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, id("dedsafio"),
            FabricItemGroup.builder()
                    .title(Component.translatable("itemGroup.dedsafio_nutri"))
                    .icon(() -> new ItemStack(DEDITACASINO))
                    .displayItems((params, output) -> {
                        output.accept(CASINO_SPAWN_EGG);
                        output.accept(DEDITA);
                        output.accept(DEDITACASINO);
                        output.accept(DEDITA_ROJA);
                        output.accept(DEDITA_VERDE);
                        output.accept(DEDITA_ROSA);
                        output.accept(DEDITA_AMARILLA);
                        output.accept(DEDITA_MORADA);
                        output.accept(DEDITAMULTICOLOR);
                        output.accept(DEDITA_MISION);
                        output.accept(BROCOLI);
                        output.accept(CORAZON);
                    })
                    .build());

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(CASINO, CasinoEntity.createAttributes());
    }
}
