package com.nutrisafio.dedsafio.mobs;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Base de los mobs con animaciones de GeckoLib (modelos originales de Dedsafio 3).
 * Quieto = animacion "idle", caminando = "walk"/"run", al pegar = una animacion de ataque.
 */
public abstract class MonstruoGeo extends Monster implements GeoEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    protected MonstruoGeo(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    /** Animacion cuando esta quieto. */
    protected abstract String animQuieto();

    /** Animacion cuando camina (puede ser la misma que quieto). */
    protected abstract String animCaminar();

    /** Animaciones de ataque (se elige una al azar al pegar). */
    protected String[] animAtaques() {
        return new String[0];
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean ok = super.doHurtTarget(target);
        String[] ataques = animAtaques();
        if (ok && ataques.length > 0 && !this.level().isClientSide) {
            this.triggerAnim("ataque", ataques[this.random.nextInt(ataques.length)]);
        }
        return ok;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        RawAnimation quieto = RawAnimation.begin().thenLoop(animQuieto());
        RawAnimation caminar = RawAnimation.begin().thenLoop(animCaminar());
        controllers.add(new AnimationController<>(this, "base", 4,
                state -> state.setAndContinue(state.isMoving() ? caminar : quieto)));
        AnimationController<MonstruoGeo> ataque = new AnimationController<>(this, "ataque", 0, state -> PlayState.STOP);
        for (String a : animAtaques()) ataque.triggerableAnim(a, RawAnimation.begin().thenPlay(a));
        controllers.add(ataque);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
