package com.nutrisafio.dedsafio;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.UUID;

/**
 * El Casino (del mod Dedsafio 3). Dale clic derecho con una Dedita Casino:
 * baja la palanca, giran las 3 ruedas y, si salen 3 dibujos iguales, te da ese premio.
 */
public class CasinoEntity extends PathfinderMob implements GeoEntity {

    // Animaciones que ya trae el modelo original (con su duracion en segundos)
    private static final String[] PERDER = {"1", "3", "4", "5", "6", "7"};
    private static final String[] TODAS = {"1", "3", "4", "5", "6", "7",
            "dedita", "nutria", "eon", "brocoli", "corazon", "oro", "poción", "pluma"};

    private static double duracion(String anim) {
        return switch (anim) {
            case "1" -> 16.0;
            case "3" -> 13.55;
            case "6" -> 9.96;
            case "eon" -> 9.375;
            case "dedita", "nutria", "pluma" -> 11.0;
            case "brocoli" -> 11.75;
            case "poción" -> 10.0;
            default -> 12.0; // 4, 5, 7, corazon, oro
        };
    }

    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private int girando = 0;          // ticks que faltan para que paren las ruedas
    private String premio = null;     // "perder" o el nombre del dibujo
    private UUID jugador = null;      // quien metio la ficha

    public CasinoEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 16.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 6.0f));
    }

    // ---------------- No se mueve, no se empuja, no se rompe por accidente ----------------

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void doPush(net.minecraft.world.entity.Entity entity) {
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // Solo un jugador en creativo (o /kill) puede quitarlo
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                || (source.getEntity() instanceof Player p && p.getAbilities().instabuild)) {
            return super.hurt(source, amount);
        }
        return false;
    }

    // ---------------- Jugar ----------------

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack ficha = player.getItemInHand(hand);
        if (!ficha.is(DedsafioNutri.DEDITACASINO)) {
            if (!this.level().isClientSide && hand == InteractionHand.MAIN_HAND) {
                player.displayClientMessage(Component.literal("Necesitas una Dedita Casino para jugar")
                        .withStyle(ChatFormatting.GOLD), true);
            }
            return InteractionResult.PASS;
        }
        if (this.level().isClientSide) return InteractionResult.SUCCESS;
        if (girando > 0) {
            player.displayClientMessage(Component.literal("¡La máquina ya está girando!")
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) ficha.shrink(1);

        premio = sortear();
        String anim = premio.equals("perder") ? PERDER[this.random.nextInt(PERDER.length)] : premio;
        jugador = player.getUUID();
        girando = (int) Math.ceil(duracion(anim) * 20) + 4;

        this.triggerAnim("ruedas", anim);
        this.level().playSound(null, this.blockPosition(), SoundEvents.LEVER_CLICK, SoundSource.NEUTRAL, 1.0f, 0.8f);
        this.level().playSound(null, this.blockPosition(), SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.NEUTRAL, 1.0f, 1.2f);
        player.displayClientMessage(Component.literal("🎰 ¡Girando...!").withStyle(ChatFormatting.YELLOW), true);
        return InteractionResult.CONSUME;
    }

    /** Probabilidades de cada resultado (de 1000). */
    private String sortear() {
        int r = this.random.nextInt(1000);
        if (r < 516) return "perder";      // 51,6 %
        if (r < 636) return "dedita";      // 12,0 %
        if (r < 736) return "oro";         // 10,0 %
        if (r < 816) return "brocoli";     //  8,0 %
        if (r < 886) return "corazon";     //  7,0 %
        if (r < 946) return "pluma";       //  6,0 %
        if (r < 996) return "poción";      //  5,0 %  (premio sorpresa)
        if (r < 999) return "nutria";      //  0,3 %
        return "eon";                      //  0,1 %
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && girando > 0) {
            girando--;
            if (girando == 0) entregar();
        }
    }

    private void entregar() {
        Player p = jugador == null ? null : this.level().getPlayerByUUID(jugador);
        String res = premio;
        premio = null;
        jugador = null;
        if (res == null) return;

        if (res.equals("perder")) {
            this.level().playSound(null, this.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.NEUTRAL, 1.0f, 0.8f);
            if (p != null) p.displayClientMessage(Component.literal("Nada esta vez... ¡suerte para la próxima!")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }

        ItemStack regalo;
        String nombre;
        switch (res) {
            case "dedita" -> { regalo = new ItemStack(DedsafioNutri.DEDITA, 2); nombre = "2 Deditas"; }
            case "oro" -> { regalo = new ItemStack(Items.GOLD_BLOCK, 1); nombre = "1 Bloque de Oro"; }
            case "brocoli" -> { regalo = new ItemStack(DedsafioNutri.BROCOLI, 1); nombre = "El Brócoli"; }
            case "corazon" -> { regalo = new ItemStack(Items.NETHERITE_SCRAP, 1); nombre = "1 Fragmento de Netherita"; }
            case "pluma" -> { regalo = libroPluma(); nombre = "Libro de Reparación"; }
            case "poción" -> {
                switch (this.random.nextInt(4)) {
                    case 0 -> { regalo = new ItemStack(Items.OMINOUS_TRIAL_KEY, 1); nombre = "una Llave Ominosa"; }
                    case 1 -> { regalo = new ItemStack(Items.TURTLE_EGG, 1); nombre = "un Huevo de Tortuga"; }
                    case 2 -> { regalo = new ItemStack(Items.ENCHANTED_GOLDEN_APPLE, 1); nombre = "¡una Manzana de Notch!"; }
                    default -> { regalo = new ItemStack(Items.ENDER_PEARL, 4); nombre = "4 Perlas de Ender"; }
                }
            }
            case "nutria" -> { regalo = new ItemStack(deOtroMod("dedsafio4:totem_nutria", Items.TOTEM_OF_UNDYING)); nombre = "¡un NUTRITÓTEM!"; }
            case "eon" -> { regalo = new ItemStack(deOtroMod("dedsafio4:totem_eon", Items.TOTEM_OF_UNDYING)); nombre = "¡un TÓTEM EÓN!"; }
            default -> { return; }
        }

        if (p != null && p.isAlive() && p.distanceTo(this) < 16 && p.getInventory().add(regalo.copy())) {
            // entregado al inventario
        } else {
            ItemEntity drop = new ItemEntity(this.level(), this.getX(), this.getY() + 1.0, this.getZ(), regalo);
            this.level().addFreshEntity(drop);
        }

        this.level().playSound(null, this.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, 1.0f, 1.0f);
        boolean grande = res.equals("nutria") || res.equals("eon");
        if (p != null) {
            p.displayClientMessage(Component.literal("¡GANASTE " + nombre + "!").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
            if (grande && p instanceof ServerPlayer sp && sp.getServer() != null) {
                sp.getServer().getPlayerList().broadcastSystemMessage(Component.literal("🎰 ")
                        .append(p.getDisplayName())
                        .append(Component.literal(" ganó el PREMIO MAYOR del Casino: " + nombre).withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD)), false);
                this.level().playSound(null, this.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.NEUTRAL, 1.0f, 1.0f);
            }
        }
    }

    private static Item deOtroMod(String id, Item siNoExiste) {
        return BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(id)).orElse(siNoExiste);
    }

    private ItemStack libroPluma() {
        Holder<Enchantment> pluma = this.level().registryAccess().registryOrThrow(Registries.ENCHANTMENT)
                .getHolderOrThrow(Enchantments.MENDING);   // antes: Caida de Pluma IV
        return EnchantedBookItem.createForEnchantment(new EnchantmentInstance(pluma, 1));
    }

    private ItemStack pocion() {
        @SuppressWarnings("unchecked")
        Holder<Potion>[] buenas = new Holder[]{Potions.STRONG_REGENERATION, Potions.STRONG_STRENGTH,
                Potions.STRONG_SWIFTNESS, Potions.LONG_FIRE_RESISTANCE, Potions.STRONG_HEALING};
        return PotionContents.createItemStack(Items.POTION, buenas[this.random.nextInt(buenas.length)]);
    }

    // ---------------- Guardar (por si se apaga el servidor mientras gira) ----------------

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (girando > 0 && premio != null) {
            tag.putInt("Girando", girando);
            tag.putString("Premio", premio);
            if (jugador != null) tag.putUUID("Jugador", jugador);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Premio")) {
            girando = Math.max(1, tag.getInt("Girando"));
            premio = tag.getString("Premio");
            if (tag.hasUUID("Jugador")) jugador = tag.getUUID("Jugador");
        }
    }

    // ---------------- Animaciones (GeckoLib) ----------------

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "base", 5, state -> state.setAndContinue(IDLE)));
        AnimationController<CasinoEntity> ruedas = new AnimationController<>(this, "ruedas", 0, state -> PlayState.STOP);
        for (String a : TODAS) {
            // "PlayAndHold": las ruedas se quedan mostrando el resultado
            ruedas.triggerableAnim(a, RawAnimation.begin().thenPlayAndHold(a));
        }
        controllers.add(ruedas);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
