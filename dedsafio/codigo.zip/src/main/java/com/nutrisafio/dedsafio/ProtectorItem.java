package com.nutrisafio.dedsafio;

import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Supplier;

/**
 * Protector Solar / Repelente anti-bombas (como en Dedsafio 3): dan su efecto por 30 minutos.
 * paraOtros = true: se le pone a OTRO jugador o mob (clic derecho sobre el).
 * paraOtros = false: te lo pones tu mismo (clic derecho al aire).
 */
public class ProtectorItem extends Item {
    private final Supplier<Holder<MobEffect>> efecto;
    private final boolean paraOtros;

    public ProtectorItem(Properties properties, Supplier<Holder<MobEffect>> efecto, boolean paraOtros) {
        super(properties);
        this.efecto = efecto;
        this.paraOtros = paraOtros;
    }

    private void aplicar(LivingEntity e, Player quien, ItemStack stack) {
        e.addEffect(new MobEffectInstance(efecto.get(), 36000, 0));
        e.level().playSound(null, e.blockPosition(), SoundEvents.HONEY_DRINK, SoundSource.PLAYERS, 0.8f, 1.2f);
        if (!quien.getAbilities().instabuild) stack.shrink(1);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (paraOtros) return InteractionResultHolder.pass(stack);
        if (!level.isClientSide) aplicar(player, player, stack);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (!paraOtros) return InteractionResult.PASS;
        if (!player.level().isClientSide) aplicar(target, player, stack);
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal(paraOtros ? "§7Clic derecho a otro jugador para ponérselo." : "§7Puedes colocártelo a ti mismo."));
        tooltip.add(Component.literal("§7Dura 30 minutos."));
    }
}
