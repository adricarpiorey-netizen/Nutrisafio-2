package com.nutrisafio.dedsafio;

import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.ShulkerBoxBlock;

/** Saco de Shulker: una mochila de 27 espacios. Clic derecho para abrirla. */
public class SacoItem extends Item {

    public SacoItem(Properties properties) {
        super(properties);
    }

    static boolean permitido(ItemStack s) {
        return !(s.getItem() instanceof SacoItem)
                && !(s.getItem() instanceof BlockItem b && b.getBlock() instanceof ShulkerBoxBlock);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack saco = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int bloqueado = hand == InteractionHand.MAIN_HAND ? 54 + player.getInventory().selected : -1;
            int teclaBloqueada = hand == InteractionHand.MAIN_HAND ? player.getInventory().selected : 40;
            player.openMenu(new SimpleMenuProvider(
                    (id, inv, p) -> new Menu(id, inv, saco, hand, bloqueado, teclaBloqueada),
                    saco.getHoverName()));
            level.playSound(null, player.blockPosition(), SoundEvents.SHULKER_BOX_OPEN, SoundSource.PLAYERS, 0.6f, 1.0f);
        }
        return InteractionResultHolder.sidedSuccess(saco, level.isClientSide);
    }

    /** Inventario del saco: igual que un cofre de 3 filas, pero guarda todo dentro del objeto. */
    public static class Menu extends AbstractContainerMenu {
        private final SimpleContainer cont = new SimpleContainer(27);
        private final ItemStack saco;
        private final InteractionHand mano;
        private final int bloqueado, teclaBloqueada;

        Menu(int id, Inventory inv, ItemStack saco, InteractionHand mano, int bloqueado, int teclaBloqueada) {
            super(MenuType.GENERIC_9x3, id);
            this.saco = saco;
            this.mano = mano;
            this.bloqueado = bloqueado;
            this.teclaBloqueada = teclaBloqueada;
            NonNullList<ItemStack> lista = NonNullList.withSize(27, ItemStack.EMPTY);
            saco.getOrDefault(DataComponents.CONTAINER, ItemContainerContents.EMPTY).copyInto(lista);
            for (int i = 0; i < 27; i++) cont.setItem(i, lista.get(i));
            cont.addListener(c -> guardar());
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 9; c++)
                    this.addSlot(new Slot(cont, c + r * 9, 8 + c * 18, 18 + r * 18) {
                        @Override public boolean mayPlace(ItemStack s) { return permitido(s); }
                    });
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 9; c++)
                    this.addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 85 + r * 18));
            for (int c = 0; c < 9; c++)
                this.addSlot(new Slot(inv, c, 8 + c * 18, 143));
        }

        private void guardar() {
            NonNullList<ItemStack> lista = NonNullList.withSize(27, ItemStack.EMPTY);
            for (int i = 0; i < 27; i++) lista.set(i, cont.getItem(i).copy());
            saco.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(lista));
        }

        @Override
        public void clicked(int slotId, int button, ClickType type, Player player) {
            // No dejar mover el propio saco mientras esta abierto (evita duplicar cosas)
            if (slotId == bloqueado) return;
            if (type == ClickType.SWAP && button == teclaBloqueada) return;
            super.clicked(slotId, button, type, player);
        }

        @Override
        public ItemStack quickMoveStack(Player player, int index) {
            if (index == bloqueado) return ItemStack.EMPTY;
            Slot slot = this.slots.get(index);
            if (!slot.hasItem()) return ItemStack.EMPTY;
            ItemStack s = slot.getItem();
            ItemStack copia = s.copy();
            if (index < 27) {
                if (!this.moveItemStackTo(s, 27, 63, true)) return ItemStack.EMPTY;
            } else {
                if (!permitido(s) || !this.moveItemStackTo(s, 0, 27, false)) return ItemStack.EMPTY;
            }
            if (s.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
            return copia;
        }

        @Override
        public boolean stillValid(Player player) {
            return player.getItemInHand(mano) == saco;
        }

        @Override
        public void removed(Player player) {
            super.removed(player);
            guardar();
            player.level().playSound(null, player.blockPosition(), SoundEvents.SHULKER_BOX_CLOSE, SoundSource.PLAYERS, 0.6f, 1.0f);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, java.util.List<Component> tooltip, net.minecraft.world.item.TooltipFlag flag) {
        tooltip.add(Component.literal("§7Clic derecho para abrir"));
    }
}
