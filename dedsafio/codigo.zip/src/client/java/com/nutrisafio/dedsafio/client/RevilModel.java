package com.nutrisafio.dedsafio.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo traducido automaticamente del mod Dedsafio 3 (MCreator). */
public class RevilModel<T extends Entity> extends EntityModel<T> {
    public final ModelPart Cuerno;
    public final ModelPart Cuerno2;
    public final ModelPart bone2;
    public final ModelPart bone3;
    public final ModelPart bone;

    public RevilModel(ModelPart root) {
        this.Cuerno = root.getChild("Cuerno");
        this.Cuerno2 = root.getChild("Cuerno2");
        this.bone2 = root.getChild("bone2");
        this.bone3 = root.getChild("bone3");
        this.bone = root.getChild("bone");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p1 = mesh.getRoot();
        PartDefinition p2 = p1.addOrReplaceChild("Cuerno", CubeListBuilder.create(), PartPose.offsetAndRotation(2.0928F, -42.099F, 4.5F, 0.0044F, -0.005F, -0.218F));
        PartDefinition p3 = p2.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(82, 208).addBox(-49.4122F, 16.357F, 0.2942F, 2.0F, 7.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, -0.1265F, 0.0338F, 0.0851F));
        PartDefinition p4 = p2.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(130, 65).addBox(-54.3645F, 12.9338F, -1.857F, 6.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, -0.1304F, 0.0114F, -0.088F));
        PartDefinition p5 = p2.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(198, 141).addBox(-50.7775F, -20.6877F, -3.5F, 7.0F, 5.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, -0.5672F));
        PartDefinition p6 = p2.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(46, 188).addBox(-43.1039F, -28.513F, -5.75F, 9.0F, 9.0F, 11.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, -0.6981F));
        PartDefinition p7 = p2.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(0, 187).addBox(-30.6334F, -40.1827F, -6.25F, 11.0F, 14.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, -0.9599F));
        PartDefinition p8 = p2.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(152, 34).addBox(-15.0772F, -44.3678F, -7.25F, 16.0F, 27.0F, 14.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, -0.6109F));
        PartDefinition p9 = p2.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(152, 0).addBox(-19.7503F, -44.955F, -6.75F, 24.0F, 21.0F, 13.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, -1.0472F));
        PartDefinition p10 = p2.addOrReplaceChild("cube_r8", CubeListBuilder.create().texOffs(72, 155).addBox(-30.4507F, -32.7732F, -7.75F, 13.0F, 18.0F, 15.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, 0.1745F));
        PartDefinition p11 = p2.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(0, 150).addBox(-31.3809F, -20.2703F, -8.75F, 19.0F, 20.0F, 17.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, 0.6981F));
        PartDefinition p12 = p1.addOrReplaceChild("Cuerno2", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.0928F, -42.099F, 4.5F, 0.0044F, 0.005F, 0.218F));
        PartDefinition p13 = p12.addOrReplaceChild("cube_r10", CubeListBuilder.create().texOffs(82, 208).mirror().addBox(47.4122F, 16.357F, 0.2942F, 2.0F, 7.0F, 0.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, -0.1265F, -0.0338F, -0.0851F));
        PartDefinition p14 = p12.addOrReplaceChild("cube_r11", CubeListBuilder.create().texOffs(130, 65).mirror().addBox(48.3645F, 12.9338F, -1.857F, 6.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, -0.1304F, -0.0114F, 0.088F));
        PartDefinition p15 = p12.addOrReplaceChild("cube_r12", CubeListBuilder.create().texOffs(198, 141).mirror().addBox(43.7775F, -20.6877F, -3.5F, 7.0F, 5.0F, 6.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, 0.5672F));
        PartDefinition p16 = p12.addOrReplaceChild("cube_r13", CubeListBuilder.create().texOffs(46, 188).mirror().addBox(34.1039F, -28.513F, -5.75F, 9.0F, 9.0F, 11.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, 0.6981F));
        PartDefinition p17 = p12.addOrReplaceChild("cube_r14", CubeListBuilder.create().texOffs(0, 187).mirror().addBox(19.6334F, -40.1827F, -6.25F, 11.0F, 14.0F, 12.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, 0.9599F));
        PartDefinition p18 = p12.addOrReplaceChild("cube_r15", CubeListBuilder.create().texOffs(152, 34).mirror().addBox(-0.9228F, -44.3678F, -7.25F, 16.0F, 27.0F, 14.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, 0.6109F));
        PartDefinition p19 = p12.addOrReplaceChild("cube_r16", CubeListBuilder.create().texOffs(152, 0).mirror().addBox(-4.2497F, -44.955F, -6.75F, 24.0F, 21.0F, 13.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, 1.0472F));
        PartDefinition p20 = p12.addOrReplaceChild("cube_r17", CubeListBuilder.create().texOffs(72, 155).mirror().addBox(17.4507F, -32.7732F, -7.75F, 13.0F, 18.0F, 15.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, -0.1745F));
        PartDefinition p21 = p12.addOrReplaceChild("cube_r18", CubeListBuilder.create().texOffs(0, 150).mirror().addBox(12.3809F, -20.2703F, -8.75F, 19.0F, 20.0F, 17.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(2.0928F, 14.099F, 0.5F, 0.0F, 0.0F, -0.6981F));
        PartDefinition p22 = p1.addOrReplaceChild("bone2", CubeListBuilder.create(), PartPose.offset(-25.5F, 22.5F, -17.0F));
        PartDefinition p23 = p22.addOrReplaceChild("cube_r19", CubeListBuilder.create().texOffs(178, 208).addBox(-35.8751F, 43.4899F, -22.3F, 5.0F, 9.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(25.5F, -50.5F, 22.0F, 0.0F, 0.0F, -0.0436F));
        PartDefinition p24 = p22.addOrReplaceChild("cube_r20", CubeListBuilder.create().texOffs(112, 208).addBox(-38.2231F, 23.8707F, -18.2523F, 5.0F, 13.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(25.5F, -50.5F, 22.0F, -0.0865F, -0.0114F, -0.4358F));
        PartDefinition p25 = p22.addOrReplaceChild("cube_r21", CubeListBuilder.create().texOffs(188, 155).addBox(-49.0649F, 29.6092F, -9.901F, 6.0F, 6.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(25.5F, -50.5F, 22.0F, -0.2F, -0.2324F, -0.4129F));
        PartDefinition p26 = p22.addOrReplaceChild("cube_r22", CubeListBuilder.create().texOffs(188, 155).addBox(30.7223F, 44.2824F, -9.6786F, 6.0F, 6.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(25.5F, -50.5F, 22.0F, -0.2099F, 0.2236F, 1.2417F));
        PartDefinition p27 = p22.addOrReplaceChild("cube_r23", CubeListBuilder.create().texOffs(86, 188).addBox(-11.1147F, 37.6734F, -9.0867F, 6.0F, 19.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(178, 180).addBox(-14.1336F, 22.8014F, -11.1011F, 12.0F, 16.0F, 12.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(25.5F, -50.5F, 22.0F, -0.3054F, 0.0F, 0.4363F));
        PartDefinition p28 = p1.addOrReplaceChild("bone3", CubeListBuilder.create(), PartPose.offset(24.5F, 20.5F, -17.0F));
        PartDefinition p29 = p28.addOrReplaceChild("cube_r24", CubeListBuilder.create().texOffs(178, 208).mirror().addBox(29.0875F, 42.6671F, -22.0F, 5.0F, 9.0F, 0.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-24.5F, -48.5F, 22.0F, 0.0F, 0.0F, 0.0436F));
        PartDefinition p30 = p28.addOrReplaceChild("cube_r25", CubeListBuilder.create().texOffs(112, 208).mirror().addBox(32.8398F, 23.0324F, -18.0283F, 5.0F, 13.0F, 0.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-24.5F, -48.5F, 22.0F, -0.0865F, 0.0114F, 0.4358F));
        PartDefinition p31 = p28.addOrReplaceChild("cube_r26", CubeListBuilder.create().texOffs(188, 155).mirror().addBox(42.6443F, 28.7598F, -9.8602F, 6.0F, 6.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-24.5F, -48.5F, 22.0F, -0.2F, 0.2324F, 0.4129F));
        PartDefinition p32 = p28.addOrReplaceChild("cube_r27", CubeListBuilder.create().texOffs(188, 155).mirror().addBox(-35.8252F, 43.9764F, -9.6378F, 6.0F, 6.0F, 8.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-24.5F, -48.5F, 22.0F, -0.2099F, -0.2236F, -1.2417F));
        PartDefinition p33 = p28.addOrReplaceChild("cube_r28", CubeListBuilder.create().texOffs(86, 188).mirror().addBox(5.4951F, 36.8053F, -9.0458F, 6.0F, 19.0F, 7.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(128, 180).addBox(2.0725F, 20.6696F, -11.7733F, 12.0F, 16.0F, 13.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-24.5F, -48.5F, 22.0F, -0.3054F, 0.0F, -0.4363F));
        PartDefinition p34 = p1.addOrReplaceChild("bone", CubeListBuilder.create().texOffs(0, 0).addBox(-47.5F, -67.5F, 4.0F, 47.0F, 36.0F, 29.0F, new CubeDeformation(0.0F)).texOffs(198, 121).addBox(-27.25F, -48.5F, 1.75F, 7.0F, 17.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(112, 188).mirror().addBox(-6.0F, -53.75F, 2.5F, 6.0F, 18.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(112, 188).addBox(-47.75F, -53.75F, 2.5F, 6.0F, 18.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 92).addBox(-42.5F, -39.5F, 6.0F, 38.0F, 5.0F, 25.0F, new CubeDeformation(0.0F)).texOffs(0, 65).addBox(-46.5F, -74.5F, 8.0F, 45.0F, 7.0F, 20.0F, new CubeDeformation(0.0F)).texOffs(0, 122).addBox(-40.5F, -75.5F, 8.2F, 33.0F, 8.0F, 20.0F, new CubeDeformation(0.0F)), PartPose.offset(22.5F, 20.5F, -14.0F));
        PartDefinition p35 = p34.addOrReplaceChild("cube_r29", CubeListBuilder.create().texOffs(72, 150).mirror().addBox(-0.4054F, -1.0517F, -16.05F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(204, 75).addBox(-17.979F, -4.0582F, -16.0F, 12.0F, 11.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(188, 169).mirror().addBox(2.4652F, -1.5688F, -17.05F, 14.0F, 4.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, 0.0F, 0.0F, -0.2618F));
        PartDefinition p36 = p34.addOrReplaceChild("cube_r30", CubeListBuilder.create().texOffs(72, 150).addBox(-10.4924F, -0.2753F, -16.05F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(188, 169).addBox(-19.3629F, -0.7923F, -17.05F, 14.0F, 4.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(204, 75).mirror().addBox(4.0472F, -3.5405F, -16.0F, 12.0F, 11.0F, 0.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, 0.0F, 0.0F, 0.2618F));
        PartDefinition p37 = p34.addOrReplaceChild("cube_r31", CubeListBuilder.create().texOffs(130, 75).addBox(-18.0F, -20.4119F, 15.7115F, 33.0F, 10.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, 0.4363F, 0.0F, 0.0F));
        PartDefinition p38 = p34.addOrReplaceChild("cube_r32", CubeListBuilder.create().texOffs(130, 75).addBox(-18.0F, -19.778F, -21.0709F, 33.0F, 10.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, -0.4363F, 0.0F, 0.0F));
        PartDefinition p39 = p34.addOrReplaceChild("cube_r33", CubeListBuilder.create().texOffs(64, 208).mirror().addBox(4.55F, 33.4656F, -11.0135F, 5.0F, 11.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(46, 208).mirror().addBox(-1.2F, 33.4656F, -11.0135F, 5.0F, 14.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(64, 208).addBox(-12.0F, 33.4656F, -11.0135F, 5.0F, 11.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(46, 208).addBox(-6.6F, 33.4656F, -11.0135F, 5.0F, 14.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(128, 155).addBox(-12.25F, 17.5842F, -14.0957F, 22.0F, 17.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, -0.2182F, 0.0F, 0.0F));
        PartDefinition p40 = p34.addOrReplaceChild("cube_r34", CubeListBuilder.create().texOffs(126, 92).addBox(-13.5F, 12.0035F, -19.183F, 24.0F, 9.0F, 20.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, 0.5236F, 0.0F, 0.0F));
        PartDefinition p41 = p34.addOrReplaceChild("cube_r35", CubeListBuilder.create().texOffs(106, 122).mirror().addBox(-0.7591F, 11.4219F, -17.0F, 17.0F, 4.0F, 29.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, 0.0F, 0.0F, 0.0873F));
        PartDefinition p42 = p34.addOrReplaceChild("cube_r36", CubeListBuilder.create().texOffs(106, 122).addBox(-19.2295F, 11.1604F, -17.0F, 17.0F, 4.0F, 29.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-22.5F, -48.5F, 19.0F, 0.0F, 0.0F, -0.0873F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay, int color) {
        Cuerno.render(poseStack, buffer, light, overlay, color);
        Cuerno2.render(poseStack, buffer, light, overlay, color);
        bone2.render(poseStack, buffer, light, overlay, color);
        bone3.render(poseStack, buffer, light, overlay, color);
        bone.render(poseStack, buffer, light, overlay, color);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        // El modelo original no tiene animacion
    }
}
