package com.nutrisafio.dedsafio.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/** Modelo traducido automaticamente del mod Dedsafio 3 (MCreator). */
public class CreeperPastelModel<T extends Entity> extends EntityModel<T> {
    public final ModelPart Head;
    public final ModelPart Fueguito;
    public final ModelPart Vela;
    public final ModelPart body;
    public final ModelPart leg1;
    public final ModelPart leg2;
    public final ModelPart leg3;
    public final ModelPart leg4;

    public CreeperPastelModel(ModelPart root) {
        this.Head = root.getChild("Head");
        this.Fueguito = root.getChild("Head").getChild("Fueguito");
        this.Vela = root.getChild("Head").getChild("Vela");
        this.body = root.getChild("body");
        this.leg1 = root.getChild("leg1");
        this.leg2 = root.getChild("leg2");
        this.leg3 = root.getChild("leg3");
        this.leg4 = root.getChild("leg4");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p1 = mesh.getRoot();
        PartDefinition p2 = p1.addOrReplaceChild("Head", CubeListBuilder.create(), PartPose.offset(0.0F, 5.0F, 0.0F));
        PartDefinition p3 = p2.addOrReplaceChild("head_r1", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -26.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 19.0F, 0.0F, 0.0F, 3.1416F, 0.0F));
        PartDefinition p4 = p2.addOrReplaceChild("Fueguito", CubeListBuilder.create().texOffs(16, 36).addBox(0.0F, -1.5F, -1.0F, 0.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, -12.5F, 0.0F));
        PartDefinition p5 = p4.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(16, 36).addBox(0.0F, -1.5F, -1.0F, 0.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, -1.5708F, 0.0F));
        PartDefinition p6 = p2.addOrReplaceChild("Vela", CubeListBuilder.create().texOffs(32, 10).addBox(-1.0F, -30.0F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 19.0F, 0.0F));
        PartDefinition p7 = p1.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 6.0F, 0.0F));
        PartDefinition p8 = p1.addOrReplaceChild("leg1", CubeListBuilder.create().texOffs(24, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-2.0F, 18.0F, 4.0F));
        PartDefinition p9 = p1.addOrReplaceChild("leg2", CubeListBuilder.create().texOffs(24, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(2.0F, 18.0F, 4.0F));
        PartDefinition p10 = p1.addOrReplaceChild("leg3", CubeListBuilder.create().texOffs(24, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-2.0F, 18.0F, -4.0F));
        PartDefinition p11 = p1.addOrReplaceChild("leg4", CubeListBuilder.create().texOffs(24, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(2.0F, 18.0F, -4.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int light, int overlay, int color) {
        Head.render(poseStack, buffer, light, overlay, color);
        body.render(poseStack, buffer, light, overlay, color);
        leg1.render(poseStack, buffer, light, overlay, color);
        leg2.render(poseStack, buffer, light, overlay, color);
        leg3.render(poseStack, buffer, light, overlay, color);
        leg4.render(poseStack, buffer, light, overlay, color);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        // Patas igual que en el original
        this.leg1.xRot = Mth.cos(limbSwing) * -1.0F * limbSwingAmount;
        this.leg4.xRot = Mth.cos(limbSwing) * -1.0F * limbSwingAmount;
        this.leg2.xRot = Mth.cos(limbSwing) * 1.0F * limbSwingAmount;
        this.leg3.xRot = Mth.cos(limbSwing) * 1.0F * limbSwingAmount;
        this.Head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
    }
}
