package com.nutrisafio.dedsafio.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.nutrisafio.dedsafio.CasinoEntity;
import com.nutrisafio.dedsafio.DedsafioNutri;
import com.nutrisafio.dedsafio.mobs.CreeperPastel;
import com.nutrisafio.dedsafio.mobs.Revil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class DedsafioNutriClient implements ClientModInitializer {

    /** Modelo GeckoLib generico: geo/NOMBRE.geo.json, animations/NOMBRE.animation.json, textures/entity/NOMBRE.png */
    public static class ModeloGeo<T extends GeoAnimatable> extends GeoModel<T> {
        private final ResourceLocation geo, tex, anim;

        public ModeloGeo(String nombre) {
            this.geo = DedsafioNutri.id("geo/" + nombre + ".geo.json");
            this.tex = DedsafioNutri.id("textures/entity/" + nombre + ".png");
            this.anim = DedsafioNutri.id("animations/" + nombre + ".animation.json");
        }

        @Override public ResourceLocation getModelResource(T animatable) { return geo; }
        @Override public ResourceLocation getTextureResource(T animatable) { return tex; }
        @Override public ResourceLocation getAnimationResource(T animatable) { return anim; }
    }

    private static <T extends Entity & GeoAnimatable> void geo(EntityType<T> type, String nombre, float escala, float sombra) {
        EntityRendererRegistry.register(type, ctx -> {
            GeoEntityRenderer<T> r = new GeoEntityRenderer<>(ctx, new ModeloGeo<T>(nombre)) {
                { this.shadowRadius = sombra; }
            };
            if (escala != 1.0f) r.withScale(escala);
            return r;
        });
    }

    public static final ModelLayerLocation CAPA_REVIL = new ModelLayerLocation(DedsafioNutri.id("revil"), "main");
    public static final ModelLayerLocation CAPA_CREEPER_PASTEL = new ModelLayerLocation(DedsafioNutri.id("creeper_pastel"), "main");

    public static class RevilRenderer extends MobRenderer<Revil, RevilModel<Revil>> {
        private static final ResourceLocation TEX = DedsafioNutri.id("textures/entity/revil.png");
        public RevilRenderer(EntityRendererProvider.Context ctx) { super(ctx, new RevilModel<>(ctx.bakeLayer(CAPA_REVIL)), 0.5f); }
        @Override public ResourceLocation getTextureLocation(Revil e) { return TEX; }
    }

    public static class CreeperPastelRenderer extends MobRenderer<CreeperPastel, CreeperPastelModel<CreeperPastel>> {
        private static final ResourceLocation TEX = DedsafioNutri.id("textures/entity/creeper_pastel.png");
        public CreeperPastelRenderer(EntityRendererProvider.Context ctx) { super(ctx, new CreeperPastelModel<>(ctx.bakeLayer(CAPA_CREEPER_PASTEL)), 0.5f); }
        @Override public ResourceLocation getTextureLocation(CreeperPastel e) { return TEX; }
    }

    private static final ResourceLocation PASTEL = DedsafioNutri.id("textures/gui/tortazo.png");

    @Override
    public void onInitializeClient() {
        // Animacion con la imagen del Totem Eon cuando se usa desde el inventario
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.registerGlobalReceiver(
                com.nutrisafio.dedsafio.TotemEon.PopPayload.TYPE, (payload, context) -> {
                    net.minecraft.world.item.Item eon = net.minecraft.core.registries.BuiltInRegistries.ITEM
                            .getOptional(ResourceLocation.parse(com.nutrisafio.dedsafio.TotemEon.ID_EON))
                            .orElse(net.minecraft.world.item.Items.TOTEM_OF_UNDYING);
                    context.client().gameRenderer.displayItemActivation(new net.minecraft.world.item.ItemStack(eon));
                });

        EntityRendererRegistry.register(DedsafioNutri.CASINO, ctx -> new GeoEntityRenderer<CasinoEntity>(ctx, new ModeloGeo<>("casino")));
        geo(DedsafioNutri.INFERNAL_BULL, "infernal_bull", 1.0f, 1.55f);
        geo(DedsafioNutri.RANA, "rana", 1.0f, 0.4f);
        geo(DedsafioNutri.RANA_GIGANTE, "rana_gigante", 1.0f, 0.5f);
        geo(DedsafioNutri.REVIIL, "reviil", 1.0f, 0.5f);
        geo(DedsafioNutri.TIKI_GUARDIAN, "tiki_guardian", 2.0f, 3.0f);
        geo(DedsafioNutri.FLASHBANG, "flashbang", 0.7f, 0.5f);

        EntityModelLayerRegistry.registerModelLayer(CAPA_REVIL, RevilModel::createBodyLayer);
        EntityModelLayerRegistry.registerModelLayer(CAPA_CREEPER_PASTEL, CreeperPastelModel::createBodyLayer);
        EntityRendererRegistry.register(DedsafioNutri.REVIL, RevilRenderer::new);
        EntityRendererRegistry.register(DedsafioNutri.CREEPER_PASTEL, CreeperPastelRenderer::new);

        // Pantalla en blanco del Flashbang y pastel en la cara del Creeper Pastel
        HudRenderCallback.EVENT.register((g, tick) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            int w = g.guiWidth(), h = g.guiHeight();
            MobEffectInstance flash = mc.player.getEffect(DedsafioNutri.FLASHBANG_EFECTO);
            if (flash != null) {
                float a = Math.min(1.0f, flash.getDuration() / 40.0f);
                g.fill(0, 0, w, h, ((int) (a * 255) << 24) | 0xFFFFFF);
            }
            MobEffectInstance pastel = mc.player.getEffect(DedsafioNutri.TORTAZO);
            if (pastel != null) {
                float a = Math.min(1.0f, pastel.getDuration() / 20.0f);
                RenderSystem.enableBlend();
                RenderSystem.setShaderColor(1f, 1f, 1f, a);
                int lado = Math.max(w, h);
                g.blit(PASTEL, (w - lado) / 2, (h - lado) / 2, 0.0f, 0.0f, lado, lado, lado, lado);
                RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                RenderSystem.disableBlend();
            }
        });
    }
}
