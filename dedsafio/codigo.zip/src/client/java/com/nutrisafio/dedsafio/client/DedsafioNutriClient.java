package com.nutrisafio.dedsafio.client;

import com.nutrisafio.dedsafio.CasinoEntity;
import com.nutrisafio.dedsafio.DedsafioNutri;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class DedsafioNutriClient implements ClientModInitializer {

    /** Modelo, textura y animaciones originales del Casino (Dedsafio 3). */
    public static class CasinoModel extends GeoModel<CasinoEntity> {
        @Override
        public ResourceLocation getModelResource(CasinoEntity animatable) {
            return DedsafioNutri.id("geo/casino.geo.json");
        }

        @Override
        public ResourceLocation getTextureResource(CasinoEntity animatable) {
            return DedsafioNutri.id("textures/entity/casino.png");
        }

        @Override
        public ResourceLocation getAnimationResource(CasinoEntity animatable) {
            return DedsafioNutri.id("animations/casino.animation.json");
        }
    }

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(DedsafioNutri.CASINO, ctx -> new GeoEntityRenderer<>(ctx, new CasinoModel()));
    }
}
