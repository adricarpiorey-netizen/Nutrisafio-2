package com.nutrisafio.client;

import com.nutrisafio.ElOjoEntity;
import com.nutrisafio.Nutrisafio;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ElOjoRenderer extends MobRenderer<ElOjoEntity, ElOjoModel> {
    private static final ResourceLocation TEXTURE = Nutrisafio.id("textures/entity/el_ojo.png");

    public ElOjoRenderer(EntityRendererProvider.Context context) {
        super(context, new ElOjoModel(context.bakeLayer(ElOjoModel.LAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(ElOjoEntity entity) {
        return TEXTURE;
    }
}
