package com.nutrisafio.client;

import com.nutrisafio.Nutrisafio;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class NutrisafioClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(ElOjoModel.LAYER, ElOjoModel::createBodyLayer);
        EntityRendererRegistry.register(Nutrisafio.EL_OJO, ElOjoRenderer::new);
    }
}
