package com.nutrisafio.client;

import com.nutrisafio.ElOjoEntity;
import com.nutrisafio.Nutrisafio;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Modelo de El Ojo, convertido automaticamente desde el modelo CPM "o olho". */
public class ElOjoModel extends HierarchicalModel<ElOjoEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(Nutrisafio.id("el_ojo"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public ElOjoModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition p1 = root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -2.0F, -2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p2 = p1.addOrReplaceChild("head_0", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p3 = p1.addOrReplaceChild("head_1", CubeListBuilder.create().texOffs(40, 17).addBox(-3.0F, -7.0F, -4.2F, 6.0F, 6.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p4 = p1.addOrReplaceChild("head_2", CubeListBuilder.create().texOffs(10, 16).addBox(-2.0F, -6.0F, -4.3F, 4.0F, 4.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p5 = p1.addOrReplaceChild("head_3", CubeListBuilder.create().texOffs(24, 16).addBox(-1.0F, -5.0F, -4.4F, 2.0F, 2.0F, 0.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p6 = p1.addOrReplaceChild("head_4", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p7 = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p8 = p7.addOrReplaceChild("body_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p9 = p8.addOrReplaceChild("body_0_0", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.225F, 2.0F, 2.025F, 0.17453F, 0.0F, 0.0F));
        PartDefinition p10 = p9.addOrReplaceChild("body_0_0_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 7.98478F, -0.34862F, -0.17453F, 0.0F, 0.0F));
        PartDefinition p11 = p10.addOrReplaceChild("body_0_0_0_0", CubeListBuilder.create().texOffs(4, 29).addBox(-0.775F, -1.0F, -1.07638F, 1.5F, 3.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p12 = p10.addOrReplaceChild("body_0_0_0_1", CubeListBuilder.create().texOffs(46, 46).addBox(-1.475F, -2.0F, -1.17638F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p13 = p9.addOrReplaceChild("body_0_0_1", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.17453F, 0.0F, 0.0F));
        PartDefinition p14 = p13.addOrReplaceChild("body_0_0_1_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 11.88036F, -1.29077F, -0.34907F, 0.0F, 0.0F));
        PartDefinition p15 = p14.addOrReplaceChild("body_0_0_1_0_0", CubeListBuilder.create().texOffs(46, 41).addBox(-1.475F, -2.0F, -3.63423F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p16 = p14.addOrReplaceChild("body_0_0_1_0_1", CubeListBuilder.create().texOffs(4, 29).addBox(-0.775F, -1.0F, -3.33423F, 1.5F, 3.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p17 = p9.addOrReplaceChild("body_0_0_2", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 19.47092F, -1.77775F, 0.17453F, 0.0F, 0.0F));
        PartDefinition p18 = p17.addOrReplaceChild("body_0_0_2_0", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.0F, 0.89241F, 2.45187F, -0.34907F, 0.0F, 0.0F));
        PartDefinition p19 = p18.addOrReplaceChild("body_0_0_2_0_0", CubeListBuilder.create().texOffs(46, 29).addBox(-1.475F, -2.0F, -4.19912F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p20 = p18.addOrReplaceChild("body_0_0_2_0_1", CubeListBuilder.create().texOffs(4, 29).addBox(-0.775F, -1.0F, -4.19912F, 1.5F, 3.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p21 = p8.addOrReplaceChild("body_0_1", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.225F, 2.0F, 2.025F, 0.17453F, 0.0F, 0.0F));
        PartDefinition p22 = p21.addOrReplaceChild("body_0_1_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 7.98478F, -0.34862F, -0.17453F, 0.0F, 0.0F));
        PartDefinition p23 = p22.addOrReplaceChild("body_0_1_0_0", CubeListBuilder.create().texOffs(46, 24).addBox(-1.475F, 2.0F, -1.17638F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p24 = p22.addOrReplaceChild("body_0_1_0_1", CubeListBuilder.create().texOffs(4, 29).addBox(-0.775F, 3.0F, -0.87638F, 1.5F, 3.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p25 = p8.addOrReplaceChild("body_0_2", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p26 = p25.addOrReplaceChild("body_0_2_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 25.0F, 1.0F, 0.08727F, 0.0F, 0.0F));
        PartDefinition p27 = p26.addOrReplaceChild("body_0_2_0_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -25.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p28 = p27.addOrReplaceChild("body_0_2_0_0_0", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.2F, 2.06952F, -1.85732F, 0.04363F, 0.0F, 0.0F));
        PartDefinition p29 = p28.addOrReplaceChild("body_0_2_0_0_0_0", CubeListBuilder.create().texOffs(10, 47).addBox(-4.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p30 = p28.addOrReplaceChild("body_0_2_0_0_0_1", CubeListBuilder.create().texOffs(48, 15).addBox(0.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p31 = p28.addOrReplaceChild("body_0_2_0_0_0_2", CubeListBuilder.create().texOffs(30, 8).addBox(4.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p32 = p28.addOrReplaceChild("body_0_2_0_0_0_3", CubeListBuilder.create().texOffs(30, 17).addBox(-5.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p33 = p28.addOrReplaceChild("body_0_2_0_0_0_4", CubeListBuilder.create().texOffs(24, 6).addBox(-5.5F, -1.5F, 3.5F, 11.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p34 = p26.addOrReplaceChild("body_0_2_0_1", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -23.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p35 = p34.addOrReplaceChild("body_0_2_0_1_0", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.2F, 2.06952F, -1.85732F, 0.04363F, 0.0F, 0.0F));
        PartDefinition p36 = p35.addOrReplaceChild("body_0_2_0_1_0_0", CubeListBuilder.create().texOffs(47, 3).addBox(-4.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p37 = p35.addOrReplaceChild("body_0_2_0_1_0_1", CubeListBuilder.create().texOffs(47, 5).addBox(0.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p38 = p35.addOrReplaceChild("body_0_2_0_1_0_2", CubeListBuilder.create().texOffs(20, 25).addBox(4.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p39 = p35.addOrReplaceChild("body_0_2_0_1_0_3", CubeListBuilder.create().texOffs(10, 26).addBox(-5.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p40 = p35.addOrReplaceChild("body_0_2_0_1_0_4", CubeListBuilder.create().texOffs(24, 4).addBox(-5.5F, -1.5F, 3.5F, 11.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p41 = p26.addOrReplaceChild("body_0_2_0_2", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -21.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p42 = p41.addOrReplaceChild("body_0_2_0_2_0", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.2F, 2.06952F, -1.85732F, 0.04363F, 0.0F, 0.0F));
        PartDefinition p43 = p42.addOrReplaceChild("body_0_2_0_2_0_0", CubeListBuilder.create().texOffs(0, 47).addBox(-4.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p44 = p42.addOrReplaceChild("body_0_2_0_2_0_1", CubeListBuilder.create().texOffs(47, 1).addBox(0.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p45 = p42.addOrReplaceChild("body_0_2_0_2_0_2", CubeListBuilder.create().texOffs(20, 16).addBox(4.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p46 = p42.addOrReplaceChild("body_0_2_0_2_0_3", CubeListBuilder.create().texOffs(0, 25).addBox(-5.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p47 = p42.addOrReplaceChild("body_0_2_0_2_0_4", CubeListBuilder.create().texOffs(24, 2).addBox(-5.5F, -1.5F, 3.5F, 11.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p48 = p26.addOrReplaceChild("body_0_2_0_3", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, -19.0F, 2.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p49 = p48.addOrReplaceChild("body_0_2_0_3_0", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.2F, 2.06952F, -1.85732F, 0.04363F, 0.0F, 0.0F));
        PartDefinition p50 = p49.addOrReplaceChild("body_0_2_0_3_0_0", CubeListBuilder.create().texOffs(30, 26).addBox(-4.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p51 = p49.addOrReplaceChild("body_0_2_0_3_0_1", CubeListBuilder.create().texOffs(46, 34).addBox(0.5F, -1.5F, -4.5F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p52 = p49.addOrReplaceChild("body_0_2_0_3_0_2", CubeListBuilder.create().texOffs(0, 16).addBox(4.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p53 = p49.addOrReplaceChild("body_0_2_0_3_0_3", CubeListBuilder.create().texOffs(10, 17).addBox(-5.5F, -1.5F, -4.5F, 1.0F, 1.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p54 = p49.addOrReplaceChild("body_0_2_0_3_0_4", CubeListBuilder.create().texOffs(24, 0).addBox(-5.5F, -1.5F, 3.5F, 11.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p55 = p25.addOrReplaceChild("body_0_2_1", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.225F, 2.0F, 2.025F, 0.17453F, 0.0F, 0.0F));
        PartDefinition p56 = p55.addOrReplaceChild("body_0_2_1_0", CubeListBuilder.create().texOffs(4, 29).addBox(-0.775F, -1.0F, -0.725F, 1.5F, 3.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p57 = p55.addOrReplaceChild("body_0_2_1_1", CubeListBuilder.create().texOffs(40, 8).addBox(-1.475F, -3.0F, -1.025F, 3.0F, 4.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p58 = p25.addOrReplaceChild("body_0_2_2", CubeListBuilder.create(), PartPose.offsetAndRotation(-0.225F, 2.0F, 2.025F, 0.17453F, 0.0F, 0.0F));
        PartDefinition p59 = p58.addOrReplaceChild("body_0_2_2_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, -0.08727F, 0.0F, 0.0F));
        PartDefinition p60 = p59.addOrReplaceChild("body_0_2_2_0_0", CubeListBuilder.create().texOffs(4, 29).addBox(-0.775F, -1.0F, -0.725F, 1.5F, 3.0F, 1.5F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p61 = p59.addOrReplaceChild("body_0_2_2_0_1", CubeListBuilder.create().texOffs(22, 46).addBox(-1.475F, -2.0F, -1.025F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p62 = p7.addOrReplaceChild("body_1", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p63 = p7.addOrReplaceChild("body_2", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p64 = root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.offsetAndRotation(5.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p65 = p64.addOrReplaceChild("left_arm_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p66 = p65.addOrReplaceChild("left_arm_0_0", CubeListBuilder.create().texOffs(38, 26).addBox(2.0F, 1.0F, -1.0F, 2.0F, 10.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p67 = p65.addOrReplaceChild("left_arm_0_1", CubeListBuilder.create().texOffs(20, 16).addBox(4.0F, 1.0F, -1.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p68 = p65.addOrReplaceChild("left_arm_0_2", CubeListBuilder.create().texOffs(20, 21).addBox(3.0F, 1.0F, -2.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p69 = p65.addOrReplaceChild("left_arm_0_3", CubeListBuilder.create().texOffs(0, 25).addBox(4.0F, 9.0F, -1.0F, 1.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p70 = p65.addOrReplaceChild("left_arm_0_4", CubeListBuilder.create().texOffs(0, 43).addBox(1.0F, 10.0F, -2.0F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p71 = p64.addOrReplaceChild("left_arm_1", CubeListBuilder.create().texOffs(38, 40).addBox(2.0F, 11.0F, -1.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p72 = p71.addOrReplaceChild("left_arm_1_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p73 = p72.addOrReplaceChild("left_arm_1_0_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p74 = p73.addOrReplaceChild("left_arm_1_0_0_0", CubeListBuilder.create().texOffs(0, 34).addBox(-0.5F, 0.0F, 2.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(2.5F, 19.0F, -1.5F, 0.0F, 0.0F, 0.56723F));
        PartDefinition p75 = p73.addOrReplaceChild("left_arm_1_0_0_1", CubeListBuilder.create().texOffs(34, 17).addBox(-0.27592F, 0.23121F, 1.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.27592F, 18.76879F, 0.0F, 0.0F, 0.0F, -0.3927F));
        PartDefinition p76 = p72.addOrReplaceChild("left_arm_1_0_1", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p77 = p76.addOrReplaceChild("left_arm_1_0_1_0", CubeListBuilder.create().texOffs(32, 11).addBox(-0.5F, 0.0F, 1.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(2.5F, 19.0F, -1.5F, 0.0F, 0.0F, 0.56723F));
        PartDefinition p78 = p76.addOrReplaceChild("left_arm_1_0_1_1", CubeListBuilder.create().texOffs(33, 30).addBox(-0.27592F, 0.23121F, -0.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.27592F, 18.76879F, 0.0F, 0.0F, 0.0F, -0.3927F));
        PartDefinition p79 = p72.addOrReplaceChild("left_arm_1_0_2", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p80 = p79.addOrReplaceChild("left_arm_1_0_2_0", CubeListBuilder.create().texOffs(30, 28).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(2.5F, 19.0F, -1.5F, 0.0F, 0.0F, 0.56723F));
        PartDefinition p81 = p79.addOrReplaceChild("left_arm_1_0_2_1", CubeListBuilder.create().texOffs(32, 8).addBox(-0.27592F, 0.23121F, -2.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.27592F, 18.76879F, 0.0F, 0.0F, 0.0F, -0.3927F));
        PartDefinition p82 = p64.addOrReplaceChild("left_arm_2", CubeListBuilder.create().texOffs(0, 35).addBox(1.0F, -3.0F, -2.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p83 = p64.addOrReplaceChild("left_arm_3", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p84 = root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.offsetAndRotation(-4.0F, 2.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p85 = p84.addOrReplaceChild("right_arm_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p86 = p85.addOrReplaceChild("right_arm_0_0", CubeListBuilder.create().texOffs(44, 36).addBox(-7.0F, 1.0F, -1.0F, 3.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p87 = p85.addOrReplaceChild("right_arm_0_1", CubeListBuilder.create().texOffs(0, 21).addBox(-7.0F, 1.0F, -2.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p88 = p85.addOrReplaceChild("right_arm_0_2", CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, 4.0F, -1.0F, 2.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p89 = p85.addOrReplaceChild("right_arm_0_3", CubeListBuilder.create().texOffs(24, 42).addBox(-8.0F, 8.0F, -2.0F, 3.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p90 = p85.addOrReplaceChild("right_arm_0_4", CubeListBuilder.create().texOffs(10, 20).addBox(-7.0F, 6.0F, -2.0F, 2.0F, 3.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p91 = p85.addOrReplaceChild("right_arm_0_5", CubeListBuilder.create().texOffs(0, 16).addBox(-6.0F, 6.0F, 0.0F, 2.0F, 3.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p92 = p84.addOrReplaceChild("right_arm_1", CubeListBuilder.create().texOffs(24, 34).addBox(-7.0F, -3.0F, -2.0F, 4.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p93 = p84.addOrReplaceChild("right_arm_2", CubeListBuilder.create().texOffs(16, 35).addBox(-7.0F, 9.0F, -1.0F, 2.0F, 10.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p94 = p84.addOrReplaceChild("right_arm_3", CubeListBuilder.create(), PartPose.offsetAndRotation(-12.0F, 22.0F, 0.0F, 0.0F, 3.14159F, 0.0F));
        PartDefinition p95 = p94.addOrReplaceChild("right_arm_3_0", CubeListBuilder.create(), PartPose.offsetAndRotation(-9.0F, -22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p96 = p95.addOrReplaceChild("right_arm_3_0_0", CubeListBuilder.create().texOffs(30, 20).addBox(-0.5F, 0.0F, 2.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(2.5F, 19.0F, -1.5F, 0.0F, 0.0F, 0.56723F));
        PartDefinition p97 = p95.addOrReplaceChild("right_arm_3_0_1", CubeListBuilder.create().texOffs(24, 30).addBox(-0.27592F, 0.23121F, 1.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.27592F, 18.76879F, 0.0F, 0.0F, 0.0F, -0.3927F));
        PartDefinition p98 = p94.addOrReplaceChild("right_arm_3_1", CubeListBuilder.create(), PartPose.offsetAndRotation(-9.0F, -22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p99 = p98.addOrReplaceChild("right_arm_3_1_0", CubeListBuilder.create().texOffs(30, 17).addBox(-0.5F, 0.0F, 1.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(2.5F, 19.0F, -1.5F, 0.0F, 0.0F, 0.56723F));
        PartDefinition p100 = p98.addOrReplaceChild("right_arm_3_1_1", CubeListBuilder.create().texOffs(20, 30).addBox(-0.27592F, 0.23121F, -0.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.27592F, 18.76879F, 0.0F, 0.0F, 0.0F, -0.3927F));
        PartDefinition p101 = p94.addOrReplaceChild("right_arm_3_2", CubeListBuilder.create(), PartPose.offsetAndRotation(-9.0F, -22.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p102 = p101.addOrReplaceChild("right_arm_3_2_0", CubeListBuilder.create().texOffs(10, 30).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(2.5F, 19.0F, -1.5F, 0.0F, 0.0F, 0.56723F));
        PartDefinition p103 = p101.addOrReplaceChild("right_arm_3_2_1", CubeListBuilder.create().texOffs(14, 30).addBox(-0.27592F, 0.23121F, -2.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.27592F, 18.76879F, 0.0F, 0.0F, 0.0F, -0.3927F));
        PartDefinition p104 = p84.addOrReplaceChild("right_arm_4", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p105 = root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(1.9F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p106 = p105.addOrReplaceChild("left_leg_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p107 = root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-1.9F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition p108 = p107.addOrReplaceChild("right_leg_0", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(ElOjoEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);
        // La cabeza (el ojo) mira hacia donde mira el mob
        this.head.yRot += netHeadYaw * Mth.DEG_TO_RAD;
        this.head.xRot += headPitch * Mth.DEG_TO_RAD;
        // Brazos y piernas se balancean al caminar
        float swing = Mth.cos(limbSwing * 0.6662F) * 1.0F * limbSwingAmount;
        this.rightArm.xRot += -swing * 0.6F;
        this.leftArm.xRot += swing * 0.6F;
        this.rightLeg.xRot += swing;
        this.leftLeg.xRot += -swing;
        // Cuando persigue a alguien, levanta los brazos como un zombi
        if (entity.isAggressive()) {
            this.rightArm.xRot += -1.2F;
            this.leftArm.xRot += -1.2F;
        }
        // Respiracion suave
        float breathe = Mth.sin(ageInTicks * 0.067F) * 0.05F;
        this.rightArm.zRot += breathe;
        this.leftArm.zRot -= breathe;
    }
}
