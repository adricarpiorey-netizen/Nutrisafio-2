package com.nutrisafio;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Mod del servidor Nutrisafio.
 * Agrega el mob "El Ojo" y el item "Ojo Maldito".
 */
public class Nutrisafio implements ModInitializer {
    public static final String MOD_ID = "nutrisafio";

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
    }

    // ---- El Ojo (mob) ----
    public static final EntityType<ElOjoEntity> EL_OJO = Registry.register(
            BuiltInRegistries.ENTITY_TYPE, id("el_ojo"),
            EntityType.Builder.of(ElOjoEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.2F)
                    .clientTrackingRange(8)
                    .build("el_ojo"));

    // ---- Items ----
    public static final Item OJO_MALDITO = Registry.register(
            BuiltInRegistries.ITEM, id("ojo_maldito"), new Item(new Item.Properties()));

    // Espada Maldita: 13 de dano, velocidad de espada normal
    public static final Item ESPADA_MALDITA = Registry.register(
            BuiltInRegistries.ITEM, id("espada_maldita"),
            new SwordItem(MaldicionTier.INSTANCE, new Item.Properties()
                    .attributes(SwordItem.createAttributes(MaldicionTier.INSTANCE, 3, -2.4F))));

    // Manzana de Sangre: al comerla da Regeneracion III por 10 segundos (se puede comer sin hambre)
    public static final Item MANZANA_SANGRE = Registry.register(
            BuiltInRegistries.ITEM, id("manzana_sangre"),
            new Item(new Item.Properties().food(new net.minecraft.world.food.FoodProperties.Builder()
                    .nutrition(4).saturationModifier(1.2F).alwaysEdible()
                    .effect(new net.minecraft.world.effect.MobEffectInstance(
                            net.minecraft.world.effect.MobEffects.REGENERATION, 200, 2), 1.0F)
                    .build())));

    public static final Item EL_OJO_SPAWN_EGG = Registry.register(
            BuiltInRegistries.ITEM, id("el_ojo_spawn_egg"),
            new SpawnEggItem(EL_OJO, 0xE8E8E8, 0xB00000, new Item.Properties()));

    @Override
    public void onInitialize() {
        // Vida, velocidad y dano
        FabricDefaultAttributeRegistry.register(EL_OJO, ElOjoEntity.createAttributes());

        // Reglas de aparicion: en el suelo, de noche y bajo el cielo
        SpawnPlacements.register(EL_OJO, SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, ElOjoEntity::checkElOjoSpawnRules);

        // Aparece en todos los biomas del overworld.
        // Peso 25: menos que un creeper (100), mas que una bruja (5).
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(),
                MobCategory.MONSTER, EL_OJO, 25, 1, 1);

        // Pestanas del modo creativo
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS)
                .register(entries -> entries.accept(EL_OJO_SPAWN_EGG));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS)
                .register(entries -> entries.accept(OJO_MALDITO));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT)
                .register(entries -> entries.accept(ESPADA_MALDITA));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS)
                .register(entries -> entries.accept(MANZANA_SANGRE));
    }
}
