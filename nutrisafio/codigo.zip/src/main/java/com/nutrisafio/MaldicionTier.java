package com.nutrisafio;

import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;

/** Material de la Espada Maldita: mejor que la netherita. */
public class MaldicionTier implements Tier {
    public static final MaldicionTier INSTANCE = new MaldicionTier();

    @Override public int getUses() { return 1561; }              // igual que la espada de diamante
    @Override public float getSpeed() { return 10.0F; }
    @Override public float getAttackDamageBonus() { return 9.0F; } // 1 + 3 + 9 = 13 de dano
    @Override public TagKey<Block> getIncorrectBlocksForDrops() { return BlockTags.INCORRECT_FOR_NETHERITE_TOOL; }
    @Override public int getEnchantmentValue() { return 15; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(Nutrisafio.OJO_MALDITO); }
}
